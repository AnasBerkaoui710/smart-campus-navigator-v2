// Shared DOM helpers, formatting and an accessible combobox.
import { icon } from './icons.js';

export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'html') el.innerHTML = v; // only ever used with trusted, static markup
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

let toastTimer;
export function toast(message, ms = 4000) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, ms);
}

export const fmt = {
  distance(m) {
    if (m == null) return '';
    if (m >= 100000) return `${Math.round(m / 1000).toLocaleString('en')} km`;
    return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
  },
  duration(s) {
    if (s == null) return '';
    const min = Math.max(1, Math.round(s / 60));
    return min >= 60 ? `${Math.floor(min / 60)} h ${min % 60} min` : `${min} min`;
  },
  // Event times are stored as campus-local wall-clock times (no timezone).
  date(iso, opts = { weekday: 'short', day: 'numeric', month: 'short' }) {
    return new Intl.DateTimeFormat(undefined, opts).format(new Date(iso));
  },
  time(iso) {
    return new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
  },
  floor(f) {
    if (f == null) return '';
    return f === 0 ? 'Ground floor' : f < 0 ? `Basement ${-f}` : `Floor ${f}`;
  },
  type(t) {
    return (t || '').replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
  },
};

export function debounce(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

let comboSeq = 0;
/**
 * Accessible combobox (ARIA 1.2 list autocomplete).
 * fetchItems(query) -> Promise<[{id, label, sub, group, value}]>; onSelect(item).
 */
export class Combobox {
  constructor(input, { fetchItems, onSelect, minChars = 1, emptyText = 'No matches' }) {
    this.input = input;
    this.fetchItems = fetchItems;
    this.onSelect = onSelect;
    this.minChars = minChars;
    this.emptyText = emptyText;
    this.items = [];
    this.active = -1;
    this.reqId = 0;
    const id = `lb-${++comboSeq}`;
    this.list = h('ul', { id, role: 'listbox', class: 'listbox', hidden: true });
    input.parentElement.append(this.list);
    input.setAttribute('role', 'combobox');
    input.setAttribute('aria-autocomplete', 'list');
    input.setAttribute('aria-expanded', 'false');
    input.setAttribute('aria-controls', id);

    input.addEventListener('input', debounce(() => this.update(), 180));
    input.addEventListener('focus', () => { if (input.value.length >= this.minChars) this.update(); });
    input.addEventListener('keydown', (e) => this.onKey(e));
    input.addEventListener('blur', () => setTimeout(() => this.close(), 150));
  }

  async update() {
    const q = this.input.value.trim();
    if (q.length < this.minChars) return this.close();
    const req = ++this.reqId;
    let items;
    try { items = await this.fetchItems(q); } catch { items = []; }
    if (req !== this.reqId) return; // a newer query is in flight
    this.items = items;
    this.active = -1;
    this.render();
  }

  render() {
    this.list.replaceChildren();
    if (!this.items.length) {
      this.list.append(h('li', { class: 'empty', role: 'presentation' }, this.emptyText));
    }
    let group = null;
    this.items.forEach((item, i) => {
      if (item.group && item.group !== group) {
        group = item.group;
        this.list.append(h('li', { class: 'group', role: 'presentation' }, group));
      }
      this.list.append(h('li', {
        id: `${this.list.id}-${i}`, role: 'option', 'aria-selected': 'false',
        onmousedown: (e) => { e.preventDefault(); this.choose(i); },
      }, item.icon ? h('span', { class: 'o-ico' }, icon(item.icon, { size: 18 })) : null,
      h('span', {}, item.label), item.sub ? h('small', {}, item.sub) : null));
    });
    this.list.hidden = false;
    this.input.setAttribute('aria-expanded', 'true');
  }

  highlight(i) {
    const opts = this.list.querySelectorAll('[role="option"]');
    opts.forEach((o, j) => o.setAttribute('aria-selected', String(j === i)));
    this.active = i;
    if (opts[i]) {
      this.input.setAttribute('aria-activedescendant', opts[i].id);
      opts[i].scrollIntoView({ block: 'nearest' });
    }
  }

  onKey(e) {
    const n = this.items.length;
    if (e.key === 'ArrowDown') { e.preventDefault(); if (this.list.hidden) this.update(); else if (n) this.highlight((this.active + 1) % n); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (n) this.highlight((this.active - 1 + n) % n); }
    else if (e.key === 'Enter') {
      if (!this.list.hidden && n) { e.preventDefault(); this.choose(this.active >= 0 ? this.active : 0); }
    } else if (e.key === 'Escape') { this.close(); }
  }

  choose(i) {
    const item = this.items[i];
    this.close();
    if (item) this.onSelect(item);
  }

  close() {
    this.list.hidden = true;
    this.input.setAttribute('aria-expanded', 'false');
    this.input.removeAttribute('aria-activedescendant');
  }
}

export function locationSub(loc) {
  const parts = [fmt.type(loc.type)];
  if (loc.building && loc.building.name !== loc.name) parts.push(loc.building.name);
  if (loc.room_number) parts.push(loc.room_number);
  if (loc.building) parts.push(fmt.floor(loc.floor));
  return parts.join(' · ');
}
