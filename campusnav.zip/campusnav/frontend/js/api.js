// Thin wrapper around the REST API. Errors are thrown as ApiError with the server's code/message.
export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function request(method, path, body) {
  let res;
  try {
    res = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'network', 'Cannot reach the server. Check your connection and try again.');
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const err = data?.error || {};
    throw new ApiError(res.status, err.code || 'http_error', err.message || `Request failed (${res.status}).`, err.details);
  }
  return data;
}

const qs = (params) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') p.set(k, v);
  const s = p.toString();
  return s ? `?${s}` : '';
};

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body ?? {}),
  put: (path, body) => request('PUT', path, body),
  patch: (path, body) => request('PATCH', path, body),
  del: (path) => request('DELETE', path, {}),

  meta: () => request('GET', '/api/meta'),
  buildings: () => request('GET', '/api/buildings'),
  pathways: () => request('GET', '/api/pathways'),
  locations: (params = {}) => request('GET', `/api/locations${qs(params)}`),
  location: (id) => request('GET', `/api/locations/${encodeURIComponent(id)}`),
  nearest: (lat, lng) => request('POST', '/api/nearest', { lat, lng }),
  route: (body) => request('POST', '/api/route', body),
  events: (params = {}) => request('GET', `/api/events${qs(params)}`),
  event: (id) => request('GET', `/api/events/${encodeURIComponent(id)}`),
  categories: () => request('GET', '/api/categories'),
};
