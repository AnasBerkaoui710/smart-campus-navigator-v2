// Staff dashboard: events, closures, lookups and pathway data import.
import { api } from './api.js';
import { fmt, h, toast } from './ui.js';

const $ = (id) => document.getElementById(id);
let user = null;
let lookups = { categories: [], organizers: [], locations: [] };

async function boot() {
  try {
    user = await api.get('/api/auth/me');
    showApp();
  } catch {
    $('login-view').hidden = false;
  }
}

$('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('login-error').hidden = true;
  try {
    user = await api.post('/api/auth/login', { email: $('email').value, password: $('password').value });
    $('password').value = '';
    $('login-view').hidden = true;
    showApp();
  } catch (err) {
    $('login-error').textContent = err.message;
    $('login-error').hidden = false;
  }
});

$('logout').addEventListener('click', async () => {
  await api.post('/api/auth/logout').catch(() => {});
  location.reload();
});

async function showApp() {
  $('who').textContent = `${user.name} (${user.role})`;
  $('logout').hidden = false;
  $('app-view').hidden = false;
  document.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => openTab(b.dataset.tab)));
  if (user.role !== 'admin') {
    document.querySelectorAll('[data-tab="lookups"], [data-tab="import"]').forEach((b) => { b.hidden = true; });
  }
  await refreshLookups();
  openTab('events');
}

async function refreshLookups() {
  const [categories, organizers, locations] = await Promise.all([
    api.categories(), api.get('/api/organizers'), api.locations({ limit: 200 }),
  ]);
  lookups = { categories, organizers, locations };
}

function openTab(name) {
  document.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
  ({ events: eventsTab, closures: closuresTab, lookups: lookupsTab, import: importTab })[name]();
}

const panel = () => $('tab-panel');
const fail = (err) => toast(err.message, 6000);

// ------------------------------------------------------------------ events
async function eventsTab() {
  const events = await api.get('/api/admin/events').catch((e) => { fail(e); return []; });
  const rows = events.map((ev) => h('tr', {},
    h('td', {}, h('strong', {}, ev.title), ev.is_sample ? h('div', { class: 'muted' }, 'sample') : null),
    h('td', {}, `${fmt.date(ev.starts_at)} ${fmt.time(ev.starts_at)}`),
    h('td', {}, ev.venue.name, ev.venue.room_number ? ` (${ev.venue.room_number})` : ''),
    h('td', {}, h('span', { class: `badge ${ev.status === 'published' ? 'badge-ok' : ev.status === 'cancelled' ? 'badge-danger' : 'badge-info'}` }, ev.status)),
    h('td', {}, h('div', { class: 'row-actions' },
      h('button', { class: 'btn btn-sm', onclick: () => eventForm(ev) }, 'Edit'),
      h('button', { class: 'btn btn-sm', onclick: () => deleteEvent(ev) }, 'Delete')))));
  panel().replaceChildren(
    h('div', { class: 'card' },
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' } },
        h('h2', {}, 'Events'), h('button', { class: 'btn btn-primary', onclick: () => eventForm(null) }, '+ New event')),
      h('div', { class: 'table-wrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Title', 'Starts', 'Venue', 'Status', ''].map((t) => h('th', {}, t)))),
        h('tbody', {}, rows.length ? rows : h('tr', {}, h('td', { colspan: 5, class: 'muted' }, 'No events yet.')))))));
}

async function deleteEvent(ev) {
  if (!confirm(`Delete "${ev.title}"? This cannot be undone.`)) return;
  try {
    await api.del(`/api/admin/events/${ev.id}`);
    toast('Event deleted.');
    eventsTab();
  } catch (e) { fail(e); }
}

function eventForm(ev) {
  const field = (id, label, input, full) => h('div', { class: full ? 'full' : '' }, h('label', { class: 'lbl', for: id }, label), input);
  const select = (id, items, labelFn, selected) => h('select', { id, required: true },
    h('option', { value: '' }, 'Choose…'),
    items.map((it) => h('option', { value: it.id, selected: it.id === selected }, labelFn(it))));
  const venueLabel = (l) => `${l.name}${l.room_number ? ` (${l.room_number})` : ''}${l.building && l.building.name !== l.name ? ` — ${l.building.name}` : ''}`;
  const form = h('form', { class: 'grid2' },
    field('f-title', 'Title', h('input', { id: 'f-title', type: 'text', required: true, minlength: 3, maxlength: 200, value: ev?.title || '' }), true),
    field('f-desc', 'Description', h('textarea', { id: 'f-desc', maxlength: 5000 }, ev?.description || ''), true),
    field('f-cat', 'Category', select('f-cat', lookups.categories, (c) => c.name, ev?.category.id)),
    field('f-org', 'Organizer', select('f-org', lookups.organizers, (o) => o.name, ev?.organizer.id)),
    field('f-venue', 'Venue (campus location)', select('f-venue', [...lookups.locations].sort((a, b) => a.name.localeCompare(b.name)), venueLabel, ev?.venue.id), true),
    field('f-start', 'Starts', h('input', { id: 'f-start', type: 'datetime-local', required: true, value: ev?.starts_at || '' })),
    field('f-end', 'Ends', h('input', { id: 'f-end', type: 'datetime-local', required: true, value: ev?.ends_at || '' })),
    field('f-img', 'Image URL (optional)', h('input', { id: 'f-img', type: 'url', value: ev?.image_url || '' })),
    field('f-cap', 'Capacity (optional)', h('input', { id: 'f-cap', type: 'number', min: 1, value: ev?.capacity ?? '' })),
    field('f-regurl', 'Registration URL (optional)', h('input', { id: 'f-regurl', type: 'url', value: ev?.registration_url || '' })),
    field('f-status', 'Status', h('select', { id: 'f-status' }, ['draft', 'published', 'cancelled'].map((s) => h('option', { value: s, selected: (ev?.status || 'draft') === s }, s)))),
    h('label', { class: 'check full' }, h('input', { id: 'f-reg', type: 'checkbox', checked: !!ev?.registration_required }), 'Registration required'),
    h('div', { id: 'f-error', class: 'alert alert-error full', role: 'alert', hidden: true }),
    h('div', { class: 'row-actions full' },
      h('button', { class: 'btn btn-primary', type: 'submit' }, ev ? 'Save changes' : 'Create event'),
      h('button', { class: 'btn', type: 'button', onclick: eventsTab }, 'Cancel')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = {
      title: $('f-title').value, description: $('f-desc').value,
      category_id: Number($('f-cat').value), organizer_id: Number($('f-org').value), venue_id: Number($('f-venue').value),
      starts_at: $('f-start').value, ends_at: $('f-end').value,
      image_url: $('f-img').value || null, capacity: $('f-cap').value ? Number($('f-cap').value) : null,
      registration_url: $('f-regurl').value || null, registration_required: $('f-reg').checked, status: $('f-status').value,
    };
    try {
      if (ev) await api.put(`/api/admin/events/${ev.id}`, body);
      else await api.post('/api/admin/events', body);
      toast(ev ? 'Event updated.' : 'Event created.');
      eventsTab();
    } catch (err) {
      $('f-error').textContent = err.message;
      $('f-error').hidden = false;
    }
  });
  panel().replaceChildren(h('div', { class: 'card' }, h('h2', {}, ev ? 'Edit event' : 'New event'), form));
  $('f-title').focus();
}

// ------------------------------------------------------------------ closures
async function closuresTab() {
  const [paths] = await Promise.all([api.pathways().catch((e) => { fail(e); return []; }), refreshLookups()]);
  const outdoor = paths.filter((p) => !p.indoor || p.status === 'closed');
  const pathRows = outdoor.sort((a, b) => (a.name || '').localeCompare(b.name || '')).map((p) => h('tr', {},
    h('td', {}, p.name || h('span', { class: 'muted' }, '(unnamed)'), h('div', { class: 'muted' }, p.code)),
    h('td', {}, p.kind), h('td', {}, `${Math.round(p.length_m)} m`),
    h('td', {}, p.status === 'closed' ? h('span', { class: 'badge badge-danger' }, `closed${p.status_note ? `: ${p.status_note}` : ''}`) : h('span', { class: 'badge badge-ok' }, 'open')),
    h('td', {}, h('button', { class: 'btn btn-sm', onclick: () => toggleEdge(p) }, p.status === 'closed' ? 'Reopen' : 'Close'))));
  const locRows = lookups.locations.map((l) => h('tr', {},
    h('td', {}, l.name, h('div', { class: 'muted' }, l.room_number || l.code)),
    h('td', {}, fmt.type(l.type)),
    h('td', {}, l.is_open ? h('span', { class: 'badge badge-ok' }, 'open') : h('span', { class: 'badge badge-danger' }, `unavailable${l.status_note ? `: ${l.status_note}` : ''}`)),
    h('td', {}, h('button', { class: 'btn btn-sm', onclick: () => toggleLocation(l) }, l.is_open ? 'Mark unavailable' : 'Reopen'))));
  panel().replaceChildren(
    h('div', { class: 'card' }, h('h2', {}, 'Outdoor paths'),
      h('p', { class: 'muted' }, 'Closed paths are excluded from all routes immediately.'),
      h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Path', 'Kind', 'Length', 'Status', ''].map((t) => h('th', {}, t)))), h('tbody', {}, pathRows)))),
    h('div', { class: 'card' }, h('h2', {}, 'Facilities'),
      h('p', { class: 'muted' }, 'Unavailable facilities cannot be chosen as a route destination or event venue.'),
      h('div', { class: 'table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Location', 'Type', 'Status', ''].map((t) => h('th', {}, t)))), h('tbody', {}, locRows)))));
}

async function toggleEdge(p) {
  const closing = p.status !== 'closed';
  const note = closing ? prompt('Reason shown to users (optional):', '') : null;
  if (closing && note === null) return;
  try {
    await api.patch(`/api/admin/edges/${p.id}`, { status: closing ? 'closed' : 'open', status_note: note || null });
    toast(closing ? 'Path closed.' : 'Path reopened.');
    closuresTab();
  } catch (e) { fail(e); }
}

async function toggleLocation(l) {
  const closing = l.is_open;
  const note = closing ? prompt('Reason shown to users (optional):', '') : null;
  if (closing && note === null) return;
  try {
    await api.patch(`/api/admin/locations/${l.id}/status`, { is_open: !closing, status_note: note || null });
    toast(closing ? 'Marked unavailable.' : 'Reopened.');
    closuresTab();
  } catch (e) { fail(e); }
}

// ------------------------------------------------------------------ lookups
async function lookupsTab() {
  await refreshLookups();
  const section = (title, items, path, fields, labelFn) => {
    const inputs = fields.map(([key, label]) => h('input', { type: 'text', placeholder: label, 'aria-label': label, 'data-key': key }));
    const form = h('form', { class: 'row-actions', style: { margin: '.75rem 0' } }, inputs, h('button', { class: 'btn btn-primary', type: 'submit' }, 'Add'));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(inputs.map((i) => [i.dataset.key, i.value || null]));
      try { await api.post(path, body); toast('Added.'); lookupsTab(); } catch (err) { fail(err); }
    });
    return h('div', { class: 'card' }, h('h2', {}, title), form,
      h('table', {}, h('tbody', {}, items.map((it) => h('tr', {}, h('td', {}, labelFn(it)),
        h('td', {}, h('button', { class: 'btn btn-sm', onclick: async () => {
          if (!confirm(`Delete ${it.name}?`)) return;
          try { await api.del(`${path}/${it.id}`); toast('Deleted.'); lookupsTab(); } catch (err) { fail(err); }
        } }, 'Delete')))))));
  };
  panel().replaceChildren(
    section('Event categories', lookups.categories, '/api/admin/categories', [['slug', 'slug (e.g. sports)'], ['name', 'Name'], ['color', '#hex colour']],
      (c) => h('span', {}, h('span', { class: 'badge', style: { background: c.color, color: '#fff' } }, c.name), ` ${c.slug}`)),
    section('Organizers', lookups.organizers, '/api/admin/organizers', [['name', 'Name'], ['department', 'Department'], ['contact_email', 'Contact email']],
      (o) => `${o.name}${o.department ? ` — ${o.department}` : ''}`));
}

// ------------------------------------------------------------------ import
function importTab() {
  const file = h('input', { type: 'file', accept: 'application/json,.json', id: 'imp-file' });
  const out = h('div', { 'aria-live': 'polite' });
  const run = async (dry) => {
    out.replaceChildren();
    if (!file.files[0]) { out.append(h('div', { class: 'alert alert-warn' }, 'Choose a dataset file first.')); return; }
    let data;
    try { data = JSON.parse(await file.files[0].text()); } catch { out.append(h('div', { class: 'alert alert-error' }, 'The file is not valid JSON.')); return; }
    if (!dry && !confirm('Replace the campus pathway data with this file? Edge closures are kept for paths with the same code.')) return;
    try {
      const res = await api.post(`/api/admin/import${dry ? '?dry_run=1' : ''}`, data);
      if (dry) {
        out.append(h('div', { class: `alert ${res.valid ? 'alert-info' : 'alert-error'}` }, res.valid ? 'Dataset is valid.' : 'Dataset has errors:'),
          h('ul', {}, [...res.errors.map((x) => h('li', {}, x)), ...res.warnings.map((x) => h('li', {}, `Warning: ${x}`))]));
      } else {
        out.append(h('div', { class: 'alert alert-info' }, `Imported ${res.nodes} nodes, ${res.edges} edges, ${res.locations} locations.`),
          h('ul', {}, res.warnings.map((x) => h('li', {}, `Warning: ${x}`))));
      }
    } catch (e) {
      out.append(h('div', { class: 'alert alert-error' }, e.message), h('ul', {}, (e.details?.errors || []).map((x) => h('li', {}, x))));
    }
  };
  panel().replaceChildren(h('div', { class: 'card' },
    h('h2', {}, 'Import campus pathway data'),
    h('p', {}, 'Upload a ', h('code', {}, 'campusnav-pathways/1'), ' JSON file (see docs/ROUTING.md). It is validated first: unknown nodes, duplicate codes, ',
      'edges shorter than their straight-line distance, and locations used by events that would disappear are all rejected.'),
    h('div', { class: 'field' }, h('label', { class: 'lbl', for: 'imp-file' }, 'Dataset file'), file),
    h('div', { class: 'row-actions' },
      h('button', { class: 'btn', type: 'button', onclick: () => run(true) }, 'Validate only'),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: () => run(false) }, 'Import')),
    out));
}

boot();
