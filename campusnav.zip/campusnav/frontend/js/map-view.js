// Map section: Leaflet map, destination/start selection, route panel, and
// Google-Maps-style turn-by-turn navigation (banner, ETA bar, live progress, walking preview, voice).
import { api } from './api.js';
import { icon, stepIconName, svg, typeIcon } from './icons.js';
import { Combobox, fmt, h, locationSub, toast } from './ui.js';

const OFF_ROUTE_M = 25;          // farther than this from the route line counts as off-route
const OFF_ROUTE_FIXES = 2;       // ...for this many consecutive GPS fixes
const REROUTE_MIN_MS = 10000;    // never re-route more often than this
const ARRIVE_M = 15;
const NAV_PREVIEW_SPEED = 6;     // m/s for the walking preview (faster than real walking, so it can be watched)
const NAV_DWELL_S = 1.4;         // pause at doors / stairs / lifts during the preview
const STORE_KEY = 'campusnav.nav';
const OSM_TILES = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const ESRI_STREETS = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
const SAT_TILES = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
const $ = (id) => document.getElementById(id);

const state = {
  meta: null, dest: null, start: null, profile: 'shortest', avoidStairs: false, avoidEdges: [],
  result: null, selected: 0, event: null, watchId: null, simulate: false, pickMode: false,
  offRouteCount: 0, lastReroute: 0, arrived: false, reqId: 0, autoStart: false,
};
const nav = {
  on: false, route: null, cum: [], total: 0, startIdx: [], startCum: [], k: 0, s: 0,
  playing: true, follow: false, dwell: 0, timer: null, voice: false, spoken: '', lastTick: 0,
};

let map, routeLayer, markerLayer, youLayer, pathLayer, walkerMarker;
let baseLayers = {};
let locationsCache = null;
let fitted = false;

// ------------------------------------------------------------------ init
export async function initMap(meta) {
  state.meta = meta;
  map = L.map('map', { maxZoom: 21, minZoom: 14, zoomSnap: 0.5, zoomControl: true });
  const esri = L.tileLayer(ESRI_STREETS, { maxZoom: 21, maxNativeZoom: 19, attribution: 'Tiles &copy; Esri &mdash; Source: Esri, HERE, Garmin, OpenStreetMap contributors' });
  const osm = L.tileLayer(OSM_TILES, { maxZoom: 21, maxNativeZoom: 19, referrerPolicy: 'origin', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });
  const sat = L.tileLayer(SAT_TILES, { maxZoom: 21, maxNativeZoom: 19, attribution: 'Imagery &copy; Esri, Maxar, Earthstar Geographics' });
  const plain = L.layerGroup();
  baseLayers = { osm, esri, sat };
  osm.addTo(map);
  // If tiles fail to load (offline / blocked) tell the user how to switch; the route itself is drawn by us.
  let tileErrors = 0;
  osm.on('tileerror', () => { if (++tileErrors === 8) toast('Map tiles could not be loaded. Try the layer switcher (top-left) or check your connection.', 7000); });
  const outlineLayer = L.layerGroup().addTo(map);
  pathLayer = L.layerGroup().addTo(map);
  const buildingLayer = L.layerGroup().addTo(map);
  markerLayer = L.layerGroup().addTo(map);
  routeLayer = L.layerGroup().addTo(map);
  youLayer = L.layerGroup().addTo(map);
  L.control.layers({ 'OpenStreetMap': osm, 'Streets (Esri)': esri, Satellite: sat, 'Plain plan': plain }, { 'Campus outline': outlineLayer, Walkways: pathLayer, Buildings: buildingLayer }, { position: 'topleft' }).addTo(map);
  L.control.scale({ imperial: false }).addTo(map);

  const locate = L.control({ position: 'topleft' });
  locate.onAdd = () => {
    const wrap = L.DomUtil.create('div', 'leaflet-bar');
    const b = L.DomUtil.create('button', 'locate-btn', wrap);
    b.type = 'button';
    b.setAttribute('aria-label', 'Show my location');
    b.innerHTML = svg('locate', { size: 20 });
    L.DomEvent.on(b, 'click', (e) => { L.DomEvent.stop(e); locateOnMap(); });
    return wrap;
  };
  locate.addTo(map);

  if (meta.dataset.is_sample) {
    const note = L.control({ position: 'bottomleft' });
    note.onAdd = () => h('div', { class: 'map-note' }, 'Roads and outline: OpenStreetMap. Buildings, floors and rooms: potential layout, not yet surveyed.');
    note.addTo(map);
    document.querySelector('.demo-only').hidden = false;
  }
  if (meta.dataset.outline?.length) {
    L.polygon(meta.dataset.outline, { color: '#245d38', weight: 3, dashArray: '8 6', fillColor: '#9dc183', fillOpacity: 0.12, interactive: false }).addTo(outlineLayer);
  }
  map.setView(meta.bounds ? L.latLngBounds(meta.bounds).getCenter() : [32.3766, -6.3193], 17);
  map.on('click', onMapClick);
  // Zoomed out: show short building codes; zoomed in: full names with floor counts.
  const syncLabels = () => map.getContainer().classList.toggle('low-zoom', map.getZoom() < 18);
  map.on('zoomend', syncLabels);
  syncLabels();

  const [buildings, paths, locations] = await Promise.all([api.buildings(), api.pathways(), api.locations({ limit: 200 })]);
  locationsCache = locations;
  for (const b of buildings) {
    if (!b.footprint?.length) continue;
    const floors = b.floors[1] - b.floors[0] + 1;
    const poly = L.polygon(b.footprint, {
      color: '#245d38', weight: 2, fillColor: b.is_open ? '#ede8d0' : '#fbe4e1', fillOpacity: 0.92,
    }).addTo(buildingLayer);
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    poly.bindTooltip(`<b class="bl-code">${esc(b.code)}</b><span class="bl-name">${esc(b.name)}<br><small>${floors} floor${floors > 1 ? 's' : ''}</small></span>`,
      { permanent: true, direction: 'center', className: 'building-label' });
    poly.on('click', (e) => {
      if (state.pickMode || state.simulate) return;
      L.DomEvent.stopPropagation(e);
      const loc = locations.find((l) => l.code === b.code.toLowerCase());
      if (loc) setDestination(loc);
    });
  }
  drawPathways(paths);
  for (const loc of locations.filter((l) => !l.building)) {
    L.marker([loc.lat, loc.lng], {
      icon: L.divIcon({ className: '', html: `<div class="loc-badge">${svg(typeIcon(loc.type), { size: 16 })}</div>`, iconSize: [30, 30], iconAnchor: [15, 15] }),
      title: loc.name, keyboard: false,
    }).bindTooltip(loc.name).on('click', (e) => {
      if (state.pickMode || state.simulate) return;
      L.DomEvent.stopPropagation(e);
      setDestination(loc);
    }).addTo(buildingLayer);
  }

  bindPanel();
  restore();
}

function drawPathways(paths) {
  pathLayer.clearLayers();
  for (const p of paths) {
    if (p.status === 'closed') {
      L.polyline(p.coords, { color: '#b3261e', weight: 6, dashArray: '6 6' })
        .bindTooltip(`Closed${p.name ? `: ${p.name}` : ''}${p.status_note ? ` — ${p.status_note}` : ''}`).addTo(pathLayer);
      continue;
    }
    if (p.indoor) continue;
    L.polyline(p.coords, { color: '#ffffff', weight: 7, opacity: 0.85, interactive: false }).addTo(pathLayer);
    L.polyline(p.coords, { color: '#7fae6b', weight: 3.5, interactive: false }).addTo(pathLayer);
  }
}

// ------------------------------------------------------------------ section entry
export async function showMap(params) {
  map.invalidateSize();
  if (!fitted && state.meta.bounds) {
    fitted = true;
    if (!state.dest) map.fitBounds(state.meta.bounds, { padding: [40, 40] });
  }
  const to = params.get('to');
  const eventId = params.get('event');
  // Optional route parameters (used by the AI assistant and shareable links):
  //   from=<placeId>  starting place      stepfree=1|0  avoid stairs      go=1  start turn-by-turn once the route is ready
  const from = params.get('from');
  const hasOptions = from || params.has('stepfree') || params.get('go') === '1';
  try {
    if (params.has('stepfree')) {
      state.avoidStairs = params.get('stepfree') === '1';
      $('avoid-stairs').checked = state.avoidStairs;
    }
    if (from) {
      const loc = await api.location(from);
      stopWatch();
      state.start = { type: 'location', location: loc, lat: loc.lat, lng: loc.lng, label: loc.name };
      $('start-gps').setAttribute('aria-pressed', 'false');
      setStartStatus(`From: ${loc.name}`);
      drawMarkers();
    }
    state.autoStart = params.get('go') === '1';
    if (eventId) state.event = await api.event(eventId);
    else if (to) state.event = null;
    if (to && String(state.dest?.id) !== to) setDestination(await api.location(to), { keepEvent: true });
    else {
      renderEventContext();
      if (to && hasOptions) calculate();
    }
    persist();
  } catch (e) {
    showError(e.message);
    return;
  }
  // Navigate-to-Event / deep link without a start: try the user's location right away.
  if (to && !state.start) locate();
}

// ------------------------------------------------------------------ panel wiring
function bindPanel() {
  const fetchLocations = async (q) => (await api.locations({ q, limit: 12 })).map((loc) => ({
    label: loc.name, sub: locationSub(loc), icon: typeIcon(loc.type), value: loc,
  }));
  new Combobox($('dest-input'), {
    fetchItems: fetchLocations,
    onSelect: (item) => { $('dest-input').value = ''; setDestination(item.value); },
  });
  new Combobox($('start-input'), {
    fetchItems: fetchLocations,
    onSelect: (item) => {
      $('start-input').value = '';
      stopWatch();
      setStart({ type: 'location', location: item.value, lat: item.value.lat, lng: item.value.lng, label: item.value.name });
    },
  });
  $('start-gps').addEventListener('click', () => locate());
  $('start-pick').addEventListener('click', () => {
    state.pickMode = !state.pickMode;
    $('start-pick').setAttribute('aria-pressed', String(state.pickMode));
    map.getContainer().style.cursor = state.pickMode ? 'crosshair' : '';
    if (state.pickMode) {
      setStartStatus('Tap or click the map where you are.');
      collapsePanel(true);
    }
  });
  $('simulate-gps').addEventListener('change', (e) => {
    state.simulate = e.target.checked;
    if (state.simulate) {
      stopWatch();
      toast('Click the map to move your simulated position.');
    }
  });
  document.querySelectorAll('input[name="profile"]').forEach((r) => r.addEventListener('change', (e) => {
    state.profile = e.target.value;
    persist();
    calculate();
  }));
  $('avoid-stairs').addEventListener('change', (e) => {
    state.avoidStairs = e.target.checked;
    persist();
    calculate();
  });
  $('panel-handle').addEventListener('click', () => collapsePanel(!$('panel').classList.contains('collapsed')));
  $('nav-exit').addEventListener('click', () => exitNav());
  $('nav-next').addEventListener('click', () => gotoStep(nav.k + 1));
  $('nav-prev').addEventListener('click', () => gotoStep(Math.max(0, nav.k - 1)));
  $('nav-play').addEventListener('click', () => setPlaying(!nav.playing));
  $('nav-voice').addEventListener('click', () => setVoice(!nav.voice));
  $('arrived-ok').addEventListener('click', () => { $('arrived').hidden = true; exitNav(); });
  $('fab-start').addEventListener('click', () => startNav());
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && nav.on) exitNav(); });
}

/** Snapshot of the map state, sent to the assistant as context so it can answer "how long?" / "what's next?". */
export function getMapContext() {
  const route = state.result?.routes[state.selected];
  return {
    destination: state.dest?.name || '', start: state.start?.label || '', avoid_stairs: state.avoidStairs, profile: state.profile,
    route_minutes: route ? Math.max(1, Math.round(route.duration_s / 60)) : 0, route_meters: route ? Math.round(route.distance_m) : 0,
    navigating: nav.on, instruction: nav.on ? `${$('nav-dist').textContent} ${$('nav-instr').textContent}`.trim() : '',
  };
}

// ---- remote control used by the AI assistant (also handy for tests) ----
export function routeOptions({ avoid_stairs: stairs, profile } = {}) {
  if (typeof stairs === 'boolean') { state.avoidStairs = stairs; $('avoid-stairs').checked = stairs; }
  if (profile === 'shortest' || profile === 'fastest') {
    state.profile = profile;
    document.querySelector(`input[name="profile"][value="${profile}"]`).checked = true;
  }
  persist();
  calculate();
}

export function navControl(cmd) {
  if (cmd === 'start') {
    if (state.result) startNav();
    else toast('Choose a destination first, then I can start the navigation.');
    return;
  }
  if (!nav.on) { toast('Navigation is not running.'); return; }
  if (cmd === 'stop') exitNav();
  else if (cmd === 'next_step') gotoStep(nav.k + 1);
  else if (cmd === 'previous_step') gotoStep(Math.max(0, nav.k - 1));
  else if (cmd === 'pause') setPlaying(false);
  else if (cmd === 'resume' && !nav.follow) setPlaying(true);
  else if (cmd === 'repeat' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(`${$('nav-dist').textContent}. ${$('nav-instr').textContent}`));
  }
}

function setBase(name) {
  Object.values(baseLayers).forEach((l) => map.removeLayer(l));
  (baseLayers[name] || baseLayers.osm).addTo(map).bringToBack();
}

export async function mapControl(cmd, placeId) {
  map.invalidateSize();
  if (cmd === 'zoom_in') map.zoomIn();
  else if (cmd === 'zoom_out') map.zoomOut();
  else if (cmd === 'show_my_location') locateOnMap();
  else if (cmd === 'show_campus' && state.meta.bounds) map.fitBounds(state.meta.bounds, { padding: [40, 40] });
  else if (cmd === 'satellite_view') setBase('sat');
  else if (cmd === 'street_view') setBase('osm');
  else if (cmd === 'clear_route') clearDestination();
  else if (cmd === 'show_place' && placeId) {
    const loc = await api.location(placeId);
    map.setView([loc.lat, loc.lng], 19);
    L.popup({ closeButton: false }).setLatLng([loc.lat, loc.lng]).setContent(`<strong>${loc.name.replace(/[<>&]/g, '')}</strong>`).openOn(map);
  }
}

export function setAvoidStairs(on) {
  state.avoidStairs = on;
  $('avoid-stairs').checked = on;
  persist();
  calculate();
}

function collapsePanel(collapsed) {
  if (!window.matchMedia('(max-width: 820px)').matches) return;
  $('panel').classList.toggle('collapsed', collapsed);
  $('panel-handle').setAttribute('aria-expanded', String(!collapsed));
}

// ------------------------------------------------------------------ destination / start
export function setDestination(loc, { keepEvent = false } = {}) {
  if (nav.on) exitNav();
  state.dest = loc;
  state.avoidEdges = [];
  state.arrived = false;
  if (!keepEvent) state.event = null;
  const target = `#/map?to=${loc.id}${state.event ? `&event=${state.event.id}` : ''}`;
  // Only rewrite the URL while the map is the visible section (not when restoring a session on Home).
  if (location.hash.startsWith('#/map') && location.hash !== target) history.replaceState(null, '', target);
  renderDestCard();
  renderEventContext();
  drawMarkers();
  persist();
  collapsePanel(false);
  if (state.start) calculate();
  else {
    clearRoute();
    setStartStatus('Choose a starting point: use your location, search, or pick on the map.');
    map.setView([loc.lat, loc.lng], Math.max(map.getZoom(), 18));
  }
}

function clearDestination() {
  if (nav.on) exitNav();
  state.dest = null;
  state.event = null;
  state.result = null;
  if (location.hash.startsWith('#/map')) history.replaceState(null, '', '#/map');
  renderDestCard();
  renderEventContext();
  clearRoute();
  drawMarkers();
  persist();
}

function setStart(start) {
  state.start = start;
  state.pickMode = false;
  $('start-pick').setAttribute('aria-pressed', 'false');
  $('start-gps').setAttribute('aria-pressed', String(start.type === 'gps'));
  map.getContainer().style.cursor = '';
  if (start.type !== 'gps') setStartStatus(`From: ${start.label}`);
  drawMarkers();
  persist();
  calculate();
}

/** Use the campus main gate as the starting point. Returns false if the map has no gate. */
function useGateStart(message) {
  const gate = locationsCache?.find((l) => l.code === 'gate-main') || locationsCache?.find((l) => l.type === 'gate');
  if (!gate) return false;
  stopWatch();
  setStart({ type: 'location', location: gate, lat: gate.lat, lng: gate.lng, label: gate.name });
  if (message) setStartStatus(message);
  return true;
}

function setStartStatus(text, tone) {
  const el = $('start-status');
  el.textContent = text || '';
  el.style.color = tone === 'error' ? 'var(--red-600)' : '';
}

async function onMapClick(e) {
  const { lat, lng } = e.latlng;
  if (state.pickMode) {
    try {
      const near = await api.nearest(lat, lng);
      if (!near.within_campus) {
        setStartStatus(`That point is ${fmt.distance(near.distance_m)} from the nearest mapped path. Pick a point on campus.`, 'error');
        return;
      }
      stopWatch();
      setStart({ type: 'point', lat, lng, label: 'Point on map' });
      collapsePanel(false);
    } catch (err) {
      setStartStatus(err.message, 'error');
    }
  } else if (state.simulate) {
    handleFix(lat, lng, 5);
  }
}

// ------------------------------------------------------------------ geolocation
function locateOnMap() {
  if (!('geolocation' in navigator)) { toast('Location is not available in this browser.'); return; }
  navigator.geolocation.getCurrentPosition(
    (p) => { showYou(p.coords.latitude, p.coords.longitude, p.coords.accuracy); map.setView([p.coords.latitude, p.coords.longitude], Math.max(map.getZoom(), 18)); },
    () => toast('Could not get your location. Check the browser permission.'),
    { enableHighAccuracy: true, timeout: 10000 });
}

function locate() {
  if (state.simulate) {
    setStartStatus('Simulated position is on: click the map to set where you are.');
    return;
  }
  if (!('geolocation' in navigator)) {
    setStartStatus('Location is not available in this browser. Search for a starting point or pick it on the map.', 'error');
    return;
  }
  setStartStatus('Finding your location…');
  navigator.geolocation.getCurrentPosition(
    (pos) => handleFix(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy),
    (err) => {
      const msg = {
        1: 'Location permission was denied. Search for a starting point or pick it on the map.',
        2: 'Your position is unavailable right now. Search for a starting point or pick it on the map.',
        3: 'Finding your location took too long. Try again, or choose a starting point.',
      }[err.code] || 'Could not get your location.';
      setStartStatus(msg, 'error');
      $('start-input').focus({ preventScroll: true });
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 },
  );
}

async function handleFix(lat, lng, accuracy) {
  showYou(lat, lng, accuracy);
  if (state.start?.type === 'gps') return onMove(lat, lng);
  try {
    const near = await api.nearest(lat, lng);
    if (!near.within_campus) {
      stopWatch();
      const away = fmt.distance(near.distance_m);
      // Not on campus (e.g. testing from home): start the route at the main gate instead of dead-ending.
      if (state.dest && useGateStart(`You are ${away} from the campus, so the route starts at the main gate. Change the start any time.`)) return;
      setStartStatus(`You are ${away} from the campus, so we can't route from your position. Pick a starting point on campus.`, 'error');
      return;
    }
  } catch (err) {
    setStartStatus(err.message, 'error');
    return;
  }
  state.start = { type: 'gps', lat, lng, label: 'Your location' };
  $('start-gps').setAttribute('aria-pressed', 'true');
  setStartStatus(`Using your location${accuracy > 50 ? ` (low accuracy: ±${Math.round(accuracy)} m)` : ''}. The route updates as you walk.`);
  startWatch();
  drawMarkers();
  calculate();
}

function startWatch() {
  if (state.simulate || state.watchId !== null || !('geolocation' in navigator)) return;
  state.watchId = navigator.geolocation.watchPosition(
    (pos) => handleFix(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy),
    () => {}, { enableHighAccuracy: true, maximumAge: 5000 },
  );
}

function stopWatch() {
  if (state.watchId !== null) navigator.geolocation.clearWatch(state.watchId);
  state.watchId = null;
  if (state.start?.type === 'gps') $('start-gps').setAttribute('aria-pressed', 'false');
}

function onMove(lat, lng) {
  const route = state.result?.routes[state.selected];
  if (!route) return;
  if (nav.on && nav.follow) {
    const p = projectOnRoute(lat, lng);
    if (p && p.d <= OFF_ROUTE_M) { nav.s = Math.max(nav.s, p.s); advance(); render(false); }
  }
  if (state.dest && metres(lat, lng, state.dest.lat, state.dest.lng) < ARRIVE_M && !state.arrived && !nav.on) {
    state.arrived = true;
    toast(`You have arrived at ${state.dest.name}.`);
    return;
  }
  const off = distanceToRoute(lat, lng, route.geometry);
  if (off === null || off <= OFF_ROUTE_M) {
    state.offRouteCount = 0;
    return;
  }
  state.offRouteCount += 1;
  if (state.offRouteCount >= OFF_ROUTE_FIXES && Date.now() - state.lastReroute > REROUTE_MIN_MS) {
    state.offRouteCount = 0;
    state.lastReroute = Date.now();
    state.start = { type: 'gps', lat, lng, label: 'Your location' };
    toast('You left the route — recalculating…');
    calculate({ keepView: true });
  }
}

function showYou(lat, lng, accuracy) {
  youLayer.clearLayers();
  if (nav.on && !nav.follow) return; // the walking preview draws its own marker
  if (accuracy) L.circle([lat, lng], { radius: accuracy, color: '#1a73e8', weight: 1, fillOpacity: 0.08, interactive: false }).addTo(youLayer);
  L.marker([lat, lng], { icon: L.divIcon({ className: '', html: '<div class="you-dot"></div>', iconSize: [20, 20], iconAnchor: [10, 10] }), keyboard: false, title: 'You are here' }).addTo(youLayer);
}

// Equirectangular metres; fine at campus scale.
function project(lat, lng, lat0, lng0) {
  return [(lng - lng0) * Math.cos((lat0 * Math.PI) / 180) * 111195, (lat - lat0) * 111195];
}
function metres(lat1, lng1, lat2, lng2) {
  const [x, y] = project(lat2, lng2, lat1, lng1);
  return Math.hypot(x, y);
}
function distanceToRoute(lat, lng, geometry) {
  let best = null;
  for (let i = 0; i + 1 < geometry.length; i++) {
    const a = geometry[i], b = geometry[i + 1];
    if (!a.outdoor || !b.outdoor) continue; // GPS cannot be trusted indoors
    const [ax, ay] = project(a.lat, a.lng, lat, lng);
    const [bx, by] = project(b.lat, b.lng, lat, lng);
    const dx = bx - ax, dy = by - ay;
    const len2 = dx * dx + dy * dy;
    const t = len2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / len2)) : 0;
    const d = Math.hypot(ax + t * dx, ay + t * dy);
    best = best === null ? d : Math.min(best, d);
  }
  return best;
}

// ------------------------------------------------------------------ routing
async function calculate({ keepView = false } = {}) {
  if (!state.dest || !state.start) return;
  const from = state.start.type === 'location'
    ? { location_id: state.start.location.id }
    : { lat: state.start.lat, lng: state.start.lng };
  const body = {
    from, to: { location_id: state.dest.id }, profile: state.profile,
    avoid_stairs: state.avoidStairs, avoid_edges: state.avoidEdges, alternatives: true,
  };
  const req = ++state.reqId;
  $('route-loading').hidden = false;
  $('route-error').hidden = true;
  try {
    const result = await api.route(body);
    if (req !== state.reqId) return;
    state.result = result;
    state.selected = 0;
    renderResults();
    if (nav.on) {
      prepareNav(result.routes[0]);
      nav.s = 0; nav.k = 0; nav.dwell = 0;
      render(true);
    } else {
      collapsePanel(true); // phones: show the route, keep the summary bar tappable
      drawRoute(!keepView);
      if (state.autoStart) { state.autoStart = false; startNav(); }
    }
  } catch (e) {
    if (e.code !== 'outside_campus') state.autoStart = false;
    if (req !== state.reqId) return;
    // A start point (GPS or a remembered point) that is far from campus: fall back to the main gate.
    if (e.code === 'outside_campus' && state.start?.type !== 'location'
      && useGateStart('That start point is far from the campus, so the route starts at the main gate. Change the start any time.')) return;
    state.result = null;
    if (nav.on) exitNav();
    clearRoute();
    showError(e.message);
  } finally {
    if (req === state.reqId) $('route-loading').hidden = true;
  }
}

function showError(message) {
  const el = $('route-error');
  el.replaceChildren(icon('alert', { size: 20 }), h('span', {}, message));
  el.hidden = false;
  $('panel-summary').textContent = 'Directions';
  $('fab-start').hidden = true;
}

function clearRoute() {
  routeLayer.clearLayers();
  $('route-results').replaceChildren();
  $('route-error').hidden = true;
  $('fab-start').hidden = true;
  $('panel-summary').textContent = state.dest ? `To ${state.dest.name}` : 'Directions';
}

// ------------------------------------------------------------------ rendering (panel)
function renderDestCard() {
  const card = $('dest-card');
  card.replaceChildren();
  const loc = state.dest;
  card.classList.toggle('empty', !loc);
  if (!loc) {
    card.append(h('p', { class: 'muted' }, 'Search for a place, or tap a building on the map.'));
    return;
  }
  card.append(...[
    h('div', { class: 'row' },
      h('div', { style: { display: 'flex', gap: '.75rem', alignItems: 'center' } },
        h('span', { class: 'd-ico' }, icon(typeIcon(loc.type), { size: 22 })),
        h('div', {}, h('h2', {}, loc.name), h('div', { class: 'meta' }, locationSub(loc)))),
      h('button', { class: 'btn btn-ghost btn-sm', type: 'button', 'aria-label': `Clear destination ${loc.name}`, onclick: clearDestination }, icon('x', { size: 18 }))),
    loc.description ? h('p', { class: 'meta', style: { margin: '.5rem 0 0' } }, loc.description) : null,
    !loc.is_open ? h('div', { class: 'alert alert-warn' }, `Temporarily unavailable${loc.status_note ? `: ${loc.status_note}` : ''}`) : null,
  ].filter(Boolean));
}

function renderEventContext() {
  const box = $('event-context');
  const ev = state.event;
  box.hidden = !ev;
  box.replaceChildren();
  if (!ev) return;
  box.append(
    h('span', { class: 'muted' }, 'Navigating to event'),
    h('strong', {}, ev.title),
    h('span', {}, `${fmt.date(ev.starts_at)} · ${fmt.time(ev.starts_at)}–${fmt.time(ev.ends_at)}`), ' ',
    h('a', { href: `#/events/${ev.id}` }, 'Event details'),
  );
}

const PIN_SVG = '<svg width="34" height="44" viewBox="0 0 34 44" aria-hidden="true"><path d="M17 43S3 28 3 17a14 14 0 0 1 28 0c0 11-14 26-14 26z" fill="#b3261e" stroke="#fff" stroke-width="2.5"/><circle cx="17" cy="17" r="5.5" fill="#fff"/></svg>';

function drawMarkers() {
  markerLayer.clearLayers();
  if (state.dest) {
    L.marker([state.dest.lat, state.dest.lng], {
      icon: L.divIcon({ className: 'pin-wrap', html: PIN_SVG, iconSize: [34, 44], iconAnchor: [17, 43] }),
      title: `Destination: ${state.dest.name}`, alt: 'Destination', zIndexOffset: 1000,
    }).bindTooltip(state.dest.name, { direction: 'top', offset: [0, -40] }).addTo(markerLayer);
  }
  if (state.start && state.start.type !== 'gps') {
    L.marker([state.start.lat, state.start.lng], {
      icon: L.divIcon({ className: '', html: '<div class="pin-start"></div>', iconSize: [22, 22], iconAnchor: [11, 11] }),
      title: `Start: ${state.start.label}`, alt: 'Start',
    }).bindTooltip(state.start.label).addTo(markerLayer);
  }
}

function drawRoute(fit = true) {
  routeLayer.clearLayers();
  const result = state.result;
  if (!result) return;
  result.routes.forEach((r, i) => {
    if (i === state.selected) return;
    L.polyline(r.geometry.map((p) => [p.lat, p.lng]), { color: '#6b7d70', weight: 5, opacity: 0.75, dashArray: '8 8' })
      .bindTooltip(`${r.label}: ${fmt.duration(r.duration_s)}, ${fmt.distance(r.distance_m)}`)
      .on('click', (e) => { L.DomEvent.stopPropagation(e); selectRoute(i); })
      .addTo(routeLayer);
  });
  const r = result.routes[state.selected];
  drawRouteLine(r.geometry, 0, '#1a73e8');
  addFloorTags(r.geometry);
  if (fit) {
    const covered = window.matchMedia('(max-width: 820px)').matches ? $('panel').offsetHeight : 0;
    map.fitBounds(L.latLngBounds(r.geometry.map((p) => [p.lat, p.lng])), {
      paddingTopLeft: [40, 40], paddingBottomRight: [40, 40 + covered], maxZoom: 19,
    });
  }
}

/** Route line with a white casing; indoor legs dashed. `fromIdx` allows drawing only the remaining part. */
function drawRouteLine(g, fromIdx, color, opacity = 1) {
  for (let i = fromIdx; i + 1 < g.length; i++) {
    const seg = [[g[i].lat, g[i].lng], [g[i + 1].lat, g[i + 1].lng]];
    const indoor = !g[i].outdoor || !g[i + 1].outdoor;
    L.polyline(seg, { color: '#ffffff', weight: 11, opacity, interactive: false }).addTo(routeLayer);
    L.polyline(seg, { color, weight: 6, opacity, dashArray: indoor ? '4 9' : null, lineCap: 'round', interactive: false }).addTo(routeLayer);
  }
}

function addFloorTags(g) {
  for (let i = 0; i + 1 < g.length; i++) {
    if (g[i].floor === g[i + 1].floor) continue;
    const up = g[i + 1].floor > g[i].floor;
    L.marker([g[i + 1].lat, g[i + 1].lng], {
      icon: L.divIcon({ className: '', html: `<span class="floor-tag">${svg(up ? 'straight' : 'chevron', { size: 12 })}${fmt.floor(g[i + 1].floor)}</span>`, iconAnchor: [-8, 12] }),
      keyboard: false, interactive: false,
    }).addTo(routeLayer);
  }
}

function selectRoute(i) {
  state.selected = i;
  renderResults();
  drawRoute(false);
}

function renderResults() {
  const box = $('route-results');
  box.replaceChildren();
  const result = state.result;
  if (!result) return;
  const sel = result.routes[state.selected];
  $('panel-summary').textContent = `${fmt.duration(sel.duration_s)} · ${fmt.distance(sel.distance_m)} to ${state.dest.name}`;
  $('fab-start').hidden = nav.on;

  const cards = h('div', { class: 'routes', role: 'group', 'aria-label': 'Route options' });
  result.routes.forEach((r, i) => {
    const tags = [];
    if (r.uses_stairs) tags.push(h('span', { class: 'badge badge-warn' }, icon('stairs', { size: 13 }), 'Stairs'));
    if (r.uses_elevator) tags.push(h('span', { class: 'badge badge-info' }, icon('elevator', { size: 13 }), 'Elevator'));
    if (r.accessibility === 'verified') tags.push(h('span', { class: 'badge badge-ok' }, icon('accessibility', { size: 13 }), 'Step-free'));
    if (r.accessibility === 'incomplete') tags.push(h('span', { class: 'badge badge-warn', title: 'Some segments have not been surveyed for accessibility' }, icon('accessibility', { size: 13 }), 'Step-free (unverified parts)'));
    if (r.floors.length > 1) tags.push(h('span', { class: 'badge badge-info' }, `Floors ${r.floors.map((f) => (f === 0 ? 'G' : f)).join('–')}`));
    cards.append(h('button', {
      type: 'button', class: 'route-card', 'aria-pressed': String(i === state.selected), onclick: () => selectRoute(i),
    },
    h('div', { class: 'top' }, h('span', { class: 'time' }, fmt.duration(r.duration_s)), h('span', { class: 'muted' }, fmt.distance(r.distance_m))),
    h('div', {}, h('strong', {}, r.label)),
    h('div', { class: 'tags' }, tags)));
  });
  box.append(cards);
  box.append(h('button', { class: 'btn btn-primary btn-lg start-nav', type: 'button', onclick: startNav }, icon('navigation', { size: 22 }), 'Start navigation'));

  for (const w of result.warnings) box.append(h('div', { class: 'alert alert-warn' }, icon('alert', { size: 18 }), h('span', {}, w)));
  if (state.avoidEdges.length) {
    box.append(h('div', { class: 'alert alert-info' }, h('span', {},
      `Avoiding ${state.avoidEdges.length} segment(s) you reported as blocked. `,
      h('button', { class: 'link-btn', type: 'button', onclick: () => { state.avoidEdges = []; calculate(); } }, 'Reset'))));
  }

  const list = h('ol', { class: 'steps', 'aria-label': `Directions, ${sel.label}` });
  sel.steps.forEach((s) => {
    const sub = [];
    if (s.distance_m) sub.push(h('span', {}, fmt.distance(s.distance_m)));
    if (s.building_id !== null && s.kind !== 'approach') sub.push(h('span', {}, fmt.floor(s.floor)));
    if (s.edge_ids.length && s.kind !== 'approach') {
      sub.push(h('button', {
        type: 'button', class: 'link-btn', onclick: () => reportBlocked(s), 'aria-label': `Report blocked: ${s.text}`,
      }, 'Blocked?'));
    }
    const li = h('li', { class: s.kind === 'arrive' ? 'arrive' : '' },
      h('span', { class: 'ico' }, icon(stepIconName(s), { size: 22 })),
      h('div', {},
        h('div', { class: 'txt', tabindex: '0', role: 'button', 'aria-label': `${s.text}. Show on map.`,
          onclick: () => focusStep(li, s), onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); focusStep(li, s); } } }, s.text),
        sub.length ? h('div', { class: 'sub' }, sub) : ''));
    list.append(li);
  });
  box.append(list);

  const notes = [];
  if (state.meta.dataset.is_sample) notes.push('Buildings, floors and rooms are a potential layout (not surveyed): distances and times are estimates.');
  notes.push(`Times assume ${state.meta.walking_speed_mps} m/s walking speed.`);
  if (state.start?.type === 'gps') notes.push('Live re-routing is on: the route recalculates if you leave it.');
  box.append(h('p', { class: 'disclaimer' }, notes.join(' ')));
}

function focusStep(li, step) {
  document.querySelectorAll('.steps li.active').forEach((x) => x.classList.remove('active'));
  li.classList.add('active');
  map.setView([step.lat, step.lng], Math.max(map.getZoom(), 19));
  collapsePanel(true);
}

function reportBlocked(step) {
  state.avoidEdges = [...new Set([...state.avoidEdges, ...step.edge_ids])];
  toast('Thanks — finding a route that avoids that segment.');
  calculate();
}

// ------------------------------------------------------------------ turn-by-turn navigation
function prepareNav(route) {
  const g = route.geometry;
  nav.route = route;
  nav.cum = [0];
  for (let i = 1; i < g.length; i++) nav.cum[i] = nav.cum[i - 1] + metres(g[i - 1].lat, g[i - 1].lng, g[i].lat, g[i].lng);
  nav.total = nav.cum[g.length - 1];
  // Each step starts at the geometry vertex whose node it names (same lat/lng/floor, in order).
  let from = 0;
  nav.startIdx = route.steps.map((st, i) => {
    if (i === 0) return 0;
    for (let j = from + 1; j < g.length; j++) {
      if (Math.abs(g[j].lat - st.lat) < 1e-9 && Math.abs(g[j].lng - st.lng) < 1e-9 && g[j].floor === st.floor) { from = j; return j; }
    }
    return from;
  });
  nav.startCum = nav.startIdx.map((i) => nav.cum[i]);
  nav.startCum[nav.startCum.length - 1] = nav.total; // the arrival step sits at the very end
}

function posAt(s) {
  const g = nav.route.geometry;
  if (s <= 0) return { ...g[0], seg: 0 };
  if (s >= nav.total) return { ...g[g.length - 1], seg: g.length - 2 };
  let i = 0;
  while (i + 1 < g.length - 1 && nav.cum[i + 1] <= s) i++;
  const span = nav.cum[i + 1] - nav.cum[i];
  const t = span > 0 ? (s - nav.cum[i]) / span : 0;
  return {
    lat: g[i].lat + t * (g[i + 1].lat - g[i].lat), lng: g[i].lng + t * (g[i + 1].lng - g[i].lng),
    floor: t < 1 ? g[i].floor : g[i + 1].floor, outdoor: g[i].outdoor && g[i + 1].outdoor, seg: i,
  };
}

function projectOnRoute(lat, lng) {
  const g = nav.route.geometry;
  let best = null;
  for (let i = 0; i + 1 < g.length; i++) {
    if (!g[i].outdoor || !g[i + 1].outdoor) continue;
    const [ax, ay] = project(g[i].lat, g[i].lng, lat, lng);
    const [bx, by] = project(g[i + 1].lat, g[i + 1].lng, lat, lng);
    const dx = bx - ax, dy = by - ay;
    const len2 = dx * dx + dy * dy;
    const t = len2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / len2)) : 0;
    const d = Math.hypot(ax + t * dx, ay + t * dy);
    if (!best || d < best.d) best = { d, s: nav.cum[i] + t * (nav.cum[i + 1] - nav.cum[i]) };
  }
  return best;
}

function startNav() {
  const route = state.result?.routes[state.selected];
  if (!route) return;
  prepareNav(route);
  nav.on = true;
  nav.s = 0; nav.k = 0; nav.dwell = 0; nav.spoken = '';
  nav.follow = state.start?.type === 'gps' && !state.simulate;
  nav.playing = !nav.follow;
  $('view-map').classList.add('navigating');
  document.body.classList.add('is-navigating');
  $('nav-banner').hidden = false;
  $('nav-bar').hidden = false;
  $('fab-start').hidden = true;
  $('nav-play').hidden = nav.follow;
  setPlaying(nav.playing);
  youLayer.clearLayers();
  map.invalidateSize();
  map.setView([route.geometry[0].lat, route.geometry[0].lng], 19);
  nav.lastTick = performance.now();
  clearInterval(nav.timer);
  nav.timer = setInterval(tick, 100);
  render(true);
  if (!nav.follow) toast('Walking preview: watch the route, or use the arrows to jump between steps.', 4500);
}

function exitNav() {
  clearInterval(nav.timer);
  nav.on = false;
  if (walkerMarker) { walkerMarker.remove(); walkerMarker = null; }
  window.speechSynthesis?.cancel();
  $('view-map').classList.remove('navigating');
  document.body.classList.remove('is-navigating');
  $('nav-banner').hidden = true;
  $('nav-bar').hidden = true;
  $('arrived').hidden = true;
  map.invalidateSize();
  if (state.result) { renderResults(); drawRoute(true); }
}

function setPlaying(on) {
  nav.playing = on;
  const b = $('nav-play');
  b.setAttribute('aria-pressed', String(on));
  b.setAttribute('aria-label', on ? 'Pause walking preview' : 'Play walking preview');
  b.replaceChildren(icon(on ? 'pause' : 'play', { size: 20 }));
}

function setVoice(on) {
  nav.voice = on && 'speechSynthesis' in window;
  const b = $('nav-voice');
  b.setAttribute('aria-pressed', String(nav.voice));
  b.replaceChildren(icon(nav.voice ? 'volume' : 'volume-off', { size: 20 }));
  if (!nav.voice) window.speechSynthesis?.cancel();
  else nav.spoken = '';
  if (on && !('speechSynthesis' in window)) toast('Voice guidance is not supported in this browser.');
}

function gotoStep(i) {
  const n = nav.route.steps.length;
  if (i >= n - 1) { nav.k = n - 1; nav.s = nav.total; arrive(); return; }
  nav.k = Math.max(0, i);
  nav.s = nav.startCum[nav.k];
  nav.dwell = 0;
  render(true);
}

function tick() {
  const now = performance.now();
  const dt = Math.min(0.5, (now - nav.lastTick) / 1000);
  nav.lastTick = now;
  if (!nav.on || !$('arrived').hidden) return;
  if (nav.dwell > 0) { nav.dwell -= dt; if (nav.dwell > 0) return; }
  if (nav.playing && !nav.follow) {
    nav.s = Math.min(nav.total, nav.s + NAV_PREVIEW_SPEED * dt);
    advance();
    render(false);
  }
}

/** Move to the step the walker is in. Pauses briefly at doors, stairs and lifts (zero-length legs). */
function advance() {
  const n = nav.route.steps.length;
  while (nav.k + 1 < n && nav.startCum[nav.k + 1] <= nav.s + 0.01) {
    nav.k++;
    if (nav.k === n - 1) { arrive(); return; }
    if (nav.startCum[nav.k + 1] - nav.startCum[nav.k] < 0.5 && nav.playing && !nav.follow) {
      nav.s = nav.startCum[nav.k];
      nav.dwell = NAV_DWELL_S;
      return;
    }
  }
}

function arrive() {
  render(true);
  $('arrived-title').textContent = `You have arrived`;
  const d = state.dest;
  $('arrived-text').textContent = d ? `${d.name}${d.room_number ? ` · room ${d.room_number}` : ''}${d.building ? ` · ${fmt.floor(d.floor)}` : ''}` : '';
  $('arrived').hidden = false;
  speak('You have arrived at your destination.');
}

function speak(text) {
  if (!nav.voice || nav.spoken === text) return;
  nav.spoken = text;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
}

function render(recenter) {
  if (!nav.on) return;
  const route = nav.route;
  const steps = route.steps;
  const n = steps.length;
  const k = Math.min(nav.k, n - 1);
  const stepLen = (nav.startCum[k + 1] ?? nav.total) - nav.startCum[k];
  const into = nav.s - nav.startCum[k];
  // Show the current leg as "Now" right after it starts (or at doors/stairs/lifts); otherwise the upcoming maneuver.
  const showCurrent = into < 4 || stepLen < 0.5 || k >= n - 1;
  const m = showCurrent ? k : Math.min(k + 1, n - 1);
  const dist = showCurrent ? 'Now' : fmt.distance(Math.max(0, nav.startCum[k + 1] - nav.s));
  const step = steps[m];
  $('nav-ico').replaceChildren(icon(stepIconName(step), { size: 38 }));
  $('nav-dist').textContent = dist;
  $('nav-instr').textContent = step.text;
  const next = steps[m + 1];
  $('nav-then').hidden = !next;
  $('nav-then-text').textContent = next ? `Then: ${next.text}` : '';
  const pos = posAt(nav.s);
  const floorChip = $('nav-floor');
  floorChip.hidden = pos.outdoor !== false;
  if (!floorChip.hidden) floorChip.textContent = fmt.floor(pos.floor);

  const frac = nav.total > 0 ? 1 - nav.s / nav.total : 0;
  const remainS = route.duration_s * frac;
  $('nav-eta').textContent = frac <= 0 ? 'Arrived' : fmt.duration(remainS);
  const arriveAt = new Date(Date.now() + remainS * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  $('nav-remaining').textContent = `${fmt.distance(route.distance_m * frac)} · arrive ${arriveAt}`;

  // Map: travelled part faded, remaining part bold, walker marker follows.
  routeLayer.clearLayers();
  const g = route.geometry;
  drawRouteLine(g, pos.seg + 1, '#1a73e8');
  const done = g.slice(0, pos.seg + 1).concat([{ lat: pos.lat, lng: pos.lng, floor: pos.floor, outdoor: pos.outdoor }]);
  for (let i = 0; i + 1 < done.length; i++) L.polyline([[done[i].lat, done[i].lng], [done[i + 1].lat, done[i + 1].lng]], { color: '#8a9a8f', weight: 6, opacity: 0.8, interactive: false }).addTo(routeLayer);
  L.polyline([[pos.lat, pos.lng], [g[Math.min(pos.seg + 1, g.length - 1)].lat, g[Math.min(pos.seg + 1, g.length - 1)].lng]], { color: '#1a73e8', weight: 6, interactive: false }).addTo(routeLayer);
  addFloorTags(g);
  const ll = [pos.lat, pos.lng];
  if (!walkerMarker) walkerMarker = L.marker(ll, { icon: L.divIcon({ className: '', html: '<div class="you-dot"></div>', iconSize: [20, 20], iconAnchor: [10, 10] }), keyboard: false, zIndexOffset: 2000 }).addTo(map);
  else walkerMarker.setLatLng(ll);
  if (recenter || nav.playing || nav.follow) map.panTo(ll, { animate: true, duration: 0.25, easeLinearity: 1 });
  speak(`${showCurrent ? '' : `In ${dist}, `}${step.text}`);
}

// ------------------------------------------------------------------ persistence
function persist() {
  try {
    const start = state.start && state.start.type !== 'gps'
      ? { type: state.start.type, lat: state.start.lat, lng: state.start.lng, label: state.start.label, locationId: state.start.location?.id }
      : null;
    sessionStorage.setItem(STORE_KEY, JSON.stringify({
      dataset: state.meta?.dataset?.name,   // saved state only applies to the map it was made on
      destId: state.dest?.id ?? null, eventId: state.event?.id ?? null, start, profile: state.profile, avoidStairs: state.avoidStairs,
    }));
  } catch { /* storage unavailable: state just isn't remembered */ }
}

async function restore() {
  let saved;
  try { saved = JSON.parse(sessionStorage.getItem(STORE_KEY) || 'null'); } catch { saved = null; }
  if (!saved) return;
  if (saved.dataset !== state.meta.dataset.name) {   // made on another map (e.g. an older demo campus): discard it
    try { sessionStorage.removeItem(STORE_KEY); } catch { /* ignore */ }
    return;
  }
  state.profile = saved.profile === 'fastest' ? 'fastest' : 'shortest';
  state.avoidStairs = !!saved.avoidStairs;
  document.querySelector(`input[name="profile"][value="${state.profile}"]`).checked = true;
  $('avoid-stairs').checked = state.avoidStairs;
  if (saved.start) {
    if (saved.start.type === 'location' && saved.start.locationId) {
      const loc = locationsCache?.find((l) => l.id === saved.start.locationId);
      if (loc) state.start = { type: 'location', location: loc, lat: loc.lat, lng: loc.lng, label: loc.name };
    } else if (saved.start.type === 'point') {
      try {   // only keep a remembered point if it is still on the mapped campus
        const near = await api.nearest(saved.start.lat, saved.start.lng);
        if (near.within_campus) state.start = { type: 'point', lat: saved.start.lat, lng: saved.start.lng, label: saved.start.label };
      } catch { /* ignore */ }
    }
    if (state.start) setStartStatus(`From: ${state.start.label}`);
  }
  // A destination in the URL wins over the remembered one (handled by showMap).
  const hasUrlDest = new URLSearchParams(location.hash.split('?')[1] || '').has('to');
  if (saved.destId && !hasUrlDest) {
    try {
      if (saved.eventId) state.event = await api.event(saved.eventId).catch(() => null);
      setDestination(await api.location(saved.destId), { keepEvent: true });
    } catch { /* location removed since: ignore */ }
  } else {
    drawMarkers();
  }
}
