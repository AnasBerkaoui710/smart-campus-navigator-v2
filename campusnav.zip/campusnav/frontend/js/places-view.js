// Home and Places pages.
import { api } from './api.js';
import { eventCard, emptyState } from './events-view.js';
import { icon, typeIcon } from './icons.js';
import { setAvoidStairs } from './map-view.js';
import { Combobox, debounce, fmt, h, locationSub } from './ui.js';

const $ = (id) => document.getElementById(id);
const go = (loc) => { location.hash = `#/map?to=${loc.id}`; };

export function placeCard(loc) {
  return h('article', { class: 'place-card' },
    h('div', { class: 'top' },
      h('div', { class: 'place-ico' }, icon(typeIcon(loc.type), { size: 24 })),
      h('div', {}, h('h3', {}, loc.name), h('div', { class: 'meta' }, locationSub(loc)))),
    !loc.is_open ? h('span', { class: 'badge badge-danger', style: { alignSelf: 'start' } }, 'Temporarily unavailable') : '',
    h('button', { class: 'btn btn-primary btn-sm', type: 'button', disabled: !loc.is_open, onclick: () => go(loc),
      'aria-label': `Get directions to ${loc.name}` }, icon('navigation', { size: 16 }), 'Directions'));
}

// ------------------------------------------------------------------ home
let homeLoaded = false;
export async function showHome() {
  if (homeLoaded) return;
  homeLoaded = true;
  new Combobox($('hero-input'), {
    fetchItems: async (q) => (await api.locations({ q, limit: 8 })).map((loc) => ({ label: loc.name, sub: locationSub(loc), icon: typeIcon(loc.type), value: loc })),
    onSelect: (item) => go(item.value),
  });
  const chips = [['coffee', 'Cafeteria', 'cafeteria'], ['library', 'Library', 'library'], ['flask', 'Labs', 'laboratory'], ['monitor', 'Computer labs', 'computer_lab'], ['briefcase', 'Offices', 'office']];
  $('hero-chips').replaceChildren(...chips.map(([ic, label, type]) => h('button', {
    class: 'chip', type: 'button', onclick: () => { location.hash = `#/places?type=${type}`; },
  }, icon(ic, { size: 16 }), label)));
  $('quick-stepfree').addEventListener('click', () => { setAvoidStairs(true); });

  const [events, places] = await Promise.all([api.events({ when: 'upcoming' }).catch(() => []), api.locations({ limit: 200 }).catch(() => [])]);
  $('home-events').replaceChildren(...(events.length
    ? events.slice(0, 3).map(eventCard)
    : [emptyState('calendar', 'No upcoming events', 'Check back soon.')]));
  const wanted = ['lib', 'amp', 'caf', 'adm', 'dmi', 'dbg'];
  const featured = wanted.map((c) => places.find((p) => p.code === c)).filter(Boolean);
  $('home-places').replaceChildren(...(featured.length ? featured : places.slice(0, 6)).map(placeCard));
}

// ------------------------------------------------------------------ places
let placesInit = false;
let activeType = '';
let reqId = 0;

async function loadPlaces() {
  const req = ++reqId;
  const grid = $('places-grid');
  grid.setAttribute('aria-busy', 'true');
  try {
    const items = await api.locations({ q: $('pl-q').value.trim(), type: activeType, limit: 200 });
    if (req !== reqId) return;
    $('places-count').textContent = `${items.length} place${items.length === 1 ? '' : 's'}`;
    grid.replaceChildren(...(items.length ? items.map(placeCard)
      : [emptyState('search', 'No places found', 'Try another name, room number or type.')]));
  } catch (e) {
    if (req !== reqId) return;
    grid.replaceChildren(emptyState('alert', 'Places could not be loaded', e.message,
      h('button', { class: 'btn', type: 'button', onclick: loadPlaces }, 'Try again')));
  } finally {
    grid.removeAttribute('aria-busy');
  }
}

function renderTypeChips(types) {
  $('pl-types').replaceChildren(...[['', 'All'], ...types.map((t) => [t, fmt.type(t)])].map(([value, label]) => h('button', {
    class: 'chip', type: 'button', 'aria-pressed': String(value === activeType),
    onclick: () => { activeType = value; renderTypeChips(types); loadPlaces(); },
  }, value ? icon(typeIcon(value), { size: 16 }) : '', label)));
}

export async function showPlaces(params) {
  if (!placesInit) {
    placesInit = true;
    $('pl-q').addEventListener('input', debounce(loadPlaces, 250));
    const meta = await api.meta().catch(() => ({ location_types: [] }));
    $('pl-types').dataset.types = JSON.stringify(meta.location_types);
  }
  const types = JSON.parse($('pl-types').dataset.types || '[]');
  activeType = params.get('type') || '';
  renderTypeChips(types);
  await loadPlaces();
}
