// Entry point: loads metadata, wires the hash router and the global search.
import { api } from './api.js';
import { initEvents, showEvents } from './events-view.js';
import { CATEGORY_ICON, hydrateIcons, typeIcon } from './icons.js';
import { initMap, setDestination, showMap } from './map-view.js';
import { initAssistant, showAssistant } from './assistant.js';
import { showHome, showPlaces } from './places-view.js';
import { Combobox, fmt, h, locationSub } from './ui.js';

const $ = (id) => document.getElementById(id);

// Routes: #/map[?to=<locationId>&event=<eventId>] · #/events · #/events/<id>
const SECTIONS = ['home', 'map', 'events', 'places', 'assistant'];
function parseHash() {
  const [path, query] = (location.hash.slice(1) || '/home').split('?');
  const parts = path.split('/').filter(Boolean);
  return { section: SECTIONS.includes(parts[0]) ? parts[0] : 'home', id: parts[1], params: new URLSearchParams(query || '') };
}

const TITLES = { home: 'Home', map: 'Campus map', events: 'Events', places: 'Places', assistant: 'AI assistant' };
async function route() {
  const { section, id, params } = parseHash();
  document.body.dataset.section = section;
  for (const s of SECTIONS) $(`view-${s}`).hidden = s !== section;
  $('main').scrollTop = 0;
  document.querySelectorAll('[data-nav]').forEach((a) => {
    if (a.dataset.nav === section) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  document.title = `${TITLES[section]} — CampusNav`;
  if (section === 'map') await showMap(params);
  else if (section === 'events') await showEvents(id);
  else if (section === 'places') await showPlaces(params);
  else if (section === 'assistant') showAssistant();
  else await showHome();
}

function initGlobalSearch() {
  new Combobox($('global-search-input'), {
    fetchItems: async (q) => {
      const [locs, events] = await Promise.all([
        api.locations({ q, limit: 6 }).catch(() => []),
        api.events({ q, when: 'upcoming' }).catch(() => []),
      ]);
      return [
        ...locs.map((loc) => ({ group: 'Places', label: loc.name, sub: locationSub(loc), icon: typeIcon(loc.type), value: { kind: 'loc', loc } })),
        ...events.slice(0, 5).map((ev) => ({
          group: 'Events', label: ev.title, sub: `${fmt.date(ev.starts_at)} · ${ev.venue.name}`, icon: CATEGORY_ICON[ev.category.slug] || 'calendar', value: { kind: 'event', ev },
        })),
      ];
    },
    onSelect: (item) => {
      $('global-search-input').value = '';
      if (item.value.kind === 'loc') {
        if (parseHash().section !== 'map') location.hash = `#/map?to=${item.value.loc.id}`;
        else setDestination(item.value.loc);
      } else {
        location.hash = `#/events/${item.value.ev.id}`;
      }
    },
  });
}

async function main() {
  hydrateIcons();
  let meta;
  try {
    meta = await api.meta();
  } catch (e) {
    document.querySelector('main').replaceChildren(h('div', { class: 'empty-state', role: 'alert' },
      h('h1', {}, 'CampusNav is unavailable'), h('p', {}, e.message),
      h('button', { class: 'btn', type: 'button', onclick: () => location.reload() }, 'Reload')));
    return;
  }
  $('dataset-name').textContent = meta.dataset.name || 'Campus';
  $('sample-badge').hidden = !meta.dataset.is_sample;

  $('event-dialog').addEventListener('close', () => {
    if (/^#\/events\/\d+/.test(location.hash)) history.replaceState(null, '', '#/events');
  });

  initGlobalSearch();
  await Promise.all([initMap(meta), initEvents()]);
  initAssistant();
  window.addEventListener('hashchange', route);
  await route();
}

main();

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
