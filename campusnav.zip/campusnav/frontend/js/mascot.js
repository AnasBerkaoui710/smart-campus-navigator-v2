// Ghoula, the CampusNav mascot. The artwork and its animations live in /icons/ghoula.svg and are inlined here
// so the animation state can be switched with data-state:
//   idle · watching (student is typing) · thinking · typing (writing the answer) · speaking · listening · done · oops
import { h } from './ui.js';

let template = '';
const FULL_BOX = 'viewBox="-6 0 152 170"';
const HEAD_BOX = 'viewBox="14 0 112 100"';

export async function loadMascot() {
  if (template) return;
  try { template = await (await fetch('/icons/ghoula.svg')).text(); } catch { template = ''; }
}

/** A mascot element. `mini` shows just the (static) face, for chat bubbles. */
export function mascot(state = 'idle', { size = 56, mini = false } = {}) {
  const el = h('span', { class: `mascot${mini ? ' mini' : ''}`, style: { width: `${size}px`, height: `${mini ? size : Math.round((size * 170) / 152)}px` } });
  if (!template) return el;
  let svg = template.replace(/<\?xml[^>]*\?>/, '');
  if (mini) svg = svg.replace(FULL_BOX, HEAD_BOX).replace('class="ghoula"', 'class="ghoula" data-static');
  el.innerHTML = svg; // our own static asset
  el.firstElementChild?.setAttribute('data-state', state);
  return el;
}

export function setMascotState(root, state) {
  root.querySelectorAll('.mascot:not(.mini) > svg').forEach((s) => {
    if (s.getAttribute('data-state') !== state) s.setAttribute('data-state', state);
  });
}
