// AI assistant "Ghoula": streaming chat (Gemini via the server), voice in/out, conversation history,
// auto titles, and actions that drive the app (redirects, map and navigation control).
import { api } from './api.js';
import { icon } from './icons.js';
import { getMapContext, mapControl, navControl, routeOptions } from './map-view.js';
import { loadMascot, mascot, setMascotState } from './mascot.js';
import { h, toast } from './ui.js';

const STORE = 'campusnav.chats.v2';
const MAX_CHATS = 30;
const SUGGESTIONS = [
  'Take me to the library',
  'Where is the computer lab DMI-101?',
  'Step-free route to the cafeteria',
  'What events are happening this week?',
  'Je cherche la salle des actes',
  'Take me to the next conference and start',
];
const SILENT_WAV = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';

const state = {
  chats: [], currentId: null, busy: false, status: null, autoSpeak: false, speakThis: false,
  listening: false, thinking: false, speaking: false, typingUntil: 0, doneUntil: 0, oopsUntil: 0, busySince: 0,
};
const views = new Set();
let abort = null;
let drawerEl = null;
let fabMascot = null;
let moodTimer = null;

// ------------------------------------------------------------------ chats store (kept in this browser only)
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
function createChat() {
  const c = { id: uid(), title: '', titleAuto: false, created: Date.now(), updated: Date.now(), messages: [] };
  state.chats.unshift(c);
  state.currentId = c.id;
  return c;
}
const cur = () => state.chats.find((c) => c.id === state.currentId) || state.chats[0] || createChat();

function load() {
  try {
    const data = JSON.parse(localStorage.getItem(STORE) || 'null');
    state.chats = (data?.chats || []).filter((c) => c && Array.isArray(c.messages)).slice(0, MAX_CHATS);
    state.currentId = data?.currentId;
    state.autoSpeak = !!data?.autoSpeak;
  } catch { state.chats = []; }
  if (!state.chats.some((c) => c.id === state.currentId)) state.currentId = state.chats[0]?.id;
  cur();
}
function save() {
  try {
    const keep = state.chats.filter((c) => c.messages.length).slice(0, MAX_CHATS)
      .map((c) => ({ ...c, messages: c.messages.slice(-40).map(({ role, text, actions, error }) => ({ role, text, actions, error })) }));
    localStorage.setItem(STORE, JSON.stringify({ chats: keep, currentId: state.currentId, autoSpeak: state.autoSpeak }));
  } catch { /* storage unavailable: history just isn't kept */ }
}
const currentSection = () => (location.hash.slice(2).split(/[/?]/)[0] || 'home');
const titleOf = (c) => c.title || 'New chat';

function newChat() {
  stopSpeaking();
  const c = cur();
  if (!c.messages.length) { renderAll(); return; }   // already on an empty chat
  createChat();
  save();
  renderAll();
  [...views].forEach((v) => v.input.focus({ preventScroll: true }));
}
function openChat(id) {
  if (id === state.currentId) return;
  stopSpeaking();
  state.currentId = id;
  views.forEach((v) => { v.root.classList?.remove('side-open'); v.layout?.classList.remove('side-open'); });
  save();
  renderAll();
}
function deleteChat(id) {
  state.chats = state.chats.filter((c) => c.id !== id);
  if (state.currentId === id) state.currentId = state.chats[0]?.id;
  cur();
  save();
  renderAll();
}
function clearHistory() {
  if (!confirm('Delete all your conversations with Ghoula from this browser?')) return;
  stopSpeaking();
  abort?.abort();
  state.chats = [];
  createChat();
  save();
  renderAll();
}
const ago = (t) => {
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return 'now';
  if (m < 60) return `${m} min`;
  if (m < 1440) return `${Math.round(m / 60)} h`;
  return new Date(t).toLocaleDateString([], { day: 'numeric', month: 'short' });
};

// ------------------------------------------------------------------ mascot mood
function mood() {
  const now = Date.now();
  if (state.listening) return 'listening';
  if (state.thinking) return 'thinking';
  if (state.busy) return cur().messages.at(-1)?.text ? 'typing' : 'thinking';
  if (now < state.doneUntil) return 'done';
  if (now < state.oopsUntil) return 'oops';
  if (state.speaking) return 'speaking';
  if (now < state.typingUntil) return 'watching';
  return 'idle';
}
function scheduleMood(ms) {
  clearTimeout(moodTimer);
  moodTimer = setTimeout(renderAll, ms + 30);
}

// ------------------------------------------------------------------ rendering
function bubbleNode(m, last) {
  if (m.role === 'user') return h('div', { class: 'msg user' }, h('div', { class: 'bubble' }, m.text));
  const typing = !m.text && last && state.busy;
  return h('div', { class: `msg bot${m.error ? ' err' : ''}` },
    h('span', { class: 'avatar' }, mascot('idle', { size: 32, mini: true })),
    h('div', { class: 'bubble-wrap' },
      h('div', { class: `bubble${typing ? ' typing-b' : ''}` }, typing ? h('span', { class: 'typing' }, h('i'), h('i'), h('i')) : m.text),
      ...(m.actions || []).map((a) => h('span', { class: 'act-chip' }, icon(a.kind === 'navigate' ? 'navigation' : a.kind === 'nav' ? 'play' : a.kind === 'map' ? 'map' : 'accessibility', { size: 14 }), a.label))));
}

function statusLine() {
  if (state.listening) return 'Listening… speak now';
  if (state.thinking) return 'Understanding your voice…';
  if (state.busy) {
    if (cur().messages.at(-1)?.text) return 'Ghoula is typing…';
    return Date.now() - state.busySince > 7000 ? 'The AI service is busy, trying again…' : 'Ghoula is thinking…';
  }
  if (state.speaking) return 'Speaking…';
  return '';
}

function renderHistory(v) {
  const list = [...state.chats].filter((c) => c.messages.length).sort((a, b) => b.updated - a.updated);
  v.history.replaceChildren(...(list.length ? list.map((c) => h('div', { class: `hist-item${c.id === state.currentId ? ' active' : ''}` },
    h('button', { type: 'button', class: 'hist-open', onclick: () => openChat(c.id), 'aria-current': c.id === state.currentId ? 'true' : null },
      h('span', { class: 'hist-title' }, titleOf(c)), h('small', {}, `${ago(c.updated)} · ${c.messages.filter((m) => m.role === 'user').length} msg`)),
    h('button', { type: 'button', class: 'icon-btn-sm hist-del', 'aria-label': `Delete conversation ${titleOf(c)}`, title: 'Delete', onclick: () => deleteChat(c.id) }, icon('trash', { size: 16 }))))
    : [h('p', { class: 'hist-empty' }, 'Your conversations will appear here.')]));
}

function renderView(v) {
  const chat = cur();
  const stick = v.list.scrollHeight - v.list.scrollTop - v.list.clientHeight < 80;
  const m = mood();
  v.list.replaceChildren();
  if (!chat.messages.length) {
    v.list.append(h('div', { class: 'chat-empty' },
      mascot(m, { size: v.mode === 'mini' ? 110 : 150 }),
      h('h3', {}, 'Hi, I\'m Ghoula'),
      h('p', {}, 'Your campus buddy. I find places and events, open directions, control the map and start navigation for you. Type, or tap the microphone and just talk. English, Français, العربية.'),
      h('div', { class: 'sugg' }, SUGGESTIONS.slice(0, v.mode === 'mini' ? 4 : 6).map((s) => h('button', { type: 'button', class: 'chip', onclick: () => send(s) }, s)))));
  } else {
    chat.messages.forEach((msg, i) => v.list.append(bubbleNode(msg, i === chat.messages.length - 1)));
  }
  if (stick) v.list.scrollTop = v.list.scrollHeight;
  const line = statusLine();
  v.status.textContent = line;
  v.status.hidden = !line;
  v.title.textContent = chat.messages.length ? titleOf(chat) : 'Ghoula';
  v.mic.classList.toggle('listening', state.listening);
  v.mic.setAttribute('aria-pressed', String(state.listening));
  v.speaker.setAttribute('aria-pressed', String(state.autoSpeak));
  v.speaker.replaceChildren(icon(state.autoSpeak ? 'volume' : 'volume-off', { size: 18 }));
  v.speaker.title = state.autoSpeak ? 'Voice replies on' : 'Voice replies off';
  v.send.disabled = state.busy || !state.status?.available;
  v.input.disabled = !state.status?.available;
  v.notice.hidden = state.status === null || state.status.available;
  v.root.classList.toggle('is-speaking', state.speaking);
  if (v.history) renderHistory(v);
  setMascotState(v.root, m);
}
function renderAll() {
  views.forEach(renderView);
  const m = mood();
  if (fabMascot) setMascotState(fabMascot.parentElement, m);
  if (m === 'done') scheduleMood(Math.max(0, state.doneUntil - Date.now()));
  else if (m === 'oops') scheduleMood(Math.max(0, state.oopsUntil - Date.now()));
  else if (m === 'watching') scheduleMood(Math.max(0, state.typingUntil - Date.now()));
}

export function buildChat(mode) {
  const input = h('input', { type: 'text', class: 'chat-input', placeholder: 'Ask Ghoula anything about the campus…', autocomplete: 'off', maxlength: 500, 'aria-label': 'Message to Ghoula' });
  input.addEventListener('input', () => { state.typingUntil = Date.now() + 1500; renderAll(); });
  const send_ = h('button', { type: 'submit', class: 'icon-round primary', 'aria-label': 'Send' }, icon('arrow-right', { size: 20 }));
  const mic = h('button', { type: 'button', class: 'icon-round mic', 'aria-label': 'Talk to Ghoula', onclick: toggleMic }, icon('mic', { size: 20 }));
  const speaker = h('button', { type: 'button', class: 'icon-btn-sm', 'aria-label': 'Toggle voice replies', onclick: () => { state.autoSpeak = !state.autoSpeak; if (!state.autoSpeak) stopSpeaking(); save(); renderAll(); } });
  const status = h('div', { class: 'chat-status', 'aria-live': 'polite', hidden: true });
  const notice = h('div', { class: 'alert alert-warn', hidden: true }, icon('alert', { size: 18 }), h('span', {}, 'The assistant is not configured on this server (missing GEMINI_API_KEY).'));
  const list = h('div', { class: 'chat-list', role: 'log', 'aria-live': 'polite', 'aria-label': 'Conversation' });
  const form = h('form', { class: 'chat-form', onsubmit: (e) => { e.preventDefault(); const t = input.value; input.value = ''; state.typingUntil = 0; send(t); } }, mic, input, send_);
  const title = h('strong', {}, 'Ghoula');
  let layout = null;
  const head = h('div', { class: 'chat-head' },
    mode === 'page' ? h('button', { type: 'button', class: 'icon-btn-sm hist-toggle', 'aria-label': 'Conversation history', onclick: () => layout.classList.toggle('side-open') }, icon('list', { size: 20 })) : '',
    h('span', { class: 'avatar lg' }, mascot('idle', { size: 40 })),
    h('div', { class: 'ch-title' }, title, h('small', {}, 'AI campus assistant · Gemini')),
    speaker,
    h('button', { type: 'button', class: 'icon-btn-sm', 'aria-label': 'New chat', title: 'New chat', onclick: newChat }, icon('plus', { size: 20 })),
    mode === 'mini' ? h('a', { class: 'icon-btn-sm', href: '#/assistant', 'aria-label': 'Open the full page with history', title: 'Open full page', onclick: () => setDrawer(false) }, icon('arrow-right', { size: 18 })) : '',
    mode === 'mini' ? h('button', { type: 'button', class: 'icon-btn-sm', 'aria-label': 'Close assistant', onclick: () => setDrawer(false) }, icon('x', { size: 18 })) : '');
  const main = h('div', { class: 'chat-main' }, head, notice, list, status, form);
  const view = { mode, input, send: send_, mic, speaker, status, notice, list, title };
  let root = main;
  if (mode === 'page') {
    const history = h('div', { class: 'hist-list' });
    const side = h('aside', { class: 'chat-side', 'aria-label': 'Conversation history' },
      h('div', { class: 'side-head' }, h('strong', {}, 'History'),
        h('button', { type: 'button', class: 'icon-btn-sm side-close', 'aria-label': 'Close history', onclick: () => layout.classList.remove('side-open') }, icon('x', { size: 18 }))),
      h('button', { type: 'button', class: 'btn btn-primary new-chat', onclick: newChat }, icon('plus', { size: 18 }), 'New chat'),
      history,
      h('button', { type: 'button', class: 'link-btn clear-all', onclick: clearHistory }, 'Delete all conversations'),
      h('p', { class: 'hist-note' }, 'Saved in this browser only.'));
    layout = h('div', { class: 'chat-layout' }, side, main);
    root = layout;
    view.history = history;
    view.layout = layout;
  }
  view.root = root;
  views.add(view);
  renderView(view);
  return root;
}

// ------------------------------------------------------------------ drawer + page
export function setDrawer(open) {
  if (!drawerEl) return;
  drawerEl.hidden = !open;
  document.getElementById('assistant-fab').setAttribute('aria-expanded', String(open));
  if (open) {
    const v = [...views].find((x) => x.mode === 'mini');
    setTimeout(() => { v?.input.focus({ preventScroll: true }); if (v) v.list.scrollTop = v.list.scrollHeight; }, 30);
  }
}

export async function initAssistant() {
  load();
  await loadMascot();
  drawerEl = document.getElementById('assistant-drawer');
  document.getElementById('assistant-page-host').append(buildChat('page'));
  drawerEl.append(buildChat('mini'));
  const fab = document.getElementById('assistant-fab');
  fabMascot = mascot('idle', { size: 44 });
  fab.prepend(fabMascot);
  fab.addEventListener('click', () => setDrawer(drawerEl.hidden));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !drawerEl.hidden) setDrawer(false); });
  try { state.status = await api.get('/api/assistant/status'); } catch { state.status = { available: false }; }
  renderAll();
}

export function showAssistant() {
  setDrawer(false);
  const v = [...views].find((x) => x.mode === 'page');
  setTimeout(() => v?.input.focus({ preventScroll: true }), 50);
}

// ------------------------------------------------------------------ actions the model can trigger
async function ensureMap() {
  if (currentSection() !== 'map') {
    location.hash = '#/map';
    await new Promise((r) => setTimeout(r, 500));
  }
}

async function runAction(a) {
  try {
    if ((a.kind === 'navigate' || a.kind === 'open') && typeof a.hash === 'string' && a.hash.startsWith('#/')) {
      if (location.hash === a.hash) window.dispatchEvent(new HashChangeEvent('hashchange'));
      else location.hash = a.hash;
      setDrawer(false);
    } else if (a.kind === 'route_options') {
      await ensureMap();
      routeOptions(a);
    } else if (a.kind === 'nav') {
      await ensureMap();
      if (a.command === 'start' || window.matchMedia('(max-width: 820px)').matches) setDrawer(false);
      navControl(a.command);
    } else if (a.kind === 'map') {
      await ensureMap();
      if (window.matchMedia('(max-width: 820px)').matches) setDrawer(false);
      await mapControl(a.command, a.place_id);
    }
  } catch (e) { toast(e.message || 'Could not do that on the map.'); }
}

// ------------------------------------------------------------------ chat streaming
async function makeTitle(chat) {
  if (chat.titleAuto) return;
  const u = chat.messages.find((m) => m.role === 'user');
  const a = chat.messages.find((m) => m.role === 'assistant' && m.text && !m.error);
  if (!u || !a) return;
  chat.titleAuto = true;               // try once per conversation
  try {
    const r = await api.post('/api/assistant/title', { user: u.text, assistant: a.text.slice(0, 500) });
    if (r.title) chat.title = r.title;
  } catch { /* keep the provisional title */ }
  save();
  renderAll();
}

export async function send(text, { spoken = false } = {}) {
  text = (text || '').trim();
  if (!text || state.busy || !state.status?.available) return;
  stopSpeaking();
  unlockAudio();
  const chat = cur();
  chat.messages.push({ role: 'user', text });
  if (!chat.title) chat.title = text.length > 38 ? `${text.slice(0, 37)}…` : text;   // provisional, replaced by an AI title
  const bot = { role: 'assistant', text: '', actions: [] };
  chat.messages.push(bot);
  chat.updated = Date.now();
  state.busy = true;
  state.busySince = Date.now();
  scheduleMood(7100);                  // refresh the "busy" hint if the first words take long
  state.speakThis = spoken || state.autoSpeak;
  speechBuf = '';
  save();
  renderAll();
  const history = chat.messages.slice(0, -1).filter((m) => m.text).slice(-10).map((m) => ({ role: m.role, text: m.text }));
  abort = new AbortController();
  try {
    const res = await fetch('/api/assistant/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: abort.signal,
      body: JSON.stringify({ messages: history, context: { page: currentSection(), ...getMapContext() } }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => null);
      throw new Error(err?.error?.message || 'The assistant is unavailable right now.');
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const line = buf.slice(0, i);
        buf = buf.slice(i + 2);
        if (!line.startsWith('data: ')) continue;
        let ev;
        try { ev = JSON.parse(line.slice(6)); } catch { continue; }
        if (ev.type === 'text') { bot.text += ev.text; pushSpeech(ev.text); } else if (ev.type === 'action') { bot.actions.push(ev); runAction(ev); } else if (ev.type === 'error') { bot.text += (bot.text ? '\n' : '') + ev.message; bot.error = true; }
        renderAll();
      }
    }
  } catch (e) {
    if (e.name !== 'AbortError') { bot.text = bot.text || e.message; bot.error = true; }
  } finally {
    flushSpeech();
    state.busy = false;
    if (!bot.text) bot.text = 'Done.';
    chat.updated = Date.now();
    if (bot.error) state.oopsUntil = Date.now() + 3000;
    else state.doneUntil = Date.now() + 2600;
    save();
    renderAll();
    if (!bot.error) makeTitle(chat);
  }
}

// ------------------------------------------------------------------ voice out (Gemini TTS, browser fallback)
let speechBuf = '';
let jobs = [];
let gen = 0;
let playing = false;
let resolvePlay = null;
let audioEl = null;

function unlockAudio() {
  if (!audioEl) audioEl = new Audio();
  audioEl.src = SILENT_WAV;
  audioEl.play().catch(() => {});
}

function pushSpeech(t) {
  if (!state.speakThis) return;
  speechBuf += t;
  const parts = speechBuf.split(/(?<=[.!?؟…])\s+/);
  speechBuf = parts.pop();
  parts.forEach(enqueueSpeech);
}
function flushSpeech() {
  if (state.speakThis && speechBuf.trim()) enqueueSpeech(speechBuf);
  speechBuf = '';
}

async function fetchAudio(text) {
  try {
    const r = await fetch('/api/assistant/speak', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
    if (!r.ok) return null;
    return URL.createObjectURL(await r.blob());
  } catch { return null; }
}

function enqueueSpeech(text) {
  text = text.trim();
  if (text.length < 2) return;
  jobs.push({ text, promise: fetchAudio(text), gen });
  if (!playing) playLoop();
}

function playUrl(url) {
  return new Promise((resolve) => {
    resolvePlay = resolve;
    audioEl.onended = audioEl.onerror = () => { resolvePlay = null; resolve(); };
    audioEl.src = url;
    audioEl.play().catch(() => { resolvePlay = null; resolve(); });
  });
}

function browserSpeak(text) {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) return resolve();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = /[؀-ۿ]/.test(text) ? 'ar' : (navigator.language || 'en-US');
    u.onend = u.onerror = () => resolve();
    resolvePlay = resolve;
    window.speechSynthesis.speak(u);
  });
}

async function playLoop() {
  playing = true;
  state.speaking = true;
  renderAll();
  while (jobs.length) {
    const job = jobs.shift();
    if (job.gen !== gen) { job.promise.then((u) => u && URL.revokeObjectURL(u)); continue; }
    const url = await job.promise;
    if (job.gen !== gen) { if (url) URL.revokeObjectURL(url); continue; }
    if (url) { await playUrl(url); URL.revokeObjectURL(url); } else await browserSpeak(job.text);
  }
  playing = false;
  state.speaking = false;
  renderAll();
}

export function stopSpeaking() {
  gen += 1;
  jobs = [];
  speechBuf = '';
  if (audioEl) audioEl.pause();
  window.speechSynthesis?.cancel();
  if (resolvePlay) { const r = resolvePlay; resolvePlay = null; r(); }
}

// ------------------------------------------------------------------ voice in (record -> Gemini transcription)
let rec = null;

function bytesToBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

async function toWavBase64(blob) {
  const AC = window.AudioContext || window.webkitAudioContext;
  const ctx = new AC();
  const decoded = await ctx.decodeAudioData(await blob.arrayBuffer());
  ctx.close();
  const off = new OfflineAudioContext(1, Math.max(1, Math.ceil(decoded.duration * 16000)), 16000);
  const src = off.createBufferSource();
  src.buffer = decoded;
  src.connect(off.destination);
  src.start();
  const data = (await off.startRendering()).getChannelData(0);
  const wav = new DataView(new ArrayBuffer(44 + data.length * 2));
  const w = (o, s) => [...s].forEach((c, i) => wav.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); wav.setUint32(4, 36 + data.length * 2, true); w(8, 'WAVEfmt '); wav.setUint32(16, 16, true);
  wav.setUint16(20, 1, true); wav.setUint16(22, 1, true); wav.setUint32(24, 16000, true); wav.setUint32(28, 32000, true);
  wav.setUint16(32, 2, true); wav.setUint16(34, 16, true); w(36, 'data'); wav.setUint32(40, data.length * 2, true);
  for (let i = 0; i < data.length; i++) wav.setInt16(44 + i * 2, Math.max(-1, Math.min(1, data[i])) * 32767, true);
  return bytesToBase64(new Uint8Array(wav.buffer));
}

async function toggleMic() {
  if (state.listening) { rec?.finish(); return; }
  if (state.busy || state.thinking || !state.status?.available) return;
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { toast('Voice input is not supported in this browser. Please type your request.'); return; }
  stopSpeaking();
  unlockAudio();
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch {
    toast('Microphone access was denied. Allow it in the browser address bar, or type your request.', 6000);
    return;
  }
  const AC = window.AudioContext || window.webkitAudioContext;
  const ctx = new AC();
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 1024;
  ctx.createMediaStreamSource(stream).connect(analyser);
  const samples = new Uint8Array(analyser.fftSize);
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  const t0 = performance.now();
  let spoke = false;
  let lastVoice = t0;
  let cancelled = false;
  recorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
  const tick = setInterval(() => {
    analyser.getByteTimeDomainData(samples);
    let sum = 0;
    for (const s of samples) { const x = (s - 128) / 128; sum += x * x; }
    const now = performance.now();
    if (Math.sqrt(sum / samples.length) > 0.035) { spoke = true; lastVoice = now; }
    if ((spoke && now - lastVoice > 1300) || now - t0 > 15000 || (!spoke && now - t0 > 7000)) rec?.finish();
  }, 80);
  const finish = () => { if (recorder.state !== 'inactive') recorder.stop(); };
  rec = { finish, cancel: () => { cancelled = true; finish(); } };
  recorder.onstop = async () => {
    clearInterval(tick);
    stream.getTracks().forEach((t) => t.stop());
    ctx.close();
    rec = null;
    state.listening = false;
    if (cancelled || !spoke || !chunks.length) { if (!cancelled) toast("I didn't hear anything. Tap the microphone and try again."); renderAll(); return; }
    state.thinking = true;
    renderAll();
    try {
      const audio = await toWavBase64(new Blob(chunks, { type: recorder.mimeType }));
      const out = await api.post('/api/assistant/transcribe', { audio, mime_type: 'audio/wav' });
      state.thinking = false;
      renderAll();
      if (out.text) send(out.text, { spoken: true });
      else toast("I couldn't make out what you said. Please try again.");
    } catch (e) {
      state.thinking = false;
      state.oopsUntil = Date.now() + 3000;
      toast(e.message || 'Voice input failed. Please type your request.', 5000);
      renderAll();
    }
  };
  recorder.start();
  state.listening = true;
  renderAll();
}
