// Events section: filterable cards, detail dialog, "Navigate to Event".
import { api } from './api.js';
import { CATEGORY_ICON, icon } from './icons.js';
import { debounce, fmt, h } from './ui.js';

const $ = (id) => document.getElementById(id);
let loaded = false;
let reqId = 0;

export function navigateToEvent(ev) {
  // The map view reads `to` + `event`, sets the venue as destination and locates the user.
  const dialog = $('event-dialog');
  if (dialog.open) dialog.close();
  location.hash = `#/map?to=${ev.venue.id}&event=${ev.id}`;
}

export async function initEvents() {
  const cats = await api.categories().catch(() => []);
  for (const c of cats) $('ev-cat').append(h('option', { value: c.slug }, c.name));
  const reload = debounce(load, 250);
  $('ev-q').addEventListener('input', reload);
  $('ev-cat').addEventListener('change', load);
  $('ev-when').addEventListener('change', load);
  $('events-filters').addEventListener('submit', (e) => { e.preventDefault(); load(); });
  $('event-dialog').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
}

export async function showEvents(eventId) {
  if (!loaded) {
    loaded = true;
    await load();
  }
  if (eventId) openEvent(eventId);
}

export function emptyState(iconName, title, text, action) {
  return h('div', { class: 'empty-state' },
    h('div', { class: 'e-ico' }, icon(iconName, { size: 34 })),
    h('h2', {}, title), h('p', {}, text), action || '');
}

async function load() {
  const grid = $('events-grid');
  const req = ++reqId;
  grid.setAttribute('aria-busy', 'true');
  grid.replaceChildren(...Array.from({ length: 6 }, () => h('div', { class: 'skeleton', 'aria-hidden': 'true' })));
  try {
    const events = await api.events({ q: $('ev-q').value.trim(), category: $('ev-cat').value, when: $('ev-when').value });
    if (req !== reqId) return;
    $('events-count').textContent = `${events.length} event${events.length === 1 ? '' : 's'}`;
    grid.replaceChildren();
    if (!events.length) grid.append(emptyState('calendar', 'No events found', 'Try another search term, category or date range.'));
    for (const ev of events) grid.append(card(ev));
  } catch (e) {
    if (req !== reqId) return;
    grid.replaceChildren(emptyState('alert', 'Events could not be loaded', e.message,
      h('button', { class: 'btn', type: 'button', onclick: load }, 'Try again')));
  } finally {
    if (req === reqId) grid.removeAttribute('aria-busy');
  }
}

function venueText(v) {
  const parts = [v.name];
  if (v.building && v.building.name !== v.name) parts.push(v.building.name);
  if (v.building) parts.push(fmt.floor(v.floor));
  return parts.join(', ');
}

function media(ev) {
  const c = ev.category.color;
  const style = ev.image_url
    ? { backgroundImage: `linear-gradient(transparent 40%, rgb(0 0 0 / .45)), url("${encodeURI(ev.image_url)}")` }
    : { background: `linear-gradient(135deg, ${c}, ${c}d9 55%, #11301d)` };
  const d = new Date(ev.starts_at);
  return h('div', { class: 'event-media', style },
    h('div', { class: 'date-block' },
      h('span', {}, fmt.date(ev.starts_at, { month: 'short' })),
      h('b', {}, String(d.getDate())),
      h('span', {}, fmt.date(ev.starts_at, { weekday: 'short' }))),
    ev.image_url ? '' : h('span', { class: 'm-ico' }, icon(CATEGORY_ICON[ev.category.slug] || 'calendar', { size: 54 })),
    h('span', { class: 'badge cat' }, ev.category.name));
}

const fact = (name, text) => h('li', {}, icon(name, { size: 16 }), h('span', {}, text));
const navBtn = (ev, label = 'Navigate to event') => h('button', {
  class: 'btn btn-primary', type: 'button', onclick: () => navigateToEvent(ev), 'aria-label': `Navigate to ${ev.title}`,
}, icon('navigation', { size: 18 }), label);

export function eventCard(ev) {
  return h('article', { class: 'event-card', 'aria-labelledby': `ev-${ev.id}` },
    media(ev),
    h('div', { class: 'event-body' },
      h('h2', { id: `ev-${ev.id}` }, h('button', { type: 'button', onclick: () => openEvent(ev.id, ev) }, ev.title)),
      h('ul', { class: 'event-facts' },
        fact('clock', `${fmt.date(ev.starts_at)} · ${fmt.time(ev.starts_at)}–${fmt.time(ev.ends_at)}`),
        fact('pin', venueText(ev.venue)),
        fact('user', ev.organizer.name)),
      ev.registration_required ? h('span', { class: 'badge badge-warn', style: { alignSelf: 'start' } }, 'Registration required') : '',
      ev.is_sample ? h('span', { class: 'muted', style: { fontSize: '.75rem' } }, 'Sample event') : ''),
    h('div', { class: 'event-actions' }, navBtn(ev),
      h('button', { class: 'btn', type: 'button', onclick: () => openEvent(ev.id, ev) }, 'Details')));
}
const card = eventCard;

async function openEvent(id, cached) {
  const dialog = $('event-dialog');
  const body = $('event-dialog-body');
  let ev = cached;
  if (!ev) {
    try {
      ev = await api.event(id);
    } catch (e) {
      body.replaceChildren(h('h2', { id: 'ed-title' }, 'Event unavailable'), h('p', {}, e.message),
        h('button', { class: 'btn', type: 'button', onclick: () => dialog.close() }, 'Close'));
      if (!dialog.open) dialog.showModal();
      return;
    }
  }
  const reg = ev.registration_required
    ? (ev.registration_url
      ? h('a', { href: ev.registration_url, target: '_blank', rel: 'noopener noreferrer' }, 'Register online')
      : `Required — contact ${ev.organizer.contact_email || ev.organizer.name}`)
    : 'Not required — open attendance';
  body.replaceChildren(
    h('button', { class: 'btn btn-ghost btn-sm close', type: 'button', 'aria-label': 'Close', onclick: () => dialog.close() }, icon('x', { size: 20 })),
    h('span', { class: 'badge', style: { background: ev.category.color, color: '#fff' } }, ev.category.name),
    h('h2', { id: 'ed-title', style: { marginTop: '.5rem' } }, ev.title),
    h('p', {}, ev.description),
    h('dl', {},
      h('dt', {}, 'When'), h('dd', {}, `${fmt.date(ev.starts_at, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}, ${fmt.time(ev.starts_at)}–${fmt.time(ev.ends_at)}`),
      h('dt', {}, 'Where'), h('dd', {}, venueText(ev.venue), ev.venue.room_number ? ` (room ${ev.venue.room_number})` : ''),
      h('dt', {}, 'Organizer'), h('dd', {}, ev.organizer.name, ev.organizer.department ? ` — ${ev.organizer.department}` : ''),
      h('dt', {}, 'Registration'), h('dd', {}, reg),
      ev.capacity ? [h('dt', {}, 'Capacity'), h('dd', {}, `${ev.capacity} people`)] : ''),
    ev.is_sample ? h('p', { class: 'muted', style: { fontSize: '.8rem' } }, 'This is a sample event for demonstration.') : '',
    h('div', { class: 'dialog-actions' }, navBtn(ev),
      h('button', { class: 'btn', type: 'button', onclick: () => downloadIcs(ev) }, icon('download', { size: 18 }), 'Add to calendar')),
  );
  if (!dialog.open) dialog.showModal();
}

function downloadIcs(ev) {
  const stamp = (iso) => iso.replace(/[-:]/g, '').slice(0, 13) + '00';
  const esc = (s) => String(s || '').replace(/[\\;,]/g, (m) => `\\${m}`).replace(/\n/g, '\\n');
  const ics = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//CampusNav//EN', 'BEGIN:VEVENT',
    `UID:campusnav-event-${ev.id}@campusnav`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').slice(0, 15)}Z`,
    `DTSTART:${stamp(ev.starts_at)}`, `DTEND:${stamp(ev.ends_at)}`,
    `SUMMARY:${esc(ev.title)}`, `DESCRIPTION:${esc(ev.description)}`, `LOCATION:${esc(venueText(ev.venue))}`,
    'END:VEVENT', 'END:VCALENDAR',
  ].join('\r\n');
  const a = h('a', { href: URL.createObjectURL(new Blob([ics], { type: 'text/calendar' })), download: `event-${ev.id}.ics` });
  document.body.append(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
