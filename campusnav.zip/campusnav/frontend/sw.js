// Service worker: caches the app shell so CampusNav opens offline and can be installed.
// API responses are network-first with a cached fallback, so the last viewed campus map,
// buildings and events stay available without a connection. Routes need the server.
const CACHE = 'campusnav-v9';
const SHELL = [
  '/', '/css/app.css', '/js/app.js', '/js/api.js', '/js/ui.js', '/js/map-view.js', '/js/events-view.js', '/js/places-view.js', '/js/icons.js', '/js/assistant.js', '/js/mascot.js', '/icons/ghoula.svg', '/icons/logo-mark.svg',
  '/icons/icon.svg', '/manifest.webmanifest',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
];
const CACHEABLE_API = ['/api/meta', '/api/buildings', '/api/pathways', '/api/locations', '/api/events', '/api/categories'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin && url.pathname.startsWith('/api/')) {
    if (!CACHEABLE_API.some((p) => url.pathname.startsWith(p))) return;
    e.respondWith(fetch(req).then((res) => {
      if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
      return res;
    }).catch(() => caches.match(req).then((r) => r || Response.error())));
    return;
  }
  if (/tile\.openstreetmap\.org|cartocdn\.com|arcgisonline\.com/.test(url.hostname)) return; // never intercept map tiles
  // App shell: network first (revalidating the HTTP cache) so deployments show up
  // immediately, Cache Storage as the offline fallback.
  const net = url.origin === location.origin && req.mode !== 'navigate' ? fetch(req.url, { cache: 'no-cache' }) : fetch(req);
  e.respondWith(net.then((res) => {
    if (res.ok && (url.origin === location.origin || url.hostname === 'unpkg.com')) {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copy));
    }
    return res;
  }).catch(() => caches.match(req).then((r) => r || caches.match('/'))));
});
