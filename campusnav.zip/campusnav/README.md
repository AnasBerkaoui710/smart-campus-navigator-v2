# CampusNav â€” campus navigation & events

Discover a university event, select it, and walk to its exact room by the shortest suitable
route. CampusNav combines an interactive campus map, an A* pedestrian routing engine
(indoor + outdoor, stairs/elevators, step-free option) and an event catalogue whose
**Navigate to event** button opens the map with the venue already set as the destination.

> **Sample data.** The bundled campus "Demo University" and its events are fictional. It is
> placed at 0Â°, 0Â° on purpose so it can't be mistaken for a real place, and the UI shows a
> *Sample data* badge. See "Using real campus data" below.

## Features

* **Map** â€” Leaflet map with building footprints, walkways and closures; search by name,
  room number (`201`, `ENG-201`), facility type or keyword; tap a building to select it.
* **Routing** â€” A* over a campus graph; shortest *and* fastest routes when they differ, up
  to two alternatives, turn-by-turn steps with floor changes, distance and walking time.
* **Accessibility** â€” "Avoid stairs" uses ramps and elevators; routes over unsurveyed doors
  are marked *unverified*; if no step-free route exists the app says so explicitly.
* **Start point** â€” your GPS location (with permission), a searched place, or a point picked
  on the map. Live re-routing when you walk off the route; "Blocked?" on any step.
* **Events** â€” searchable, filterable cards; details dialog, add to calendar (.ics), and
  **Navigate to event** â†’ map + venue + your location + route, in one tap.
* **Staff dashboard** (`/admin`) â€” events CRUD, close/reopen paths and facilities, categories
  and organizers, validated pathway-data import. Role-based (`editor`, `admin`).
* **Responsive + PWA** â€” sidebar layout on desktop, bottom tabs and a collapsible directions
  sheet on mobile; installable, app shell and last-seen data work offline.

## AI assistant ("Ghoula")

A Gemini-powered assistant on its own page (`#/assistant`) and as a floating mini-chat on every page.
It streams its answers, understands English / French / Arabic, can be spoken to and can answer out loud,
and it **acts**: it searches the real places/events database and redirects the app (open directions, set the
start place, switch on step-free routes, start turn-by-turn). Example: *"I'm at the library, take me to the
conference, no stairs, and start."*

* The Gemini API key stays on the server: set `GEMINI_API_KEY` or put the key in `backend/instance/gemini_api_key`
  (git-ignored). Without a key the assistant page shows "not configured"; everything else works.
* Models (override with env vars): chat `gemini-3-flash-preview` then `gemini-3.5-flash` (`GEMINI_CHAT_MODELS`),
  voice `gemini-3.8-flash-lite-tts` then `gemini-3.8-flash-tts` (`GEMINI_TTS_MODELS`), speech-to-text
  `gemini-3-flash-preview` (`GEMINI_STT_MODEL`).
* Endpoints: `GET /api/assistant/status`, `POST /api/assistant/chat` (Server-Sent Events), `POST /api/assistant/speak`
  (text to WAV), `POST /api/assistant/transcribe`. All are rate-limited per client IP.
* Deep links the assistant uses (also shareable): `#/map?to=<place>&event=<event>&from=<place>&stepfree=1&go=1`.
* The microphone needs `localhost` or HTTPS.
* **Map control:** Ghoula can set the route options (step-free, shortest/fastest), start/stop/pause turn-by-turn, go to the
  next/previous/repeat an instruction, zoom, show your location or the whole campus, switch to satellite view, show a place and
  clear the route. It also reads the map state (destination, route time, current instruction) to answer "how long is left?".
* **History:** the assistant page keeps your conversations (New chat, open, delete, delete all) with automatic AI titles.
  They are stored in your browser only (`localStorage`), never on the server.
* **Mascot:** Ghoula (`frontend/icons/ghoula.svg`) animates by state: idle, watching you type, thinking, typing, speaking,
  listening, done, oops. Set `data-state` on the inlined SVG to switch.
* **Resilience:** Gemini's free tier rate-limits (429) and sometimes overloads (503), so each request tries the models in
  `GEMINI_CHAT_MODELS` in order, retries with back-off, and gives up after ~24 s with a friendly message.
* If a student is not on campus (for example testing from home), directions start from the Main Gate automatically.

## Run with Docker

```bash
cp .env.example .env          # Windows PowerShell: Copy-Item .env.example .env
# edit .env: set SECRET_KEY, ADMIN_PASSWORD and (optional) GEMINI_API_KEY
docker compose up --build
```

Open http://localhost:8000 (API docs: `/docs`, staff dashboard: `/admin`). The database and generated secrets live in the
`campusnav-data` volume, so they survive restarts. On first start the FST Béni Mellal data and sample events are loaded; if
`ADMIN_PASSWORD` is empty a random staff password is printed once in `docker compose logs`.

Without compose:

```bash
docker build -t campusnav .
docker run -p 8000:8000 -e GEMINI_API_KEY=your-key -v campusnav-data:/app/backend/instance campusnav
```

**Never commit your `.env` file or `backend/instance/`**: they hold the API key, the signing secret and the database
(both are in `.gitignore`).

## Quick start (local Python)

Requirements: **Python 3.10+**.

```bash
cd campusnav
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
cd backend
python run.py
```

Open http://127.0.0.1:5000 (interactive API docs: http://127.0.0.1:5000/docs). On first run the SQLite database is created with the sample
campus and events, and an admin account is created. Its password is printed **once** in the
console unless you set `ADMIN_PASSWORD` (and optionally `ADMIN_EMAIL`) beforehand â€” see
`.env.example`. Staff dashboard: http://127.0.0.1:5000/admin.

### Try the main workflows

1. **Events â†’ Navigate to event.** Location permission will be requested. Because the sample
   campus is at 0Â°,0Â°, a real GPS fix is reported as "outside the mapped campus" â€” choose a
   start (e.g. *Main Gate*) or tick **Demo: simulate GPS** and click on the map.
2. **Map â†’ search "201"** â†’ choose *Seminar Room ENG-201* â†’ start *Main Gate*: route with an
   elevator/stairs floor change.
3. **Main Gate â†’ Grand Auditorium**: *Shortest* takes the Hill Steps; *Fastest* takes the ramp.
4. **Avoid stairs â†’ Special Collections (Library floor 1)**: no step-free route â€” the library
   has no elevator in the sample data, and the app says so.
5. **Avoid stairs â†’ Main Cafeteria from West Lane**: uses a door whose accessibility is
   unknown â†’ "Step-free (unverified parts)" + warning.
6. **/admin â†’ Paths â†’ close "Hill Steps"** â†’ the Auditorium route changes immediately.

## Management commands (run in `backend/`)

```bash
python manage.py init-db                 # tables + sample campus + sample events + first admin
python manage.py reseed-events           # move sample events relative to today
python manage.py validate my_campus.json # check a dataset
python manage.py import my_campus.json   # import / update a dataset
python manage.py create-user ana@uni.edu "Ana Staff" --role editor
python tools/generate_sample_campus.py   # regenerate data/sample_campus.json
```

## Tests

```bash
cd backend
python -m pytest -q
```

Covers A* vs. brute-force Dijkstra on random graphs, profiles, closures, accessibility,
GPS snapping, every event venue and every location being routable, API validation,
auth/roles, and dataset validation. Manual test plan: [docs/TESTING.md](docs/TESTING.md).

## Using real campus data

Features that work fully with the sample data: the whole UI, search, events, the routing
logic, closures and accessibility rules. What a real deployment needs:

| Needed | Why |
|---|---|
| Surveyed pathway graph (outdoor paths, entrances, corridors, stairs, lifts) | routes and distances are only as accurate as this graph |
| Real coordinates (lat/lng) for outdoor nodes | GPS start points, OSM background alignment |
| Room positions per floor | indoor directions |
| Accessibility per door, ramp, lift (true/false; leave unknown if not surveyed) | trustworthy step-free routes |
| Measured stair and ramp lengths | stairs vs. ramp choice, times |

Produce a `campusnav-pathways/1` JSON (format in [docs/ROUTING.md](docs/ROUTING.md)), set
`"is_sample": false`, validate, then import from the CLI or the staff dashboard. OpenStreetMap
footways can be a starting point for the outdoor graph, but indoor layouts must come from
the university's floor plans.

## Deployment

1. Set `SECRET_KEY` (long random string), `DATABASE_URL` (PostgreSQL/MySQL recommended),
   `SESSION_COOKIE_SECURE=1`, `ADMIN_EMAIL`/`ADMIN_PASSWORD`.
2. Install the DB driver (`psycopg[binary]` or `PyMySQL`). `uvicorn` is already in `requirements.txt`.
3. `python manage.py init-db` (or create tables and `import` your real dataset, then
   `create-user`).
4. Run `uvicorn wsgi:app --host 0.0.0.0 --port 8000 --workers 2` (from `backend/`) behind a reverse
   proxy with HTTPS (needed for geolocation and the service worker).
5. The routing graph is cached per worker process and invalidated on admin changes; with
   several workers, a closure is seen by other workers after they restart or when you add a
   shared cache-version check (see "Known limitations").

## Project structure

```
campusnav/
â”œâ”€â”€ backend/   Flask app (app/), routing engine (app/routing/), tests/, data/, tools/, manage.py
â”œâ”€â”€ frontend/  index.html, admin.html, css/, js/, sw.js, manifest â€” served by Flask
â””â”€â”€ docs/      ARCHITECTURE.md Â· ROUTING.md Â· TESTING.md
```

## Known limitations

* Multi-worker deployments: graph cache invalidation is per process (see Deployment Â§5).
* Login throttling is in-memory per process; put a rate limiter in the reverse proxy too.
* Event times are campus-local wall-clock times (no time-zone conversion).
* The map shows all floors of a route on one plane; floor changes are labelled on the route.
