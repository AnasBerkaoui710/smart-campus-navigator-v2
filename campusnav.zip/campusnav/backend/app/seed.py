"""Sample categories, organizers and events for the FST Beni Mellal campus.

Event dates are generated relative to "now" when seeding so the demo always has
upcoming events. Every event is flagged is_sample=True (fictional events).
"""
import json
import os
import secrets
from datetime import datetime, timedelta

from . import config
from .importer import import_dataset
from .models import CampusLocation, EventCategory, Event, Organizer, User, db

CATEGORIES = [
    ("conference", "Conference", "#1f5e3b"),
    ("seminar", "Seminar", "#2f7d6b"),
    ("workshop", "Workshop", "#7a8f2a"),
    ("examination", "Examination", "#b3261e"),
    ("cultural", "Cultural", "#c2693a"),
    ("student-meeting", "Student Meeting", "#5f8a5a"),
]

ORGANIZERS = [
    ("Department of Mathematics & Computer Science", "FST Beni Mellal", "info@fst-bm.example"),
    ("Department of Chemistry & Physics", "FST Beni Mellal", "physics@fst-bm.example"),
    ("Department of Biology & Geology", "FST Beni Mellal", "biology@fst-bm.example"),
    ("Student Union", "Student Life", "union@fst-bm.example"),
    ("University Library", "Library Services", "library@fst-bm.example"),
    ("Dean's Office", "Administration", "decanat@fst-bm.example"),
]

# (title, category, organizer, venue code, day offset, start hour, duration h, registration, capacity, description)
EVENTS = [
    ("FST Scientific Days", "conference", "Dean's Office", "amp-102", 2, 9, 7,
     True, 300, "Keynotes, poster sessions and research showcases from all departments."),
    ("Intro to Machine Learning Workshop", "workshop", "Department of Mathematics & Computer Science", "dmi-101", 1, 14, 3,
     True, 30, "Hands-on session: train and evaluate your first model in Python. Bring a laptop."),
    ("Quantum Physics Seminar", "seminar", "Department of Chemistry & Physics", "dcp-201", 3, 11, 1.5,
     False, None, "Guest lecture on quantum entanglement and its experimental verification."),
    ("Midterm Exam - Analysis 2", "examination", "Dean's Office", "amp-g01", 4, 9, 2,
     False, None, "Bring your student card. Calculators without memory are allowed."),
    ("Inter-Faculty Cultural Day", "cultural", "Student Union", "plaza", 5, 12, 5,
     False, None, "Music, food stalls and club presentations on the central plaza."),
    ("Student Union General Assembly", "student-meeting", "Student Union", "amp-g02", 1, 17, 2,
     False, 150, "Vote on this semester's activities and elect committee representatives."),
    ("Research Skills: Finding Sources", "workshop", "University Library", "lib-101", 6, 10, 1.5,
     True, 15, "Learn advanced database searching and citation management."),
    ("Theses Archive Open House", "cultural", "University Library", "lib-201", 8, 15, 2,
     False, None, "Discover the archive of theses and dissertations. Library has a lift to the 2nd floor."),
    ("Biology Master's Defense", "seminar", "Department of Biology & Geology", "dbg-201", 9, 10, 4,
     False, 40, "Master's students defend their projects. Open to all (stairs only to this room)."),
    ("Field Geology Seminar", "seminar", "Department of Biology & Geology", "dbg-g02", 10, 14, 2,
     False, None, "Preparing the spring field trip: itinerary, equipment and safety."),
    ("Robotics Club Demo Day", "student-meeting", "Department of Mathematics & Computer Science", "dmi-g02", 12, 13, 3,
     False, None, "See the robots built by the student robotics club this semester."),
    ("Faculty Council Open Session", "student-meeting", "Dean's Office", "adm-103", 14, 16, 1.5,
     True, 25, "Public portion of the faculty council meeting."),
]



def seed_lookups():
    for slug, name, color in CATEGORIES:
        if not EventCategory.query.filter_by(slug=slug).first():
            db.session.add(EventCategory(slug=slug, name=name, color=color))
    for name, dept, email in ORGANIZERS:
        if not Organizer.query.filter_by(name=name).first():
            db.session.add(Organizer(name=name, department=dept, contact_email=email))
    db.session.commit()


def seed_events(now=None):
    now = (now or datetime.now()).replace(minute=0, second=0, microsecond=0)
    cats = {c.slug: c for c in EventCategory.query.all()}
    orgs = {o.name: o for o in Organizer.query.all()}
    venues = {loc.code: loc for loc in CampusLocation.query.all()}
    Event.query.filter_by(is_sample=True).delete()
    for title, cat, org, venue, day, hour, hours, reg, cap, desc in EVENTS:
        start = (now + timedelta(days=day)).replace(hour=hour)
        db.session.add(Event(
            title=title, description=desc, category=cats[cat], organizer=orgs[org], venue=venues[venue],
            starts_at=start, ends_at=start + timedelta(hours=hours), registration_required=reg,
            registration_url=None, capacity=cap, status="published", is_sample=True))
    db.session.commit()


def ensure_admin():
    """Create the first admin account if none exists. Credentials come from
    ADMIN_EMAIL / ADMIN_PASSWORD; otherwise a random password is printed once."""
    if User.query.filter_by(role="admin").first():
        return None
    email = os.environ.get("ADMIN_EMAIL") or "admin@demo-university.example"
    password = os.environ.get("ADMIN_PASSWORD") or None   # empty (e.g. from docker compose) means "generate one"
    generated = password is None
    password = password or secrets.token_urlsafe(12)
    user = User(name="Campus Administrator", email=email, role="admin")
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    if generated:
        print(f"\n  Created admin account {email}\n  Generated password: {password}\n"
              "  (shown once - set ADMIN_PASSWORD to choose your own)\n")
    return user


def init_sample(with_admin=True):
    db.create_all()
    with open(config.settings.sample_dataset, encoding="utf-8") as f:
        summary = import_dataset(json.load(f))
    seed_lookups()
    seed_events()
    if with_admin:
        ensure_admin()
    return summary
