"""Validate and import a campus pathway dataset (format "campusnav-pathways/1").

Records are upserted by their `code`, so re-importing an updated survey keeps
database ids (and therefore event venues and edge closures) stable.
"""
from collections import defaultdict, deque

from .geo import haversine_m, local_to_latlng
from .models import (Building, CampusLocation, DatasetInfo, Event, PathwayEdge, PathwayNode, db)

NODE_KINDS = {"junction", "entrance", "corridor", "room", "stairs", "elevator", "gate"}
EDGE_KINDS = {"walkway", "corridor", "door", "stairs", "ramp", "elevator"}
FORMAT = "campusnav-pathways/1"


class DatasetError(ValueError):
    def __init__(self, errors):
        super().__init__("; ".join(errors[:5]))
        self.errors = errors


def _resolve_coords(data):
    """Return {node_code: (lat, lng)} and a converter for footprint points."""
    origin = data.get("origin") or {}
    local = data.get("coordinates", "latlng") == "local_m"
    olat, olng = origin.get("lat", 0.0), origin.get("lng", 0.0)

    def conv(p):
        if local:
            return local_to_latlng(p[0], p[1], olat, olng)
        return float(p[0]), float(p[1])

    coords = {}
    for n in data.get("nodes", []):
        if local:
            coords[n["code"]] = local_to_latlng(n["x"], n["y"], olat, olng)
        else:
            coords[n["code"]] = (float(n["lat"]), float(n["lng"]))
    return coords, conv, (olat, olng)


def validate(data):
    """Return (errors, warnings). Errors block the import."""
    errors, warnings = [], []
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        return [f"'format' must be '{FORMAT}'"], warnings
    for key in ("name", "nodes", "edges", "locations"):
        if key not in data:
            errors.append(f"missing '{key}'")
    if errors:
        return errors, warnings

    try:
        coords, _, _ = _resolve_coords(data)
    except (KeyError, TypeError, ValueError) as exc:
        return [f"node coordinates are invalid: {exc!r}"], warnings

    building_codes = {b.get("code") for b in data.get("buildings", [])}
    seen = set()
    for n in data["nodes"]:
        code = n.get("code")
        if not code or code in seen:
            errors.append(f"node code missing or duplicated: {code!r}")
        seen.add(code)
        if n.get("kind") not in NODE_KINDS:
            errors.append(f"node {code}: unknown kind {n.get('kind')!r}")
        if n.get("building") and n["building"] not in building_codes:
            errors.append(f"node {code}: unknown building {n['building']!r}")
        if not isinstance(n.get("floor", 0), int):
            errors.append(f"node {code}: floor must be an integer")

    adj = defaultdict(set)
    edge_codes = set()
    for e in data["edges"]:
        code = e.get("code")
        if not code or code in edge_codes:
            errors.append(f"edge code missing or duplicated: {code!r}")
        edge_codes.add(code)
        a, b = e.get("from"), e.get("to")
        if a not in coords or b not in coords:
            errors.append(f"edge {code}: unknown endpoint")
            continue
        if e.get("kind") not in EDGE_KINDS:
            errors.append(f"edge {code}: unknown kind {e.get('kind')!r}")
        straight = haversine_m(*coords[a], *coords[b])
        if "length_m" in e:
            length = e["length_m"]
            if not isinstance(length, (int, float)) or length <= 0:
                errors.append(f"edge {code}: length_m must be a positive number")
            elif length + 0.5 < straight:
                # Shorter than the straight line is physically impossible and would
                # break the A* heuristic, so it is treated as a data error.
                errors.append(f"edge {code}: length_m {length} is shorter than straight-line {straight:.1f} m")
        elif e.get("kind") in ("stairs", "elevator") and straight < 1:
            errors.append(f"edge {code}: vertical {e['kind']} edges need an explicit length_m")
        adj[a].add(b)
        if e.get("bidirectional", True):
            adj[b].add(a)

    loc_codes = set()
    for loc in data["locations"]:
        code = loc.get("code")
        if not code or code in loc_codes:
            errors.append(f"location code missing or duplicated: {code!r}")
        loc_codes.add(code)
        if not loc.get("name") or not loc.get("type"):
            errors.append(f"location {code}: name and type are required")
        if loc.get("node") not in coords:
            errors.append(f"location {code}: node {loc.get('node')!r} does not exist")
        if loc.get("building") and loc["building"] not in building_codes:
            errors.append(f"location {code}: unknown building {loc['building']!r}")

    # Connectivity: every location should be reachable from the first gate (or first node).
    if not errors and data["nodes"]:
        gates = [n["code"] for n in data["nodes"] if n["kind"] == "gate"] or [data["nodes"][0]["code"]]
        reached, queue = {gates[0]}, deque([gates[0]])
        while queue:
            cur = queue.popleft()
            for nxt in adj[cur] - reached:
                reached.add(nxt)
                queue.append(nxt)
        for loc in data["locations"]:
            if loc["node"] not in reached:
                warnings.append(f"location {loc['code']} is not reachable from {gates[0]}")
    return errors, warnings


def import_dataset(data):
    """Validate then upsert the dataset. Returns a summary dict. Raises DatasetError."""
    errors, warnings = validate(data)
    if errors:
        raise DatasetError(errors)
    coords, conv, (olat, olng) = _resolve_coords(data)
    is_sample = bool(data.get("is_sample", False))

    # Locations referenced by events may not disappear.
    new_loc_codes = {loc["code"] for loc in data["locations"]}
    orphaned = (db.session.query(Event.title, CampusLocation.code)
                .join(CampusLocation, Event.venue_id == CampusLocation.id)
                .filter(CampusLocation.code.notin_(new_loc_codes)).all())
    if orphaned:
        raise DatasetError([f"event '{t}' uses location '{c}', which is missing from the dataset"
                            for t, c in orphaned])

    buildings = {b.code: b for b in Building.query.all()}
    for b in data.get("buildings", []):
        footprint = [list(conv(p)) for p in b.get("footprint", [])]
        lat = sum(p[0] for p in footprint) / len(footprint) if footprint else olat
        lng = sum(p[1] for p in footprint) / len(footprint) if footprint else olng
        floors = b.get("floors") or [0]
        row = buildings.get(b["code"]) or Building(code=b["code"])
        row.name, row.description = b["name"], b.get("description", "")
        row.lat, row.lng, row.footprint = lat, lng, footprint
        row.floors_min, row.floors_max = min(floors), max(floors)
        row.data_source = "sample" if is_sample else "verified"
        db.session.add(row)
        buildings[b["code"]] = row
    db.session.flush()

    nodes = {n.code: n for n in PathwayNode.query.all()}
    for n in data["nodes"]:
        row = nodes.get(n["code"]) or PathwayNode(code=n["code"])
        row.lat, row.lng = coords[n["code"]]
        row.floor = n.get("floor", 0)
        row.building_id = buildings[n["building"]].id if n.get("building") else None
        row.kind, row.name, row.accessible = n["kind"], n.get("name"), n.get("accessible", True)
        db.session.add(row)
        nodes[n["code"]] = row
    db.session.flush()

    edges = {e.code: e for e in PathwayEdge.query.all()}
    for e in data["edges"]:
        a, b = nodes[e["from"]], nodes[e["to"]]
        row = edges.get(e["code"]) or PathwayEdge(code=e["code"])
        row.from_node_id, row.to_node_id = a.id, b.id
        row.kind, row.name = e["kind"], e.get("name")
        row.length_m = float(e.get("length_m") or haversine_m(a.lat, a.lng, b.lat, b.lng))
        row.accessible = e.get("accessible", e["kind"] != "stairs")
        row.bidirectional = e.get("bidirectional", True)
        row.restricted = e.get("restricted", False)
        db.session.add(row)
        edges[e["code"]] = row

    locs = {loc.code: loc for loc in CampusLocation.query.all()}
    for loc in data["locations"]:
        row = locs.get(loc["code"]) or CampusLocation(code=loc["code"])
        row.name, row.type = loc["name"], loc["type"]
        row.building_id = buildings[loc["building"]].id if loc.get("building") else None
        row.floor = loc.get("floor", 0)
        row.room_number = loc.get("room_number")
        row.node_id = nodes[loc["node"]].id
        row.description = loc.get("description", "")
        row.keywords = loc.get("keywords", "")
        db.session.add(row)
    db.session.flush()

    # Remove records that are no longer part of the dataset (children first).
    for code, row in locs.items():
        if code not in new_loc_codes:
            db.session.delete(row)
    new_edges = {e["code"] for e in data["edges"]}
    for code, row in edges.items():
        if code not in new_edges:
            db.session.delete(row)
    db.session.flush()
    new_nodes = {n["code"] for n in data["nodes"]}
    for code, row in nodes.items():
        if code not in new_nodes:
            db.session.delete(row)
    db.session.flush()
    new_buildings = {b["code"] for b in data.get("buildings", [])}
    for code, row in buildings.items():
        if code not in new_buildings:
            db.session.delete(row)

    DatasetInfo.query.delete()
    db.session.add(DatasetInfo(name=data["name"], is_sample=is_sample, origin_lat=olat,
                               origin_lng=olng, notes=data.get("notes"),
                               outline=[list(conv(p)) for p in data.get("campus_outline", [])] or None))
    db.session.commit()
    return {"nodes": len(data["nodes"]), "edges": len(data["edges"]),
            "locations": len(data["locations"]), "buildings": len(data.get("buildings", [])),
            "warnings": warnings}
