"""Small geodesy helpers.

Campus datasets may be authored in local metres (x east, y north) relative to an
origin, which is far easier to survey and edit than raw lat/lng. These helpers
convert between the two and measure distances. At campus scale (< 5 km) the
equirectangular approximation is accurate to well under 0.1 %.
"""
import math

EARTH_RADIUS_M = 6_371_008.8


def haversine_m(lat1, lng1, lat2, lng2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(a)))


def local_to_latlng(x, y, origin_lat, origin_lng):
    lat = origin_lat + math.degrees(y / EARTH_RADIUS_M)
    lng = origin_lng + math.degrees(x / (EARTH_RADIUS_M * math.cos(math.radians(origin_lat))))
    return lat, lng


def latlng_to_local(lat, lng, origin_lat, origin_lng):
    y = math.radians(lat - origin_lat) * EARTH_RADIUS_M
    x = math.radians(lng - origin_lng) * EARTH_RADIUS_M * math.cos(math.radians(origin_lat))
    return x, y


def bearing_deg(lat1, lng1, lat2, lng2):
    """Initial compass bearing from point 1 to point 2 (0 = north, 90 = east)."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lng2 - lng1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(x, y)) + 360) % 360


def compass_name(bearing):
    names = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"]
    return names[int((bearing + 22.5) // 45) % 8]
