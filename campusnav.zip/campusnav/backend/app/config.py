import os
import secrets
from dataclasses import dataclass
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = BACKEND_DIR.parent


def _dev_secret_key():
    """Without SECRET_KEY, keep a generated key in instance/ so sessions survive
    restarts. Production must set SECRET_KEY."""
    path = BACKEND_DIR / "instance" / "secret_key"
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(secrets.token_hex(32), encoding="utf-8")
    return path.read_text(encoding="utf-8").strip()


@dataclass
class Settings:
    secret_key: str
    database_url: str
    cookie_secure: bool = False
    frontend_dir: Path = PROJECT_DIR / "frontend"
    sample_dataset: Path = BACKEND_DIR / "data" / "fst_campus.json"
    # A GPS fix farther than this from any mapped outdoor path is "outside campus".
    snap_max_distance_m: float = 150.0
    testing: bool = False
    # AI assistant (Google Gemini). The key stays on the server; the browser never sees it.
    gemini_api_key: str = ""
    # Tried in order; a model that is rate-limited (429) or overloaded (503) is skipped for the next one.
    chat_models: tuple = ("gemini-3-flash-preview", "gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-3.5-flash-lite")
    tts_models: tuple = ("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts")
    stt_model: str = "gemini-3-flash-preview"


def _gemini_key():
    """GEMINI_API_KEY env var, else backend/instance/gemini_api_key (git-ignored)."""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    path = BACKEND_DIR / "instance" / "gemini_api_key"
    if not key and path.exists():
        key = path.read_text(encoding="utf-8").strip()
    return key


def _models(env, default):
    value = os.environ.get(env, "")
    return tuple(m.strip() for m in value.split(",") if m.strip()) or default


def load_settings() -> Settings:
    (BACKEND_DIR / "instance").mkdir(exist_ok=True)
    return Settings(
        gemini_api_key=_gemini_key(),
        chat_models=_models("GEMINI_CHAT_MODELS", Settings.chat_models),
        tts_models=_models("GEMINI_TTS_MODELS", Settings.tts_models),
        stt_model=os.environ.get("GEMINI_STT_MODEL", Settings.stt_model),
        secret_key=os.environ.get("SECRET_KEY") or _dev_secret_key(),
        database_url=os.environ.get("DATABASE_URL") or f"sqlite:///{(BACKEND_DIR / 'instance' / 'campusnav.db').as_posix()}",
        cookie_secure=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",
        snap_max_distance_m=float(os.environ.get("SNAP_MAX_DISTANCE_M") or 150),
    )


def test_settings() -> Settings:
    return Settings(secret_key="test", database_url="sqlite://", testing=True)


# The active settings; create_app() replaces this (tests use in-memory SQLite).
settings: Settings = load_settings()
