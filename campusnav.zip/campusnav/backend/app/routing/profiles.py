"""Routing cost model.

Two cost profiles share one set of constraints:

* ``shortest`` – cost is metres walked.
* ``fastest``  – cost is estimated seconds, using per-kind walking speeds and a
  fixed elevator wait.

Constraints (applied to both): closed and restricted edges are never used; with
``avoid_stairs`` any edge or node marked ``accessible = False`` is excluded. Edges
whose accessibility is unknown (``None``) are allowed but reported, so the UI can
say the step-free route is *incomplete* instead of claiming it is verified.
"""

WALKING_SPEED_MPS = 1.3          # typical adult walking speed
SPEED_FACTOR = {                 # multiplier on walking speed per edge kind
    "walkway": 1.0,
    "corridor": 1.0,
    "door": 0.8,
    "ramp": 0.9,
    "stairs": 0.45,
}
ELEVATOR_WAIT_S = 30.0
ELEVATOR_S_PER_FLOOR = 4.0
MAX_SPEED_MPS = WALKING_SPEED_MPS * max(SPEED_FACTOR.values())


def edge_duration_s(kind, length_m, floors_changed=0):
    if kind == "elevator":
        return ELEVATOR_WAIT_S + ELEVATOR_S_PER_FLOOR * max(1, floors_changed)
    return length_m / (WALKING_SPEED_MPS * SPEED_FACTOR.get(kind, 1.0))


class Profile:
    NAMES = ("shortest", "fastest")

    def __init__(self, name="shortest", avoid_stairs=False, avoid_edges=()):
        if name not in self.NAMES:
            raise ValueError(f"unknown profile {name!r}")
        self.name = name
        self.avoid_stairs = avoid_stairs
        self.avoid_edges = set(avoid_edges)

    def allows(self, edge, graph):
        if not edge.is_open or edge.restricted or edge.id in self.avoid_edges:
            return False
        if self.avoid_stairs:
            if edge.accessible is False or edge.kind == "stairs":
                return False
            if graph.nodes[edge.a].accessible is False or graph.nodes[edge.b].accessible is False:
                return False
        return True

    def cost(self, edge):
        return edge.length_m if self.name == "shortest" else edge.duration_s

    def heuristic(self, graph, node_id, goal_id):
        d = graph.distance(node_id, goal_id)
        return d if self.name == "shortest" else d / MAX_SPEED_MPS

    def other(self):
        return Profile("fastest" if self.name == "shortest" else "shortest",
                       self.avoid_stairs, self.avoid_edges)
