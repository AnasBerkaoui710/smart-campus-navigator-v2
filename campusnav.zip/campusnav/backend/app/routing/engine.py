"""A* shortest-path search, alternative routes, and route assembly."""
import heapq
import itertools

from .instructions import build_steps
from .profiles import WALKING_SPEED_MPS, Profile

ALT_PENALTY = 1.4        # cost multiplier on edges already used by a returned route
ALT_MAX_RATIO = 1.5      # an alternative may cost at most 1.5x the best route
ALT_MAX_OVERLAP = 0.7    # ...and share at most 70 % of its length with earlier routes
MAX_ALTERNATIVES = 2


class NoRouteError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def astar(graph, start, goal, profile, penalties=None):
    """Return (node_ids, edges) of the cheapest path, or None.

    `penalties` maps edge id -> multiplier (>= 1), used only for finding
    alternatives; multipliers >= 1 keep the heuristic admissible.
    """
    if start == goal:
        return [start], []
    penalties = penalties or {}
    counter = itertools.count()  # tie-breaker so heapq never compares nodes
    g = {start: 0.0}
    came = {}
    open_heap = [(profile.heuristic(graph, start, goal), next(counter), start)]
    closed = set()
    while open_heap:
        _, _, cur = heapq.heappop(open_heap)
        if cur == goal:
            nodes, edges = [cur], []
            while cur in came:
                prev, edge = came[cur]
                nodes.append(prev)
                edges.append(edge)
                cur = prev
            return nodes[::-1], edges[::-1]
        if cur in closed:
            continue
        closed.add(cur)
        for nxt, edge in graph.adj[cur]:
            if nxt in closed or not profile.allows(edge, graph):
                continue
            cand = g[cur] + profile.cost(edge) * penalties.get(edge.id, 1.0)
            if cand < g.get(nxt, float("inf")):
                g[nxt] = cand
                came[nxt] = (cur, edge)
                heapq.heappush(open_heap, (cand + profile.heuristic(graph, nxt, goal), next(counter), nxt))
    return None


def _overlap(edges, used_ids):
    """Share of this path's length that runs over edges already used."""
    total = sum(e.length_m for e in edges) or 1.0
    return sum(e.length_m for e in edges if e.id in used_ids) / total


def _route_payload(graph, path, label, kind, start_point=None, start_offset_m=0.0, destination=None):
    nodes, edges = path
    distance = sum(e.length_m for e in edges) + start_offset_m
    duration = sum(e.duration_s for e in edges) + start_offset_m / WALKING_SPEED_MPS
    geometry = []
    if start_point:
        geometry.append({"lat": start_point[0], "lng": start_point[1], "floor": 0, "outdoor": True})
    for nid in nodes:
        n = graph.nodes[nid]
        geometry.append({"lat": n.lat, "lng": n.lng, "floor": n.floor, "outdoor": n.outdoor,
                         "building_id": n.building_id})
    unknown = [e for e in edges if e.accessible is None]
    unknown += [graph.nodes[n] for n in nodes if graph.nodes[n].accessible is None]
    uses_stairs = any(e.kind == "stairs" for e in edges)
    floors = sorted({graph.nodes[n].floor for n in nodes})
    return {
        "id": kind,
        "label": label,
        "distance_m": round(distance, 1),
        "duration_s": round(duration),
        "uses_stairs": uses_stairs,
        "uses_elevator": any(e.kind == "elevator" for e in edges),
        "accessibility": "not_step_free" if uses_stairs else ("incomplete" if unknown else "verified"),
        "unknown_accessibility_count": len(unknown),
        "floors": floors,
        "edge_ids": [e.id for e in edges],
        "geometry": geometry,
        "steps": build_steps(graph, nodes, edges, start_offset_m, destination),
    }


def plan_routes(graph, start, goal, profile_name="shortest", avoid_stairs=False, avoid_edges=(),
                alternatives=True, start_point=None, start_offset_m=0.0, destination=None):
    """Compute the primary route plus the other profile's best and alternatives.

    `start_point`/`start_offset_m` describe an off-graph GPS position that was snapped
    to `start`; the straight-line offset is added to the totals and the first step.
    """
    if start not in graph.nodes or goal not in graph.nodes:
        raise NoRouteError("unknown_node", "Start or destination is not part of the campus graph.")
    if start_offset_m < 1.0:  # standing on the path already
        start_offset_m = 0.0
    profile = Profile(profile_name, avoid_stairs, avoid_edges)
    best = astar(graph, start, goal, profile)
    if best is None:
        if avoid_stairs and astar(graph, start, goal, Profile(profile_name, False, avoid_edges)):
            raise NoRouteError("no_step_free_route",
                               "No step-free route could be verified with the current map data. "
                               "A route with stairs exists — turn off 'Avoid stairs' to see it.")
        raise NoRouteError("no_route", "No open walking route connects these places. "
                                       "A path may be closed — check campus notices.")

    labels = {"shortest": "Shortest distance", "fastest": "Fastest"}
    kw = dict(start_point=start_point, start_offset_m=start_offset_m, destination=destination)
    routes = [_route_payload(graph, best, labels[profile.name], profile.name, **kw)]
    seen = [tuple(e.id for e in best[1])]

    other = profile.other()
    other_path = astar(graph, start, goal, other)
    if other_path and tuple(e.id for e in other_path[1]) not in seen:
        routes.append(_route_payload(graph, other_path, labels[other.name], other.name, **kw))
        seen.append(tuple(e.id for e in other_path[1]))

    if alternatives and best[1]:
        best_cost = sum(profile.cost(e) for e in best[1])
        used = {e.id for e in best[1]}
        penalties = {eid: ALT_PENALTY for eid in used}
        for i in range(MAX_ALTERNATIVES * 2):  # a few attempts to find distinct ones
            if len(routes) >= 2 + MAX_ALTERNATIVES:
                break
            cand = astar(graph, start, goal, profile, penalties)
            if not cand:
                break
            key = tuple(e.id for e in cand[1])
            for e in cand[1]:
                penalties[e.id] = penalties.get(e.id, 1.0) * ALT_PENALTY
            if key in seen:
                continue
            cost = sum(profile.cost(e) for e in cand[1])
            if cost > best_cost * ALT_MAX_RATIO or _overlap(cand[1], used) > ALT_MAX_OVERLAP:
                continue
            seen.append(key)
            used |= {e.id for e in cand[1]}
            routes.append(_route_payload(graph, cand, f"Alternative {i + 1}", f"alt{len(routes)}", **kw))
        n = 0
        for r in routes:  # renumber alternatives 1..n in the order returned
            if r["id"].startswith("alt"):
                n += 1
                r["label"] = f"Alternative {n}"

    warnings = []
    primary = routes[0]
    if avoid_stairs and primary["accessibility"] == "incomplete":
        warnings.append("Part of this step-free route has not been surveyed for accessibility "
                        f"({primary['unknown_accessibility_count']} segment(s) unknown). "
                        "Confirm with campus services if you rely on step-free access.")
    if start_offset_m > 0:
        warnings.append(f"Your position was matched to the nearest mapped path "
                        f"({round(start_offset_m)} m away); the first segment is a straight-line estimate.")
    return {"profile": profile.name, "avoid_stairs": avoid_stairs, "routes": routes, "warnings": warnings}


def snap_point(graph, lat, lng, max_distance_m):
    node, dist = graph.nearest_node(lat, lng)
    if node is None:
        raise NoRouteError("empty_graph", "No campus pathway data is loaded.")
    if dist > max_distance_m:
        raise NoRouteError("outside_campus",
                           f"Your position is {_fmt_km(dist)} from the nearest mapped campus path. "
                           "Choose a starting point on campus instead.")
    return node, dist


def _fmt_km(m):
    if m >= 100_000:
        return f"{m / 1000:,.0f} km"
    return f"{m / 1000:.1f} km" if m >= 1000 else f"{round(m)} m"
