"""Turn a node/edge path into human-readable step-by-step instructions."""
from ..geo import bearing_deg, compass_name
from .profiles import WALKING_SPEED_MPS

WALK_KINDS = {"walkway", "corridor", "ramp"}
STRAIGHT_DEG = 30   # turns smaller than this are "continue"
SLIGHT_DEG = 60     # 30–60° is "bear left/right"


def floor_label(floor):
    if floor == 0:
        return "the ground floor"
    if floor < 0:
        return f"basement level {-floor}"
    return f"floor {floor}"


def _turn(prev, new):
    if prev is None:
        return f"Head {compass_name(new)}"
    delta = (new - prev + 540) % 360 - 180  # -180..180, negative = left
    a = abs(delta)
    side = "left" if delta < 0 else "right"
    if a < STRAIGHT_DEG:
        return "Continue straight"
    if a < SLIGHT_DEG:
        return f"Bear {side}"
    if a < 150:
        return f"Turn {side}"
    return "Turn around"


def _place(node):
    """Outdoors (incl. entrances) is one place; indoors is a (building, floor) pair."""
    return None if node.outdoor else (node.building_id, node.floor)


def _step(text, kind, node, distance=0.0, duration=0.0, edges=()):
    # edge_ids let the client say "this part is blocked" and re-route around it.
    return {"text": text, "kind": kind, "distance_m": round(distance), "duration_s": round(duration),
            "lat": node.lat, "lng": node.lng, "floor": node.floor, "building_id": node.building_id,
            "edge_ids": [e.id for e in edges]}


def build_steps(graph, nodes, edges, start_offset_m=0.0, destination=None):
    N = graph.nodes
    steps = []
    if start_offset_m > 0:
        first = N[nodes[0]]
        target = first.name or "the nearest campus path"
        steps.append(_step(f"Walk about {round(start_offset_m)} m to {target}", "approach", first,
                           start_offset_m, start_offset_m / WALKING_SPEED_MPS))

    prev_bearing = None
    i = 0
    while i < len(edges):
        e = edges[i]
        u, v = N[nodes[i]], N[nodes[i + 1]]

        if e.kind in ("stairs", "elevator") and u.floor != v.floor:
            j = i
            while j + 1 < len(edges) and edges[j + 1].kind == e.kind and N[nodes[j + 2]].floor != N[nodes[j + 1]].floor:
                j += 1
            end = N[nodes[j + 1]]
            direction = "up" if end.floor > u.floor else "down"
            what = "stairs" if e.kind == "stairs" else "elevator"
            steps.append(_step(f"Take the {what} {direction} to {floor_label(end.floor)}", e.kind, u,
                               sum(x.length_m for x in edges[i:j + 1]),
                               sum(x.duration_s for x in edges[i:j + 1]), edges[i:j + 1]))
            prev_bearing = None
            i = j + 1
            continue

        if e.kind == "door":
            # Entering and leaving the same building straight away: a cut-through.
            if (u.kind == "entrance" and i + 1 < len(edges) and edges[i + 1].kind == "door"
                    and N[nodes[i + 2]].kind == "entrance" and N[nodes[i + 2]].building_id == u.building_id):
                out = N[nodes[i + 2]]
                steps.append(_step(f"Walk through {u.building_name or 'the building'} from the "
                                   f"{(u.name or 'entrance').lower()} to the {(out.name or 'exit').lower()}",
                                   "door", u, e.length_m + edges[i + 1].length_m,
                                   e.duration_s + edges[i + 1].duration_s, edges[i:i + 2]))
                prev_bearing = bearing_deg(u.lat, u.lng, out.lat, out.lng)
                i += 2
                continue
            if u.kind == "entrance" and v.kind != "entrance":
                text = f"Enter {u.building_name or 'the building'} through the {(u.name or 'entrance').lower()}"
            elif v.kind == "entrance":
                text = f"Exit {v.building_name or 'the building'} through the {(v.name or 'exit').lower()}"
            elif v.kind == "room":
                text = f"Go through the door into {v.name or 'the room'}"
            else:
                text = f"Go through the door{f' ({e.name})' if e.name else ''}"
            steps.append(_step(text, "door", u, e.length_m, e.duration_s, [e]))
            prev_bearing = bearing_deg(u.lat, u.lng, v.lat, v.lng)
            i += 1
            continue

        if e.kind == "stairs":  # outdoor flight of steps on one level
            label = e.name or "stairs"
            steps.append(_step(f"{_turn(prev_bearing, bearing_deg(u.lat, u.lng, v.lat, v.lng))} "
                               f"and take the {label} ({round(e.length_m)} m)", "stairs", u,
                               e.length_m, e.duration_s, [e]))
            prev_bearing = bearing_deg(u.lat, u.lng, v.lat, v.lng)
            i += 1
            continue

        # Walking: merge consecutive edges that keep the same kind, place and direction.
        start_bearing = bearing_deg(u.lat, u.lng, v.lat, v.lng)
        dist, dur, last_bearing = e.length_m, e.duration_s, start_bearing
        j = i
        while j + 1 < len(edges):
            nxt = edges[j + 1]
            a, b = N[nodes[j + 1]], N[nodes[j + 2]]
            if nxt.kind != e.kind or _place(a) != _place(u):
                break
            nb = bearing_deg(a.lat, a.lng, b.lat, b.lng)
            same_name = nxt.name and nxt.name == e.name
            if not same_name and abs((nb - last_bearing + 540) % 360 - 180) >= STRAIGHT_DEG:
                break
            dist += nxt.length_m
            dur += nxt.duration_s
            last_bearing = nb
            j += 1
        turn = _turn(prev_bearing, start_bearing)
        if e.kind == "ramp":
            text = f"{turn} and use the {(e.name or 'ramp').lower()} for {round(dist)} m"
        elif e.kind == "corridor":
            text = f"{turn} along the corridor for {round(dist)} m"
        elif e.name:
            text = f"{turn} along {e.name} for {round(dist)} m"
        elif N[nodes[j + 1]].kind in ("entrance", "gate") and N[nodes[j + 1]].name:
            text = f"{turn} toward the {N[nodes[j + 1]].name.lower()} ({round(dist)} m)"
        else:
            text = f"{turn} for {round(dist)} m"
        steps.append(_step(text, e.kind, u, dist, dur, edges[i:j + 1]))
        prev_bearing = last_bearing
        i = j + 1

    end = N[nodes[-1]]
    if destination:
        where = destination["name"]
        extras = []
        if destination.get("room_number") and destination["room_number"] not in where:
            extras.append(f"room {destination['room_number']}")
        if destination.get("building") and end.building_id is not None and end.kind != "entrance":
            extras.append(floor_label(end.floor).removeprefix("the "))
        text = f"Arrive at {where}" + (f" ({', '.join(extras)})" if extras else "")
    else:
        text = "You have arrived"
    steps.append(_step(text, "arrive", end))
    return steps
