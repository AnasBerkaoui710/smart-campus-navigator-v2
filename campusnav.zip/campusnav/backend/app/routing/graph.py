"""In-memory campus graph.

Kept independent of Flask so the engine can be unit-tested with hand-built graphs.
`Graph.from_db()` builds one from the ORM tables; `get_graph()` caches it per app
and `invalidate()` must be called after any write to nodes/edges/closures.
"""
from collections import defaultdict
from dataclasses import dataclass, field

from ..geo import haversine_m
from .profiles import edge_duration_s


@dataclass
class Node:
    id: int
    lat: float
    lng: float
    floor: int = 0
    building_id: int | None = None
    kind: str = "junction"
    name: str | None = None
    accessible: bool | None = True
    building_name: str | None = None

    @property
    def outdoor(self):
        return self.building_id is None or self.kind == "entrance"


@dataclass
class Edge:
    id: int
    a: int
    b: int
    kind: str
    length_m: float
    accessible: bool | None = True
    name: str | None = None
    is_open: bool = True
    restricted: bool = False
    bidirectional: bool = True
    status_note: str | None = None
    duration_s: float = field(default=0.0)


class Graph:
    def __init__(self, nodes, edges):
        self.nodes = {n.id: n for n in nodes}
        self.edges = {e.id: e for e in edges}
        self.adj = defaultdict(list)  # node id -> [(neighbour id, Edge)]
        for e in edges:
            floors = abs(self.nodes[e.a].floor - self.nodes[e.b].floor)
            e.duration_s = edge_duration_s(e.kind, e.length_m, floors)
            self.adj[e.a].append((e.b, e))
            if e.bidirectional:
                self.adj[e.b].append((e.a, e))

    @classmethod
    def from_db(cls):
        from ..models import Building, PathwayEdge, PathwayNode
        names = {b.id: b.name for b in Building.query.all()}
        nodes = [Node(n.id, n.lat, n.lng, n.floor, n.building_id, n.kind, n.name, n.accessible,
                      names.get(n.building_id)) for n in PathwayNode.query.all()]
        edges = [Edge(e.id, e.from_node_id, e.to_node_id, e.kind, e.length_m, e.accessible, e.name,
                      e.status == "open", e.restricted, e.bidirectional, e.status_note)
                 for e in PathwayEdge.query.all()]
        return cls(nodes, edges)

    def distance(self, a, b):
        na, nb = self.nodes[a], self.nodes[b]
        return haversine_m(na.lat, na.lng, nb.lat, nb.lng)

    def nearest_node(self, lat, lng, outdoor_only=True):
        """Nearest node usable as a GPS start. GPS has no floor information, so by
        default only outdoor nodes (and building entrances) are candidates."""
        best, best_d = None, float("inf")
        for n in self.nodes.values():
            if outdoor_only and not n.outdoor:
                continue
            if not self.adj[n.id]:
                continue
            d = haversine_m(lat, lng, n.lat, n.lng)
            if d < best_d:
                best, best_d = n, d
        return best, best_d

    def reachable_from_gates(self):
        """Node ids reachable over open, unrestricted edges from any gate."""
        if getattr(self, "_reachable", None) is None:
            gates = [n.id for n in self.nodes.values() if n.kind == "gate"] or list(self.nodes)[:1]
            seen, stack = set(gates), list(gates)
            while stack:
                cur = stack.pop()
                for nxt, e in self.adj[cur]:
                    if e.is_open and not e.restricted and nxt not in seen:
                        seen.add(nxt)
                        stack.append(nxt)
            self._reachable = seen
        return self._reachable

    def bounds(self):
        lats = [n.lat for n in self.nodes.values()]
        lngs = [n.lng for n in self.nodes.values()]
        if not lats:
            return None
        return [[min(lats), min(lngs)], [max(lats), max(lngs)]]


_cache = {}


def get_graph():
    g = _cache.get("graph")
    if g is None:
        g = _cache["graph"] = Graph.from_db()
    return g


def invalidate():
    _cache.pop("graph", None)
