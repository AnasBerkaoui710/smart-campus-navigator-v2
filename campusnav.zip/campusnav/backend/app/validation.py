"""Request validation helpers. Each raises ApiError(400/415/422) with a clear message."""
from datetime import datetime
from urllib.parse import urlparse

from fastapi import Request

from .errors import ApiError


async def json_body(request: Request) -> dict:
    """FastAPI dependency: the request body as a JSON object."""
    if "application/json" not in request.headers.get("content-type", ""):
        raise ApiError(415, "json_required", "Send a JSON body with Content-Type: application/json.")
    try:
        data = await request.json()
    except ValueError:
        data = None
    if not isinstance(data, dict):
        raise ApiError(400, "invalid_json", "Request body must be a JSON object.")
    return data


def string(data, key, *, required=False, min_len=0, max_len=200, default=None):
    value = data.get(key, default)
    if value is None or value == "":
        if required:
            raise ApiError(422, "validation_error", f"'{key}' is required.", {"field": key})
        return default
    if not isinstance(value, str):
        raise ApiError(422, "validation_error", f"'{key}' must be text.", {"field": key})
    value = value.strip()
    if len(value) < min_len or len(value) > max_len:
        raise ApiError(422, "validation_error", f"'{key}' must be {min_len}–{max_len} characters.",
                       {"field": key})
    return value


def integer(data, key, *, required=False, minimum=None, maximum=None, default=None):
    value = data.get(key, default)
    if value is None or value == "":
        if required:
            raise ApiError(422, "validation_error", f"'{key}' is required.", {"field": key})
        return default
    if isinstance(value, bool):
        raise ApiError(422, "validation_error", f"'{key}' must be an integer.", {"field": key})
    try:
        value = int(value)
    except (TypeError, ValueError):
        raise ApiError(422, "validation_error", f"'{key}' must be an integer.", {"field": key})
    if (minimum is not None and value < minimum) or (maximum is not None and value > maximum):
        raise ApiError(422, "validation_error", f"'{key}' is out of range.", {"field": key})
    return value


def number(data, key, *, minimum, maximum):
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ApiError(422, "validation_error", f"'{key}' must be a number.", {"field": key})
    if not minimum <= value <= maximum:
        raise ApiError(422, "validation_error", f"'{key}' is out of range.", {"field": key})
    return float(value)


def boolean(data, key, default=False):
    value = data.get(key, default)
    if not isinstance(value, bool):
        raise ApiError(422, "validation_error", f"'{key}' must be true or false.", {"field": key})
    return value


def choice(data, key, options, default=None):
    value = data.get(key, default)
    if value not in options:
        raise ApiError(422, "validation_error", f"'{key}' must be one of: {', '.join(options)}.",
                       {"field": key})
    return value


def dt(data, key, *, required=False):
    value = data.get(key)
    if not value:
        if required:
            raise ApiError(422, "validation_error", f"'{key}' is required.", {"field": key})
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        raise ApiError(422, "validation_error", f"'{key}' must be an ISO date-time, e.g. 2026-11-03T14:00.",
                       {"field": key})
    return parsed.replace(tzinfo=None, second=0, microsecond=0)


def url(data, key):
    value = string(data, key, max_len=500)
    if value is None:
        return None
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ApiError(422, "validation_error", f"'{key}' must be an http(s) URL.", {"field": key})
    return value
