from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import or_

from .. import config
from .. import validation as v
from ..errors import ApiError
from ..models import (Building, CampusLocation, DatasetInfo, Event, EventCategory, Organizer,
                      PathwayEdge, PathwayNode, db)
from ..routing.engine import NoRouteError, plan_routes, snap_point
from ..routing.graph import get_graph
from ..routing.profiles import WALKING_SPEED_MPS

router = APIRouter(tags=["public"])


def _location_or_404(location_id):
    loc = db.session.get(CampusLocation, location_id)
    if not loc:
        raise ApiError(404, "location_not_found", f"No campus location with id {location_id}.")
    return loc


@router.get("/meta")
def meta():
    info = DatasetInfo.query.first()
    graph = get_graph()
    return {
        "dataset": {"name": info.name if info else None, "is_sample": info.is_sample if info else True,
                    "notes": info.notes if info else None,
                    "origin": [info.origin_lat, info.origin_lng] if info else None,
                    "outline": info.outline if info else None},
        "bounds": graph.bounds(),
        "walking_speed_mps": WALKING_SPEED_MPS,
        "snap_max_distance_m": config.settings.snap_max_distance_m,
        "location_types": sorted({t for (t,) in db.session.query(CampusLocation.type).distinct()}),
    }


@router.get("/health")
def health():
    db.session.query(Building.id).first()
    return {"status": "ok"}


@router.get("/buildings")
def buildings():
    return [b.to_dict() for b in Building.query.order_by(Building.name)]


@router.get("/locations")
def locations(q: str = "", type_: str | None = Query(None, alias="type"), building: int | None = None, limit: int = 50):
    q = q.strip()[:100]
    limit = min(limit, 200) if limit > 0 else 50
    query = CampusLocation.query.outerjoin(Building)
    if type_:
        query = query.filter(CampusLocation.type == type_)
    if building:
        query = query.filter(CampusLocation.building_id == building)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(CampusLocation.name.ilike(like), CampusLocation.code.ilike(like),
                                 CampusLocation.room_number.ilike(like), CampusLocation.type.ilike(like),
                                 CampusLocation.keywords.ilike(like), Building.name.ilike(like),
                                 Building.code.ilike(like)))
    results = query.all()
    ql = q.lower()

    def rank(loc):
        name, room = loc.name.lower(), (loc.room_number or "").lower()
        if ql and (room == ql or room.endswith("-" + ql) or name == ql):
            return 0
        if ql and name.startswith(ql):
            return 1
        if loc.type in ("building", "library", "auditorium", "gate", "outdoor"):
            return 2
        return 3

    results.sort(key=lambda loc: (rank(loc), loc.name))
    return [loc.to_dict() for loc in results[:limit]]


@router.get("/locations/{location_id}")
def location(location_id: int):
    return _location_or_404(location_id).to_dict()


@router.get("/pathways")
def pathways():
    """Outdoor network + closures for drawing on the map (indoor detail is shown per route)."""
    nodes = {n.id: n for n in PathwayNode.query.all()}
    out = []
    for e in PathwayEdge.query.all():
        a, b = nodes[e.from_node_id], nodes[e.to_node_id]
        indoor = (a.building_id and a.kind != "entrance") or (b.building_id and b.kind != "entrance")
        if indoor and e.status == "open":
            continue
        d = e.to_dict()
        d["coords"] = [[a.lat, a.lng], [b.lat, b.lng]]
        d["indoor"] = bool(indoor)
        out.append(d)
    return out


@router.post("/nearest")
def nearest(data: dict = Depends(v.json_body)):
    lat = v.number(data, "lat", minimum=-90, maximum=90)
    lng = v.number(data, "lng", minimum=-180, maximum=180)
    node, dist = get_graph().nearest_node(lat, lng)
    if node is None:
        raise ApiError(404, "empty_graph", "No campus pathway data is loaded.")
    return {"node_id": node.id, "name": node.name, "lat": node.lat, "lng": node.lng,
            "distance_m": round(dist, 1), "within_campus": dist <= config.settings.snap_max_distance_m}


def _endpoint(data, key, graph, allow_point):
    spec = data.get(key)
    if not isinstance(spec, dict):
        raise ApiError(422, "validation_error", f"'{key}' must be an object.", {"field": key})
    if "location_id" in spec:
        loc = _location_or_404(v.integer(spec, "location_id", required=True, minimum=1))
        return {"node": loc.node_id, "location": loc}
    if "node_id" in spec:
        nid = v.integer(spec, "node_id", required=True, minimum=1)
        if nid not in graph.nodes:
            raise ApiError(404, "node_not_found", f"No pathway node with id {nid}.")
        return {"node": nid}
    if allow_point and "lat" in spec and "lng" in spec:
        lat = v.number(spec, "lat", minimum=-90, maximum=90)
        lng = v.number(spec, "lng", minimum=-180, maximum=180)
        try:
            node, dist = snap_point(graph, lat, lng, config.settings.snap_max_distance_m)
        except NoRouteError as e:
            raise ApiError(422, e.code, e.message)
        return {"node": node.id, "point": (lat, lng), "offset": dist}
    raise ApiError(422, "validation_error",
                   f"'{key}' needs location_id or node_id" + (" or lat/lng." if allow_point else "."),
                   {"field": key})


@router.post("/route")
def route(data: dict = Depends(v.json_body)):
    graph = get_graph()
    start = _endpoint(data, "from", graph, allow_point=True)
    goal = _endpoint(data, "to", graph, allow_point=False)
    profile = v.choice(data, "profile", ("shortest", "fastest"), default="shortest")
    avoid_stairs = v.boolean(data, "avoid_stairs")
    alternatives = v.boolean(data, "alternatives", default=True)
    avoid_edges = data.get("avoid_edges", [])
    if not isinstance(avoid_edges, list) or len(avoid_edges) > 100 or \
            not all(isinstance(x, int) and not isinstance(x, bool) for x in avoid_edges):
        raise ApiError(422, "validation_error", "'avoid_edges' must be a list of edge ids.")

    dest_loc = goal.get("location")
    if dest_loc is not None and not dest_loc.is_open:
        raise ApiError(409, "destination_closed",
                       f"{dest_loc.name} is temporarily unavailable"
                       + (f": {dest_loc.status_note}" if dest_loc.status_note else "."))
    destination = None
    if dest_loc is not None:
        destination = {"name": dest_loc.name, "room_number": dest_loc.room_number,
                       "building": dest_loc.building.name if dest_loc.building else None}
    try:
        result = plan_routes(graph, start["node"], goal["node"], profile, avoid_stairs, avoid_edges,
                             alternatives, start.get("point"), start.get("offset", 0.0), destination)
    except NoRouteError as e:
        raise ApiError(422, e.code, e.message)
    result["start"] = start["location"].to_dict() if start.get("location") else {
        "node_id": start["node"], "point": start.get("point")}
    result["destination"] = dest_loc.to_dict() if dest_loc else {"node_id": goal["node"]}
    return result


@router.get("/events")
def events(request: Request, q: str = "", category: str | None = None, when: str = "upcoming"):
    q = q.strip()[:100]
    now = datetime.now()
    query = Event.query.filter(Event.status == "published").join(
        CampusLocation, Event.venue_id == CampusLocation.id).join(Organizer).join(EventCategory)
    if category:
        query = query.filter(EventCategory.slug == category)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Event.title.ilike(like), Event.description.ilike(like),
                                 Organizer.name.ilike(like), CampusLocation.name.ilike(like),
                                 CampusLocation.room_number.ilike(like)))
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if when == "upcoming":
        query = query.filter(Event.ends_at >= now)
    elif when == "today":
        query = query.filter(Event.starts_at < today + timedelta(days=1), Event.ends_at >= today)
    elif when == "week":
        query = query.filter(Event.ends_at >= now, Event.starts_at < today + timedelta(days=7))
    elif when == "past":
        query = query.filter(Event.ends_at < now)
    elif when != "all":
        raise ApiError(422, "validation_error", "'when' must be upcoming, today, week, past or all.")
    params = request.query_params
    if params.get("from"):
        query = query.filter(Event.ends_at >= v.dt(params, "from"))
    if params.get("to"):
        query = query.filter(Event.starts_at <= v.dt(params, "to"))
    order = Event.starts_at.desc() if when == "past" else Event.starts_at
    return [e.to_dict() for e in query.order_by(order).limit(200)]


@router.get("/events/{event_id}")
def event(event_id: int):
    e = Event.query.filter(Event.status == "published", Event.id == event_id).first()
    if not e:
        raise ApiError(404, "event_not_found", "This event does not exist or is not published.")
    return e.to_dict()


@router.get("/categories")
def categories():
    return [c.to_dict() for c in EventCategory.query.order_by(EventCategory.name)]


@router.get("/organizers")
def organizers():
    return [o.to_dict() for o in Organizer.query.order_by(Organizer.name)]
