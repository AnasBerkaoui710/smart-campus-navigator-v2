from fastapi import APIRouter, Depends
from sqlalchemy.exc import IntegrityError

from .. import validation as v
from ..errors import ApiError
from ..importer import DatasetError, import_dataset, validate
from ..models import (CampusLocation, Event, EventCategory, Organizer, PathwayEdge, PathwayNode, db)
from ..routing.graph import get_graph, invalidate
from .auth import require_role

router = APIRouter(tags=["admin"])

EVENT_STATUSES = ("draft", "published", "cancelled")
editor = Depends(require_role("editor"))
admin = Depends(require_role("admin"))


def _get(model, id_, what):
    row = db.session.get(model, id_)
    if not row:
        raise ApiError(404, f"{what}_not_found", f"No {what.replace('_', ' ')} with id {id_}.")
    return row


# ---------------------------------------------------------------- events
@router.get("/events", dependencies=[editor])
def list_events():
    return [e.to_dict() for e in Event.query.order_by(Event.starts_at.desc())]


def _apply_event(event, data):
    event.title = v.string(data, "title", required=True, min_len=3, max_len=200)
    event.description = v.string(data, "description", max_len=5000, default="") or ""
    event.category = _get(EventCategory, v.integer(data, "category_id", required=True), "category")
    event.organizer = _get(Organizer, v.integer(data, "organizer_id", required=True), "organizer")
    venue = _get(CampusLocation, v.integer(data, "venue_id", required=True), "location")
    event.venue = venue
    event.starts_at = v.dt(data, "starts_at", required=True)
    event.ends_at = v.dt(data, "ends_at", required=True)
    if event.ends_at <= event.starts_at:
        raise ApiError(422, "validation_error", "The event must end after it starts.", {"field": "ends_at"})
    event.image_url = v.url(data, "image_url")
    event.registration_required = v.boolean(data, "registration_required")
    event.registration_url = v.url(data, "registration_url")
    event.capacity = v.integer(data, "capacity", minimum=1, maximum=100000)
    event.status = v.choice(data, "status", EVENT_STATUSES, default="draft")
    if event.status == "published":
        if not venue.is_open:
            raise ApiError(409, "venue_closed", f"{venue.name} is marked unavailable; choose another venue.")
        if venue.node_id not in get_graph().reachable_from_gates():
            raise ApiError(409, "venue_unreachable",
                           f"No open walking route reaches {venue.name}; it cannot be published.")
    event.is_sample = False


@router.post("/events", status_code=201, dependencies=[editor])
def create_event(data: dict = Depends(v.json_body)):
    event = Event()
    _apply_event(event, data)
    db.session.add(event)
    db.session.commit()
    return event.to_dict()


@router.put("/events/{event_id}", dependencies=[editor])
def update_event(event_id: int, data: dict = Depends(v.json_body)):
    event = _get(Event, event_id, "event")
    _apply_event(event, data)
    db.session.commit()
    return event.to_dict()


@router.delete("/events/{event_id}", dependencies=[editor])
def delete_event(event_id: int):
    db.session.delete(_get(Event, event_id, "event"))
    db.session.commit()
    return {"ok": True}


# ---------------------------------------------------------------- closures
@router.patch("/edges/{edge_id}", dependencies=[editor])
def update_edge(edge_id: int, data: dict = Depends(v.json_body)):
    edge = _get(PathwayEdge, edge_id, "edge")
    edge.status = v.choice(data, "status", ("open", "closed"), default=edge.status)
    edge.status_note = v.string(data, "status_note", max_len=300)
    if "restricted" in data:
        edge.restricted = v.boolean(data, "restricted")
    db.session.commit()
    invalidate()
    return edge.to_dict()


@router.patch("/locations/{location_id}/status", dependencies=[editor])
def location_status(location_id: int, data: dict = Depends(v.json_body)):
    loc = _get(CampusLocation, location_id, "location")
    loc.is_open = v.boolean(data, "is_open", default=loc.is_open)
    loc.status_note = v.string(data, "status_note", max_len=300)
    db.session.commit()
    return loc.to_dict()


# ---------------------------------------------------------------- facilities
def _apply_location(loc, data):
    loc.code = v.string(data, "code", required=True, max_len=60)
    loc.name = v.string(data, "name", required=True, max_len=200)
    loc.type = v.string(data, "type", required=True, max_len=40)
    node = _get(PathwayNode, v.integer(data, "node_id", required=True), "node")
    loc.node_id = node.id
    loc.building_id = node.building_id
    loc.floor = node.floor
    loc.room_number = v.string(data, "room_number", max_len=40)
    loc.description = v.string(data, "description", max_len=2000, default="") or ""
    loc.keywords = v.string(data, "keywords", max_len=400, default="") or ""
    clash = CampusLocation.query.filter(CampusLocation.code == loc.code, CampusLocation.id != loc.id).first()
    if clash:
        raise ApiError(409, "duplicate_code", f"Location code '{loc.code}' is already used.")


@router.post("/locations", status_code=201, dependencies=[admin])
def create_location(data: dict = Depends(v.json_body)):
    loc = CampusLocation()
    _apply_location(loc, data)
    db.session.add(loc)
    db.session.commit()
    return loc.to_dict()


@router.put("/locations/{location_id}", dependencies=[admin])
def update_location(location_id: int, data: dict = Depends(v.json_body)):
    loc = _get(CampusLocation, location_id, "location")
    _apply_location(loc, data)
    db.session.commit()
    return loc.to_dict()


@router.get("/nodes", dependencies=[editor])
def list_nodes():
    return [n.to_dict() for n in PathwayNode.query.order_by(PathwayNode.code)]


# ---------------------------------------------------------------- lookups
def _commit_unique(what):
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise ApiError(409, "duplicate", f"A {what} with that name already exists.")


def _lookup_routes(model, what, plural, fields):
    def create(data: dict = Depends(v.json_body)):
        values = {f: v.string(data, f, required=(f in ("name", "slug")), max_len=255) for f in fields}
        row = model(**{f: val for f, val in values.items() if val is not None})  # keep column defaults
        db.session.add(row)
        _commit_unique(what)
        return row.to_dict()

    def update(row_id: int, data: dict = Depends(v.json_body)):
        row = _get(model, row_id, what)
        for f in fields:
            setattr(row, f, v.string(data, f, required=(f in ("name", "slug")), max_len=255))
        _commit_unique(what)
        return row.to_dict()

    def delete(row_id: int):
        row = _get(model, row_id, what)
        fk = Event.category_id if model is EventCategory else Event.organizer_id
        if Event.query.filter(fk == row_id).first():
            raise ApiError(409, "in_use", f"This {what} is used by events and cannot be deleted.")
        db.session.delete(row)
        db.session.commit()
        return {"ok": True}

    router.add_api_route(f"/{plural}", create, methods=["POST"], status_code=201, dependencies=[admin])
    router.add_api_route(f"/{plural}/{{row_id}}", update, methods=["PUT"], dependencies=[admin])
    router.add_api_route(f"/{plural}/{{row_id}}", delete, methods=["DELETE"], dependencies=[admin])


_lookup_routes(EventCategory, "category", "categories", ("slug", "name", "color"))
_lookup_routes(Organizer, "organizer", "organizers", ("name", "department", "contact_email"))


# ---------------------------------------------------------------- data import
@router.post("/import", dependencies=[admin])
def import_pathways(dry_run: int = 0, data: dict = Depends(v.json_body)):
    if dry_run == 1:
        errors, warnings = validate(data)
        return {"valid": not errors, "errors": errors, "warnings": warnings}
    try:
        summary = import_dataset(data)
    except DatasetError as e:
        db.session.rollback()
        raise ApiError(422, "invalid_dataset", "The dataset was rejected.", {"errors": e.errors[:50]})
    invalidate()
    return summary
