import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, Request

from .. import validation as v
from ..errors import ApiError
from ..models import User, db

router = APIRouter(tags=["auth"])

ROLE_LEVEL = {"editor": 1, "admin": 2}
_failures = defaultdict(deque)  # ip -> timestamps of recent failed logins
MAX_FAILURES, WINDOW_S = 5, 300


def current_user(request: Request):
    uid = request.session.get("uid")
    return db.session.get(User, uid) if uid else None


def require_role(role):
    """Dependency factory: the session user must have at least `role`. Mutating requests
    must be JSON, which (with SameSite=Lax cookies) blocks cross-site form submissions."""
    def dependency(request: Request) -> User:
        user = current_user(request)
        if not user:
            raise ApiError(401, "unauthenticated", "Please sign in.")
        if ROLE_LEVEL.get(user.role, 0) < ROLE_LEVEL[role]:
            raise ApiError(403, "forbidden", "You do not have permission for this action.")
        if request.method in ("POST", "PUT", "PATCH", "DELETE") \
                and "application/json" not in request.headers.get("content-type", ""):
            raise ApiError(415, "json_required", "Send a JSON body with Content-Type: application/json.")
        return user
    return dependency


@router.post("/login")
def login(request: Request, data: dict = Depends(v.json_body)):
    ip = request.client.host if request.client else "?"
    recent = _failures[ip]
    while recent and recent[0] < time.time() - WINDOW_S:
        recent.popleft()
    if len(recent) >= MAX_FAILURES:
        raise ApiError(429, "too_many_attempts", "Too many failed sign-in attempts. Try again in a few minutes.")
    email = v.string(data, "email", required=True, max_len=255).lower()
    password = v.string(data, "password", required=True, max_len=200)
    user = User.query.filter(db.func.lower(User.email) == email).first()
    if not user or not user.check_password(password):
        recent.append(time.time())
        raise ApiError(401, "invalid_credentials", "Email or password is incorrect.")
    request.session.clear()
    request.session["uid"] = user.id
    return user.to_dict()


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@router.get("/me")
def me(request: Request):
    user = current_user(request)
    if not user:
        raise ApiError(401, "unauthenticated", "Not signed in.")
    return user.to_dict()
