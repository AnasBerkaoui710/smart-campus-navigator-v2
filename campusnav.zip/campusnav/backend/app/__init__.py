from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from . import config
from .database import RequestScope, db
from .errors import register_error_handlers
from .routing.graph import invalidate


def create_app(testing: bool = False) -> FastAPI:
    config.settings = config.test_settings() if testing else config.load_settings()
    s = config.settings
    db.init(s.database_url)
    invalidate()

    app = FastAPI(
        title="CampusNav API",
        version="1.0",
        description="Campus map, events and pedestrian routing. Interactive docs at /docs. "
                    "Staff endpoints under /api/admin need a session from POST /api/auth/login.",
    )
    register_error_handlers(app)

    from .api.admin import router as admin_router
    from .api.auth import router as auth_router
    from .api.public import router as public_router
    from .api.assistant import router as assistant_router
    app.include_router(assistant_router, prefix="/api/assistant")
    app.include_router(public_router, prefix="/api")
    app.include_router(auth_router, prefix="/api/auth")
    app.include_router(admin_router, prefix="/api/admin")

    frontend = s.frontend_dir

    @app.get("/admin", include_in_schema=False)
    def admin_page():
        return FileResponse(frontend / "admin.html")

    @app.get("/sw.js", include_in_schema=False)
    def service_worker():
        return FileResponse(frontend / "sw.js", media_type="text/javascript",
                            headers={"Service-Worker-Allowed": "/"})

    # Static frontend (index.html at "/"); registered last so /api/* wins.
    app.mount("/", StaticFiles(directory=str(frontend), html=True), name="frontend")

    @app.middleware("http")
    async def headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        # Map tile servers (OpenStreetMap policy) require the origin as Referer on cross-origin requests.
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        if not request.url.path.startswith(("/api", "/docs", "/openapi")):
            resp.headers["Cache-Control"] = "no-cache"  # revalidate so deployments show up at once
        return resp

    # Order matters: the last added runs outermost. Sessions need to be inside RequestScope.
    app.add_middleware(SessionMiddleware, secret_key=s.secret_key, session_cookie="campusnav_session",
                       same_site="lax", https_only=s.cookie_secure, max_age=60 * 60 * 12)
    app.add_middleware(RequestScope)
    return app
