from datetime import datetime, timezone

from werkzeug.security import check_password_hash, generate_password_hash

from .database import db


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="editor")  # 'admin' | 'editor'
    created_at = db.Column(db.DateTime, default=utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "role": self.role}


class DatasetInfo(db.Model):
    __tablename__ = "dataset_info"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    is_sample = db.Column(db.Boolean, nullable=False, default=True)
    origin_lat = db.Column(db.Float, nullable=False)
    origin_lng = db.Column(db.Float, nullable=False)
    notes = db.Column(db.Text)
    outline = db.Column(db.JSON)  # campus boundary [[lat, lng], ...]
    imported_at = db.Column(db.DateTime, default=utcnow)


class Building(db.Model):
    __tablename__ = "buildings"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    footprint = db.Column(db.JSON)  # [[lat, lng], ...]
    floors_min = db.Column(db.Integer, default=0)
    floors_max = db.Column(db.Integer, default=0)
    data_source = db.Column(db.String(20), default="sample")
    is_open = db.Column(db.Boolean, default=True, nullable=False)

    def to_dict(self):
        return {"id": self.id, "code": self.code, "name": self.name, "description": self.description,
                "lat": self.lat, "lng": self.lng, "footprint": self.footprint,
                "floors": [self.floors_min, self.floors_max], "data_source": self.data_source,
                "is_open": self.is_open}


class PathwayNode(db.Model):
    __tablename__ = "pathway_nodes"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(60), unique=True, nullable=False)
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    floor = db.Column(db.Integer, nullable=False, default=0)
    building_id = db.Column(db.Integer, db.ForeignKey("buildings.id"), nullable=True)
    kind = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(200))
    accessible = db.Column(db.Boolean, nullable=True)  # None = not surveyed

    building = db.relationship("Building")

    def to_dict(self):
        return {"id": self.id, "code": self.code, "lat": self.lat, "lng": self.lng, "floor": self.floor,
                "building_id": self.building_id, "kind": self.kind, "name": self.name,
                "accessible": self.accessible}


class PathwayEdge(db.Model):
    __tablename__ = "pathway_edges"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(130), unique=True, nullable=False)
    from_node_id = db.Column(db.Integer, db.ForeignKey("pathway_nodes.id"), nullable=False)
    to_node_id = db.Column(db.Integer, db.ForeignKey("pathway_nodes.id"), nullable=False)
    kind = db.Column(db.String(20), nullable=False)
    length_m = db.Column(db.Float, nullable=False)
    accessible = db.Column(db.Boolean, nullable=True)  # None = not surveyed
    bidirectional = db.Column(db.Boolean, nullable=False, default=True)
    name = db.Column(db.String(200))
    status = db.Column(db.String(20), nullable=False, default="open")  # 'open' | 'closed'
    status_note = db.Column(db.String(300))
    restricted = db.Column(db.Boolean, nullable=False, default=False)

    from_node = db.relationship("PathwayNode", foreign_keys=[from_node_id])
    to_node = db.relationship("PathwayNode", foreign_keys=[to_node_id])

    def to_dict(self):
        return {"id": self.id, "code": self.code, "from": self.from_node_id, "to": self.to_node_id,
                "kind": self.kind, "length_m": round(self.length_m, 1), "accessible": self.accessible,
                "bidirectional": self.bidirectional, "name": self.name, "status": self.status,
                "status_note": self.status_note, "restricted": self.restricted}


class CampusLocation(db.Model):
    __tablename__ = "campus_locations"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(60), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(40), nullable=False)
    building_id = db.Column(db.Integer, db.ForeignKey("buildings.id"), nullable=True)
    floor = db.Column(db.Integer, default=0)
    room_number = db.Column(db.String(40))
    node_id = db.Column(db.Integer, db.ForeignKey("pathway_nodes.id"), nullable=False)
    description = db.Column(db.Text, default="")
    keywords = db.Column(db.String(400), default="")
    is_open = db.Column(db.Boolean, default=True, nullable=False)
    status_note = db.Column(db.String(300))

    building = db.relationship("Building")
    node = db.relationship("PathwayNode")

    def to_dict(self):
        return {"id": self.id, "code": self.code, "name": self.name, "type": self.type,
                "building": {"id": self.building.id, "code": self.building.code, "name": self.building.name}
                if self.building else None,
                "floor": self.floor, "room_number": self.room_number, "node_id": self.node_id,
                "lat": self.node.lat, "lng": self.node.lng, "description": self.description,
                "keywords": self.keywords, "is_open": self.is_open, "status_note": self.status_note}


class EventCategory(db.Model):
    __tablename__ = "event_categories"
    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    color = db.Column(db.String(9), default="#2563eb")

    def to_dict(self):
        return {"id": self.id, "slug": self.slug, "name": self.name, "color": self.color}


class Organizer(db.Model):
    __tablename__ = "organizers"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), unique=True, nullable=False)
    department = db.Column(db.String(200))
    contact_email = db.Column(db.String(255))

    def to_dict(self):
        return {"id": self.id, "name": self.name, "department": self.department,
                "contact_email": self.contact_email}


class Event(db.Model):
    __tablename__ = "events"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    category_id = db.Column(db.Integer, db.ForeignKey("event_categories.id"), nullable=False)
    organizer_id = db.Column(db.Integer, db.ForeignKey("organizers.id"), nullable=False)
    venue_id = db.Column(db.Integer, db.ForeignKey("campus_locations.id"), nullable=False)
    starts_at = db.Column(db.DateTime, nullable=False)
    ends_at = db.Column(db.DateTime, nullable=False)
    image_url = db.Column(db.String(500))
    registration_required = db.Column(db.Boolean, default=False, nullable=False)
    registration_url = db.Column(db.String(500))
    capacity = db.Column(db.Integer)
    status = db.Column(db.String(20), nullable=False, default="draft")  # draft | published | cancelled
    is_sample = db.Column(db.Boolean, nullable=False, default=False)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)

    category = db.relationship("EventCategory")
    organizer = db.relationship("Organizer")
    venue = db.relationship("CampusLocation")

    def to_dict(self):
        return {"id": self.id, "title": self.title, "description": self.description,
                "category": self.category.to_dict(), "organizer": self.organizer.to_dict(),
                "venue": self.venue.to_dict(),
                "starts_at": self.starts_at.isoformat(timespec="minutes"),
                "ends_at": self.ends_at.isoformat(timespec="minutes"),
                "image_url": self.image_url, "registration_required": self.registration_required,
                "registration_url": self.registration_url, "capacity": self.capacity,
                "status": self.status, "is_sample": self.is_sample}


class AccessibilityPreference(db.Model):
    __tablename__ = "accessibility_prefs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    avoid_stairs = db.Column(db.Boolean, default=False, nullable=False)
    default_profile = db.Column(db.String(20), default="shortest", nullable=False)
