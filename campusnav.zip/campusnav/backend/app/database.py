"""SQLAlchemy setup without Flask.

`db` mimics the small slice of the Flask-SQLAlchemy API the models and importer use
(`db.Model`, `db.Column`, `db.session`, `Model.query`, `db.create_all()`), so the
data layer is framework-independent.

Sessions are scoped to the current *request*: an ASGI middleware sets a context
variable per request (copied into FastAPI's worker threads) and removes the session
when the response is done. Outside a request (CLI, tests) the scope is 0.
"""
import contextvars
import itertools

from sqlalchemy import (JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text,
                        create_engine, func)
from sqlalchemy.orm import DeclarativeBase, relationship, scoped_session, sessionmaker
from sqlalchemy.pool import StaticPool

_scope = contextvars.ContextVar("db_scope", default=0)
_counter = itertools.count(1)


class Base(DeclarativeBase):
    pass


class _Database:
    Model = Base
    Column, Integer, String, Text, Float, Boolean, DateTime, JSON = Column, Integer, String, Text, Float, Boolean, DateTime, JSON
    ForeignKey, func = ForeignKey, func
    relationship = staticmethod(relationship)

    def __init__(self):
        self.engine = None
        self.session = scoped_session(sessionmaker(expire_on_commit=True), scopefunc=_scope.get)

    def init(self, url):
        self.session.remove()
        if self.engine is not None:
            self.engine.dispose()
        kwargs = {}
        if url.startswith("sqlite"):
            kwargs["connect_args"] = {"check_same_thread": False}
            if url in ("sqlite://", "sqlite:///:memory:"):
                kwargs["poolclass"] = StaticPool  # one shared in-memory connection
        self.engine = create_engine(url, **kwargs)
        self.session.configure(bind=self.engine)

    def create_all(self):
        Base.metadata.create_all(self.engine)

    def drop_all(self):
        Base.metadata.drop_all(self.engine)


db = _Database()
Base.query = db.session.query_property()


class RequestScope:
    """Pure-ASGI middleware: one DB session per HTTP request, always cleaned up."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        token = _scope.set(next(_counter))
        try:
            await self.app(scope, receive, send)
        finally:
            db.session.remove()
            _scope.reset(token)
