"""Production entry point (ASGI):  uvicorn wsgi:app --host 0.0.0.0 --port 8000 --workers 2
Run `python manage.py init-db` first to create the tables (and the sample data, if wanted)."""
from app import create_app

app = create_app()
