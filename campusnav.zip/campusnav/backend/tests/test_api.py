from datetime import datetime, timedelta

from .conftest import TEST_EDITOR, loc_id, login


def route(client, **body):
    body.setdefault("from", {"location_id": loc_id(client, "gate-main")})
    return client.post("/api/route", json=body)


# ---------------------------------------------------------------- data integrity
def test_meta_flags_provisional_data_and_has_outline(client):
    meta = client.get("/api/meta").json()
    assert meta["dataset"]["is_sample"] is True
    assert "FST" in meta["dataset"]["name"]
    assert len(meta["dataset"]["outline"]) >= 4
    lat, lng = meta["dataset"]["origin"]
    assert 32.3 < lat < 32.5 and -6.5 < lng < -6.2  # Beni Mellal


def test_campus_has_two_and_three_floor_buildings(client):
    floors = {b["code"]: b["floors"] for b in client.get("/api/buildings").json()}
    spans = {code: f[1] - f[0] + 1 for code, f in floors.items()}
    assert 3 in spans.values() and 2 in spans.values()
    assert spans["LIB"] == 3 and spans["ADM"] == 2


def test_every_event_venue_is_routable(client):
    events = client.get("/api/events?when=all").json()
    assert len(events) >= 10
    gate = loc_id(client, "gate-main")
    for ev in events:
        assert ev["venue"]["node_id"]
        r = client.post("/api/route", json={"from": {"location_id": gate}, "to": {"location_id": ev["venue"]["id"]}})
        assert r.status_code == 200, (ev["title"], r.json())


def test_every_location_reachable_from_both_gates(client):
    for gate_code in ("gate-main", "gate-east"):
        gate = loc_id(client, gate_code)
        for loc in client.get("/api/locations?limit=200").json():
            r = client.post("/api/route", json={"from": {"location_id": gate}, "to": {"location_id": loc["id"]},
                                                "alternatives": False})
            assert r.status_code == 200, (gate_code, loc["code"])


# ---------------------------------------------------------------- search
def test_search_by_room_number(client):
    results = client.get("/api/locations?q=201").json()
    assert len(results) >= 4
    assert all(r["room_number"].endswith("-201") for r in results[:4])


def test_search_by_type_keyword_and_name(client):
    assert any(r["code"] == "caf-g01" for r in client.get("/api/locations?q=coffee").json())
    labs = client.get("/api/locations?type=laboratory").json()
    assert labs and all(r["type"] == "laboratory" for r in labs)
    assert client.get("/api/locations?q=bibliotheque").json()[0]["code"] == "lib"


# ---------------------------------------------------------------- routing
def test_route_to_top_floor_has_floor_change_steps(client):
    r = route(client, to={"location_id": loc_id(client, "dmi-201")}).json()
    primary = r["routes"][0]
    assert primary["distance_m"] > 0 and primary["duration_s"] > 0
    assert 2 in primary["floors"]
    assert "floor 2" in " | ".join(s["text"] for s in primary["steps"])
    assert primary["steps"][-1]["kind"] == "arrive"
    assert all(s["edge_ids"] is not None for s in primary["steps"])


def test_avoid_stairs_uses_elevator(client):
    primary = route(client, to={"location_id": loc_id(client, "dmi-201")}, avoid_stairs=True).json()["routes"][0]
    assert not primary["uses_stairs"]
    assert primary["uses_elevator"]


def test_building_without_lift_has_no_step_free_upper_floor(client):
    r = route(client, to={"location_id": loc_id(client, "dbg-201")}, avoid_stairs=True)
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "no_step_free_route"
    assert route(client, to={"location_id": loc_id(client, "dbg-201")}).status_code == 200


def test_unsurveyed_entrance_reported_as_incomplete(client):
    r = route(client, to={"location_id": loc_id(client, "dcp-g01")}, avoid_stairs=True).json()
    assert r["routes"][0]["accessibility"] == "incomplete"
    assert any("not been surveyed" in w for w in r["warnings"])


def test_gps_far_away_is_outside_campus(client):
    r = client.post("/api/route", json={"from": {"lat": 48.85, "lng": 2.35},
                                        "to": {"location_id": loc_id(client, "lib")}})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "outside_campus"


def test_gps_near_the_gate_snaps_and_adds_approach(client):
    gate = next(l for l in client.get("/api/locations?type=gate").json() if l["code"] == "gate-main")
    r = client.post("/api/route", json={"from": {"lat": gate["lat"] + 0.00015, "lng": gate["lng"]},
                                        "to": {"location_id": loc_id(client, "lib")}}).json()
    assert r["routes"][0]["steps"][0]["kind"] == "approach"


def test_route_validation_errors(client):
    assert client.post("/api/route", content=b"x").status_code == 415
    assert client.post("/api/route", json={"to": {"location_id": 1}}).status_code == 422
    assert client.post("/api/route", json={"from": {"location_id": 1}, "to": {"location_id": 99999}}).status_code == 404
    assert route(client, to={"location_id": 1}, profile="teleport").status_code == 422
    assert route(client, to={"location_id": 1}, avoid_edges="all").status_code == 422


# ---------------------------------------------------------------- admin
def test_admin_requires_login(client):
    assert client.get("/api/admin/events").status_code == 401


def test_closing_a_ring_road_segment_reroutes(admin):
    dest = loc_id(admin, "dbg-g01")
    first = route(admin, to={"location_id": dest}).json()["routes"][0]
    ring = {e["id"]: e for e in admin.get("/api/pathways").json() if e["name"] == "Campus ring road"}
    used = [eid for eid in first["edge_ids"] if eid in ring]
    assert used, "route should use the ring road"
    r = admin.patch(f"/api/admin/edges/{used[0]}", json={"status": "closed", "status_note": "Works"})
    assert r.status_code == 200
    again = route(admin, to={"location_id": dest})
    assert again.status_code == 200
    assert used[0] not in again.json()["routes"][0]["edge_ids"]


def test_closed_destination_is_rejected(admin):
    lid = loc_id(admin, "dmi-g02")
    admin.patch(f"/api/admin/locations/{lid}/status", json={"is_open": False, "status_note": "Renovation"})
    r = route(admin, to={"location_id": lid})
    assert r.status_code == 409 and "Renovation" in r.json()["error"]["message"]


def _event_body(client, **over):
    start = datetime.now() + timedelta(days=3)
    body = {"title": "Test Event", "description": "x", "category_id": 1, "organizer_id": 1,
            "venue_id": loc_id(client, "amp-g01"), "starts_at": start.isoformat(timespec="minutes"),
            "ends_at": (start + timedelta(hours=2)).isoformat(timespec="minutes"), "status": "published"}
    body.update(over)
    return body


def test_event_crud_and_validation(client):
    login(client, TEST_EDITOR)
    r = client.post("/api/admin/events", json=_event_body(client))
    assert r.status_code == 201
    eid = r.json()["id"]
    assert client.get(f"/api/events/{eid}").json()["venue"]["code"] == "amp-g01"

    bad = _event_body(client, ends_at="2000-01-01T00:00")
    assert client.post("/api/admin/events", json=bad).status_code == 422
    assert client.post("/api/admin/events", json=_event_body(client, venue_id=99999)).status_code == 404
    assert client.post("/api/admin/events", json=_event_body(client, registration_url="javascript:alert(1)")).status_code == 422

    assert client.request("DELETE", f"/api/admin/events/{eid}", json={}).status_code == 200
    assert client.get(f"/api/events/{eid}").status_code == 404


def test_editor_cannot_import(client):
    login(client, TEST_EDITOR)
    assert client.post("/api/admin/import", json={}).status_code == 403


def test_cannot_publish_at_unreachable_venue(admin):
    for e in admin.get("/api/pathways").json():
        if e["code"].startswith("ADM-ENT"):  # the administration building has a single entrance
            admin.patch(f"/api/admin/edges/{e['id']}", json={"status": "closed"})
    r = admin.post("/api/admin/events", json=_event_body(admin, venue_id=loc_id(admin, "adm-103")))
    assert r.status_code == 409


def test_import_rejects_bad_dataset(admin):
    r = admin.post("/api/admin/import", json={"format": "campusnav-pathways/1", "name": "x",
                                              "nodes": [], "edges": [{"code": "e", "from": "a", "to": "b",
                                                                      "kind": "walkway"}],
                                              "locations": []})
    assert r.status_code == 422


def test_login_rejects_wrong_password(client):
    r = client.post("/api/auth/login", json={"email": "admin@test.example", "password": "nope"})
    assert r.status_code == 401
