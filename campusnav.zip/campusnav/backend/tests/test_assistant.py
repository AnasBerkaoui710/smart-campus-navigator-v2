"""Assistant tests. Gemini itself is faked: we test the tool layer, actions, streaming, fallbacks, validation and limits."""
import json

import httpx
import pytest

from app import config
from app.api import assistant

from .conftest import loc_id


@pytest.fixture(autouse=True)
def _fast_and_clean(monkeypatch):
    assistant._hits.clear()
    monkeypatch.setattr(assistant, "RETRY_DELAYS", (0,))   # no sleeping in tests


def http_error(code):
    req = httpx.Request("POST", "http://gemini.test")
    return httpx.HTTPStatusError(str(code), request=req, response=httpx.Response(code, request=req))


def fake_gemini(monkeypatch, rounds, fail=None):
    """rounds: list of lists of parts; each *successful* stream consumes the next round.
    fail: {model_name: status_code} -> that model raises HTTPStatusError before producing output."""
    calls = {"n": 0, "bodies": [], "models": []}

    async def fake(model, body):
        calls["models"].append(model)
        if fail and model in fail:
            raise http_error(fail[model])
        calls["bodies"].append(body)
        parts = rounds[min(calls["n"], len(rounds) - 1)]
        calls["n"] += 1
        for p in parts:  # one chunk per part, like a real stream
            yield {"candidates": [{"content": {"role": "model", "parts": [p]}}]}

    monkeypatch.setattr(assistant, "gemini_stream", fake)
    return calls


def sse(response):
    return [json.loads(line[6:]) for line in response.text.splitlines() if line.startswith("data: ")]


def ask(client, text="hello", **ctx):
    return client.post("/api/assistant/chat", json={"messages": [{"role": "user", "text": text}], "context": ctx})


def keyed():
    config.settings.gemini_api_key = "test-key"


# ---------------------------------------------------------------- endpoint behaviour
def test_status_and_unconfigured_chat(client):
    s = client.get("/api/assistant/status").json()
    assert s["available"] is False and s["name"] == "Ghoula"
    r = ask(client)
    assert r.status_code == 503 and r.json()["error"]["code"] == "assistant_unavailable"


def test_chat_streams_text_and_runs_tools(client, monkeypatch):
    keyed()
    calls = fake_gemini(monkeypatch, [
        [{"functionCall": {"name": "navigate_to_place", "args": {"place_name": "library", "avoid_stairs": True, "start_now": True}, "id": "c1"},
          "thoughtSignature": "sig"}],
        [{"text": "Opening step-free "}, {"text": "directions to the library."}],
    ])
    r = ask(client, "take me to the library, step-free", page="home")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/event-stream")
    events = sse(r)
    assert any(e["type"] == "action" for e in events), events
    action = next(e for e in events if e["type"] == "action")
    assert action["kind"] == "navigate" and f"to={loc_id(client, 'lib')}" in action["hash"]
    assert "stepfree=1" in action["hash"] and "go=1" in action["hash"]
    assert "".join(e["text"] for e in events if e["type"] == "text") == "Opening step-free directions to the library."
    assert events[-1] == {"type": "done"}
    second = calls["bodies"][1]["contents"]     # raw model part (with its thought signature) is sent back with the tool result
    assert second[-2]["parts"][0]["thoughtSignature"] == "sig"
    assert second[-1]["parts"][0]["functionResponse"]["response"]["ok"] is True
    assert "Ghoula" in calls["bodies"][0]["systemInstruction"]["parts"][0]["text"]


def test_context_reaches_the_prompt(client, monkeypatch):
    keyed()
    calls = fake_gemini(monkeypatch, [[{"text": "ok"}]])
    ask(client, "how long?", page="map", destination="Library", start="Main Gate", route_minutes=7, route_meters=474,
        navigating=True, instruction="Turn left along the ring road", avoid_stairs=True, profile="fastest")
    prompt = calls["bodies"][0]["systemInstruction"]["parts"][0]["text"]
    for needle in ("Library", "Main Gate", "7 min / 474 m (fastest)", "Turn left along the ring road", "step-free ON", '"map" page'):
        assert needle in prompt, needle


def test_falls_back_to_next_model_on_429_and_503(client, monkeypatch):
    keyed()
    first, second, third = config.settings.chat_models[:3]
    calls = fake_gemini(monkeypatch, [[{"text": "Hello from the fallback."}]], fail={first: 429, second: 503})
    events = sse(ask(client))
    assert "".join(e["text"] for e in events if e["type"] == "text") == "Hello from the fallback."
    assert calls["models"][:3] == [first, second, third]
    assert not any(e["type"] == "error" for e in events)


def test_all_models_failing_gives_friendly_error(client, monkeypatch):
    keyed()
    fake_gemini(monkeypatch, [[{"text": "x"}]], fail={m: 429 for m in config.settings.chat_models})
    events = sse(ask(client))
    assert events[0]["type"] == "error" and "lot of requests" in events[0]["message"]
    assert "key" not in events[0]["message"].lower()


def test_transport_failure_is_reported_as_error_event(client, monkeypatch):
    keyed()

    async def boom(model, body):
        raise httpx.ConnectError("down")
        yield  # pragma: no cover

    monkeypatch.setattr(assistant, "gemini_stream", boom)
    events = sse(ask(client))
    assert events[0]["type"] == "error"


def test_model_rejecting_thinking_is_retried_without_it(client, monkeypatch):
    keyed()
    seen = []

    async def fake(model, body):
        seen.append("thinkingConfig" in body["generationConfig"])
        if seen[-1]:
            raise http_error(400)
        yield {"candidates": [{"content": {"parts": [{"text": "fine"}]}}]}

    monkeypatch.setattr(assistant, "gemini_stream", fake)
    events = sse(ask(client))
    assert seen[:2] == [True, False]
    assert "".join(e["text"] for e in events if e["type"] == "text") == "fine"


def test_chat_validation(client):
    keyed()
    bad = [{"messages": []}, {"messages": "hi"}, {"messages": [{"role": "system", "text": "x"}]},
           {"messages": [{"role": "assistant", "text": "last must be user"}]},
           {"messages": [{"role": "user", "text": "x"}] * 17}]
    for body in bad:
        assert client.post("/api/assistant/chat", json=body).status_code == 422, body
    assert client.post("/api/assistant/chat", content=b"x").status_code == 415


def test_chat_is_rate_limited(client, monkeypatch):
    keyed()
    fake_gemini(monkeypatch, [[{"text": "ok"}]])
    codes = [ask(client).status_code for _ in range(17)]
    assert codes[:15] == [200] * 15 and codes[15:] == [429, 429]


def test_title_generation(client, monkeypatch):
    keyed()

    async def fake(models, body, timeout=40):
        return {"candidates": [{"content": {"parts": [{"text": '"Directions to the library."\nextra'}]}}]}

    monkeypatch.setattr(assistant, "gemini_generate", fake)
    r = client.post("/api/assistant/title", json={"user": "take me to the library", "assistant": "Opening directions."})
    assert r.status_code == 200 and r.json()["title"] == "Directions to the library"
    assert client.post("/api/assistant/title", json={}).status_code == 422

    async def down(models, body, timeout=40):
        raise assistant.UpstreamError(429)

    monkeypatch.setattr(assistant, "gemini_generate", down)
    assert client.post("/api/assistant/title", json={"user": "hi"}).status_code == 502


def test_speak_and_transcribe_validation(client):
    keyed()
    assert client.post("/api/assistant/speak", json={}).status_code == 422
    assert client.post("/api/assistant/speak", json={"text": "hi", "voice": "Darth"}).status_code == 422
    assert client.post("/api/assistant/transcribe", json={"audio": "!!not base64!!"}).status_code == 422
    assert client.post("/api/assistant/transcribe", json={"audio": "AAAA", "mime_type": "video/mp4"}).status_code == 422


def test_speak_and_transcribe_use_fallback_chain(client, monkeypatch):
    keyed()
    seen = []

    async def fake(models, body, timeout=40):
        seen.append(list(models))
        if "responseModalities" in body.get("generationConfig", {}):
            pcm = base64.b64encode(b"\x00\x00" * 8).decode()
            return {"candidates": [{"content": {"parts": [{"inlineData": {"mimeType": "audio/L16;codec=pcm;rate=24000", "data": pcm}}]}}]}
        return {"candidates": [{"content": {"parts": [{"text": " bonjour "}]}}]}

    import base64
    monkeypatch.setattr(assistant, "gemini_generate", fake)
    wav = client.post("/api/assistant/speak", json={"text": "Bonjour"})
    assert wav.status_code == 200 and wav.content[:4] == b"RIFF" and wav.headers["content-type"] == "audio/wav"
    t = client.post("/api/assistant/transcribe", json={"audio": base64.b64encode(b"RIFFxxxx").decode()})
    assert t.json() == {"text": "bonjour"}
    assert seen[0] == list(config.settings.tts_models) and seen[1][0] == config.settings.stt_model


# ---------------------------------------------------------------- tools
def test_search_tools_use_the_database(client):
    r, action = assistant._run_tool("search_places", {"query": "library"})
    assert action is None and any(p["name"] == "University Library" for p in r["places"])
    r, _ = assistant._run_tool("search_places", {"type": "computer_lab"})
    assert r["count"] >= 3 and all(p["type"] == "computer_lab" for p in r["places"])
    r, _ = assistant._run_tool("search_events", {"query": "machine learning"})
    assert r["count"] == 1 and r["events"][0]["venue"] == "Computer Lab 1"


def test_place_names_tolerate_typos_and_room_numbers(client):
    assert assistant._run_tool("search_places", {"query": "cafitiria"})[0]["places"][0]["name"] in ("Cafeteria", "Main Cafeteria")
    assert assistant._run_tool("search_places", {"query": "bibliotheque"})[0]["places"][0]["name"] == "University Library"
    assert assistant._run_tool("search_places", {"query": "101"})[0]["count"] >= 3
    _, action = assistant._run_tool("navigate_to_place", {"place_name": "DMI-101"})
    assert f"to={loc_id(client, 'dmi-101')}" in action["hash"]


def test_navigate_by_name_and_ambiguity(client):
    result, action = assistant._run_tool("navigate_to_place", {"place_name": "library", "start_place_name": "main gate", "avoid_stairs": True})
    assert result["ok"] and action["kind"] == "navigate"
    assert f"to={loc_id(client, 'lib')}" in action["hash"] and f"from={loc_id(client, 'gate-main')}" in action["hash"] and "stepfree=1" in action["hash"]
    result, action = assistant._run_tool("navigate_to_place", {"place_name": "lab"})
    assert result["ok"] is False and result["ambiguous"] and len(result["candidates"]) >= 2 and action is None
    result, _ = assistant._run_tool("navigate_to_place", {"place_name": "zzzzzz"})
    assert result["ok"] is False and "No place matches" in result["error"]
    result, _ = assistant._run_tool("navigate_to_place", {"place_name": "library", "start_place_name": "zzzzzz"})
    assert result["ok"] is False and result["which"] == "start_place"


def test_navigate_to_event_by_query_and_id(client):
    result, action = assistant._run_tool("navigate_to_event", {"event_query": "machine learning", "start_now": True})
    assert result["ok"] and "event=" in action["hash"] and "go=1" in action["hash"]
    ev = assistant._run_tool("search_events", {"query": "machine learning"})[0]["events"][0]
    result, action = assistant._run_tool("navigate_to_event", {"event_id": ev["id"], "start_place_id": loc_id(client, "gate-main")})
    assert result["ok"] and f"event={ev['id']}" in action["hash"] and "from=" in action["hash"]
    assert assistant._run_tool("navigate_to_event", {"event_query": "no such event"})[0]["ok"] is False


def test_page_route_nav_and_map_actions(client):
    assert assistant._run_tool("open_page", {"page": "events"})[1] == {"kind": "open", "hash": "#/events", "label": "Opening events"}
    assert assistant._run_tool("open_page", {"page": "../../evil"})[0]["ok"] is False
    r, a = assistant._run_tool("set_route_options", {"avoid_stairs": True, "profile": "fastest"})
    assert a == {"kind": "route_options", "avoid_stairs": True, "profile": "fastest", "label": "Step-free on, Fastest route"}
    assert assistant._run_tool("set_route_options", {"profile": "teleport"})[0]["ok"] is False
    for cmd in assistant.NAV_COMMANDS:
        assert assistant._run_tool("control_navigation", {"command": cmd})[1]["command"] == cmd
    assert assistant._run_tool("control_navigation", {"command": "explode"})[0]["ok"] is False
    assert assistant._run_tool("map_action", {"command": "zoom_in"})[1]["kind"] == "map"
    a = assistant._run_tool("map_action", {"command": "show_place", "place_name": "library"})[1]
    assert a["place_id"] == loc_id(client, "lib") and "University Library" in a["label"]
    assert assistant._run_tool("map_action", {"command": "show_place", "place_name": "zzzz"})[0]["ok"] is False
    assert assistant._run_tool("map_action", {"command": "hack"})[0]["ok"] is False


def test_bad_tool_arguments_do_not_crash(client):
    assert assistant._run_tool("navigate_to_place", {"place_id": 999999})[0]["ok"] is False
    assert assistant._run_tool("navigate_to_place", {"place_id": "1; DROP TABLE"})[0]["ok"] is False
    assert assistant._run_tool("navigate_to_place", {})[0]["ok"] is False
    assert assistant._run_tool("navigate_to_event", {"event_id": None})[0]["ok"] is False
    assert assistant._run_tool("nope", {})[0]["ok"] is False
    assert assistant._run_tool("search_places", "not-a-dict")[0]["count"] >= 1


def test_closed_place_is_not_navigated(admin):
    lid = loc_id(admin, "dmi-g02")
    admin.patch(f"/api/admin/locations/{lid}/status", json={"is_open": False, "status_note": "Renovation"})
    result, action = assistant._run_tool("navigate_to_place", {"place_id": lid})
    assert result["ok"] is False and action is None and "Renovation" in result["error"]


def test_pcm_wrapped_as_wav():
    wav = assistant._pcm_to_wav(b"\x00\x00" * 10)
    assert wav[:4] == b"RIFF" and wav[8:12] == b"WAVE" and len(wav) == 44 + 20
