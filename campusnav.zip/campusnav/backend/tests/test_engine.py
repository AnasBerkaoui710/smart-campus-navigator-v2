"""Routing engine tests on hand-built graphs (no database)."""
import heapq
import random

import pytest

from app.geo import local_to_latlng
from app.routing.engine import NoRouteError, astar, plan_routes
from app.routing.graph import Edge, Graph, Node
from app.routing.profiles import Profile


def make_graph(points, links):
    """points: {id: (x, y, floor)}; links: [(id, a, b, kind, length or None, accessible)]"""
    nodes = []
    for nid, (x, y, floor) in points.items():
        lat, lng = local_to_latlng(x, y, 0, 0)
        nodes.append(Node(nid, lat, lng, floor))
    g0 = Graph(nodes, [])
    edges = []
    for eid, a, b, kind, length, acc in links:
        edges.append(Edge(eid, a, b, kind, length if length else g0.distance(a, b), acc))
    return Graph(nodes, edges)


def dijkstra_cost(graph, s, t, profile):
    dist = {s: 0.0}
    heap = [(0.0, s)]
    while heap:
        d, u = heapq.heappop(heap)
        if u == t:
            return d
        if d > dist[u]:
            continue
        for v, e in graph.adj[u]:
            if not profile.allows(e, graph):
                continue
            nd = d + profile.cost(e)
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                heapq.heappush(heap, (nd, v))
    return None


@pytest.fixture()
def hill():
    # 1 --stairs(105)-- 2 ; 1 --ramp-- 3 --ramp-- 2 (160 total) ; 1 -- 4 -- 2 long walkway (300)
    pts = {1: (0, 0, 0), 2: (0, 100, 0), 3: (-10, 50, 0), 4: (150, 50, 0)}
    links = [(1, 1, 2, "stairs", 105, False), (2, 1, 3, "ramp", 80, True), (3, 3, 2, "ramp", 80, True),
             (4, 1, 4, "walkway", 158.2, True), (5, 4, 2, "walkway", 158.2, True)]
    return make_graph(pts, links)


def test_shortest_takes_stairs_fastest_takes_ramp(hill):
    short = astar(hill, 1, 2, Profile("shortest"))
    fast = astar(hill, 1, 2, Profile("fastest"))
    assert [e.id for e in short[1]] == [1]
    assert [e.id for e in fast[1]] == [2, 3]


def test_avoid_stairs_excludes_stairs(hill):
    path = astar(hill, 1, 2, Profile("shortest", avoid_stairs=True))
    assert all(e.kind != "stairs" for e in path[1])


def test_closed_edge_is_avoided(hill):
    hill.edges[2].is_open = False
    path = astar(hill, 1, 2, Profile("shortest", avoid_stairs=True))
    assert [e.id for e in path[1]] == [4, 5]


def test_avoid_edges_parameter(hill):
    path = astar(hill, 1, 2, Profile("shortest", avoid_edges=[1]))
    assert [e.id for e in path[1]] == [2, 3]


def test_plan_routes_returns_both_profiles_and_alternative(hill):
    result = plan_routes(hill, 1, 2, "shortest")
    ids = [r["id"] for r in result["routes"]]
    assert ids[0] == "shortest" and "fastest" in ids
    assert result["routes"][0]["distance_m"] == 105
    assert result["routes"][0]["accessibility"] == "not_step_free"


def test_no_step_free_route_is_reported():
    g = make_graph({1: (0, 0, 0), 2: (0, 0, 1)}, [(1, 1, 2, "stairs", 10, False)])
    with pytest.raises(NoRouteError) as exc:
        plan_routes(g, 1, 2, avoid_stairs=True)
    assert exc.value.code == "no_step_free_route"


def test_disconnected_graph_reports_no_route():
    g = make_graph({1: (0, 0, 0), 2: (50, 0, 0)}, [])
    with pytest.raises(NoRouteError) as exc:
        plan_routes(g, 1, 2)
    assert exc.value.code == "no_route"


def test_unknown_accessibility_marks_route_incomplete():
    g = make_graph({1: (0, 0, 0), 2: (30, 0, 0)}, [(1, 1, 2, "door", None, None)])
    result = plan_routes(g, 1, 2, avoid_stairs=True)
    assert result["routes"][0]["accessibility"] == "incomplete"
    assert result["warnings"]


def test_same_start_and_goal():
    g = make_graph({1: (0, 0, 0), 2: (30, 0, 0)}, [(1, 1, 2, "walkway", None, True)])
    result = plan_routes(g, 1, 1)
    assert result["routes"][0]["distance_m"] == 0
    assert result["routes"][0]["steps"][-1]["kind"] == "arrive"


def test_one_way_edge_respected():
    pts = {1: (0, 0, 0), 2: (100, 0, 0), 3: (50, 80, 0)}
    g0 = make_graph(pts, [])
    edges = [Edge(1, 1, 2, "walkway", 100, True, bidirectional=False),
             Edge(2, 2, 3, "walkway", g0.distance(2, 3), True),
             Edge(3, 3, 1, "walkway", g0.distance(3, 1), True)]
    g = Graph(list(g0.nodes.values()), edges)
    assert [e.id for e in astar(g, 1, 2, Profile())[1]] == [1]
    assert [e.id for e in astar(g, 2, 1, Profile())[1]] == [2, 3]


@pytest.mark.parametrize("seed", range(25))
@pytest.mark.parametrize("profile", ["shortest", "fastest"])
def test_astar_matches_dijkstra_on_random_graphs(seed, profile):
    rng = random.Random(seed)
    n = 40
    pts = {i: (rng.uniform(0, 500), rng.uniform(0, 500), rng.choice([0, 0, 0, 1])) for i in range(1, n + 1)}
    g0 = make_graph(pts, [])
    links, eid = [], 1
    kinds = ["walkway", "walkway", "corridor", "ramp", "stairs", "door"]
    for a in pts:
        for b in rng.sample(list(pts), 3):
            if a == b:
                continue
            straight = g0.distance(a, b)
            links.append((eid, a, b, rng.choice(kinds), straight * rng.uniform(1.0, 1.6), rng.random() > 0.2))
            eid += 1
    g = make_graph(pts, links)
    prof = Profile(profile, avoid_stairs=rng.random() > 0.5)
    for _ in range(10):
        s, t = rng.sample(list(pts), 2)
        expected = dijkstra_cost(g, s, t, prof)
        found = astar(g, s, t, prof)
        if expected is None:
            assert found is None
        else:
            assert found is not None
            assert sum(prof.cost(e) for e in found[1]) == pytest.approx(expected)
