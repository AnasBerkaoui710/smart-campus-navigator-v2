import pytest
from fastapi.testclient import TestClient

from app import create_app
from app.models import User, db
from app.routing.graph import invalidate
from app.seed import init_sample

TEST_ADMIN = ("admin@test.example", "test-admin-password")
TEST_EDITOR = ("editor@test.example", "test-editor-password")


@pytest.fixture()
def client():
    app = create_app(testing=True)  # fresh in-memory database per test
    init_sample(with_admin=False)
    for (email, pw), role in ((TEST_ADMIN, "admin"), (TEST_EDITOR, "editor")):
        u = User(name=role, email=email, role=role)
        u.set_password(pw)
        db.session.add(u)
    db.session.commit()
    db.session.remove()
    invalidate()
    with TestClient(app) as c:
        yield c
    db.session.remove()
    db.drop_all()
    invalidate()


def login(client, who=TEST_ADMIN):
    r = client.post("/api/auth/login", json={"email": who[0], "password": who[1]})
    assert r.status_code == 200, r.json()
    return r


@pytest.fixture()
def admin(client):
    login(client)
    return client


def loc_id(client, code):
    for loc in client.get("/api/locations?limit=200").json():
        if loc["code"] == code:
            return loc["id"]
    raise KeyError(code)
