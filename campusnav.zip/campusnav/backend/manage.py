"""Management commands.

  python manage.py init-db            create tables, import the SAMPLE campus, seed events + admin
  python manage.py import FILE.json   validate and import a campus pathway dataset
  python manage.py validate FILE.json validate only
  python manage.py reseed-events      regenerate sample events relative to today
  python manage.py create-user EMAIL NAME --role admin|editor   (prompts for password)
"""
import argparse
import getpass
import json
import sys

from app import create_app
from app.importer import DatasetError, import_dataset, validate
from app.models import User, db
from app.seed import init_sample, seed_events


def main(argv=None):
    parser = argparse.ArgumentParser(description="CampusNav management")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db")
    sub.add_parser("reseed-events")
    for name in ("import", "validate"):
        p = sub.add_parser(name)
        p.add_argument("file")
    p = sub.add_parser("create-user")
    p.add_argument("email")
    p.add_argument("name")
    p.add_argument("--role", choices=("admin", "editor"), default="editor")
    args = parser.parse_args(argv)

    create_app()
    if args.cmd == "init-db":
        summary = init_sample()
        print(f"Imported SAMPLE campus: {summary}")
    elif args.cmd == "reseed-events":
        seed_events()
        print("Sample events regenerated.")
    elif args.cmd in ("import", "validate"):
        with open(args.file, encoding="utf-8") as f:
            data = json.load(f)
        if args.cmd == "validate":
            errors, warnings = validate(data)
            for line in errors:
                print("ERROR  ", line)
            for line in warnings:
                print("WARNING", line)
            return 1 if errors else 0
        db.create_all()
        try:
            print(import_dataset(data))
        except DatasetError as e:
            print("Import rejected:\n  " + "\n  ".join(e.errors))
            return 1
    elif args.cmd == "create-user":
        if User.query.filter_by(email=args.email).first():
            print("A user with that email already exists.")
            return 1
        password = getpass.getpass("Password (min 10 chars): ")
        if len(password) < 10:
            print("Password too short.")
            return 1
        user = User(email=args.email, name=args.name, role=args.role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        print(f"Created {args.role} {args.email}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
