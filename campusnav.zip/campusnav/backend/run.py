"""Development server. On first run it creates the SQLite database with the SAMPLE campus.

    python run.py            ->  http://127.0.0.1:5000   (API docs at /docs)
"""
import os

import uvicorn

from app import create_app
from app.models import DatasetInfo, db
from app.seed import init_sample

app = create_app()

db.create_all()
if DatasetInfo.query.first() is None:
    print("Empty database: importing the SAMPLE campus and events...")
    init_sample()
db.session.remove()

if __name__ == "__main__":
    uvicorn.run(app, host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)))
