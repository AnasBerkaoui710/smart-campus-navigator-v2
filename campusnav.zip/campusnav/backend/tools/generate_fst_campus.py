"""Build backend/data/fst_campus.json: Faculty of Sciences and Techniques (FST) Beni Mellal, Mghila.

REAL data (OpenStreetMap, ODbL, saved in data/osm_fst_raw.json):
  * the campus outline (way 846672283)
  * the internal service-road loop and the two gate approaches

POTENTIAL / ILLUSTRATIVE data (generated here, NOT surveyed):
  * building positions and footprints, floors (1-3), corridors, rooms and room names
  * entrance access paths, central-quad footpaths, accessibility attributes

OpenStreetMap has no building footprints or indoor data for this campus, so the layout
below is a proposal to be replaced by a real survey. The dataset is flagged is_sample=true
so the UI says so.

Run from backend/:  python tools/generate_fst_campus.py [--plot]
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.geo import latlng_to_local  # noqa: E402

BACKEND = Path(__file__).resolve().parents[1]
RAW = json.loads((BACKEND / "data" / "osm_fst_raw.json").read_text(encoding="utf-8"))
OUT = BACKEND / "data" / "fst_campus.json"
ORIGIN = (32.3766264, -6.3192835)  # centre of the campus outline
ALPHA = math.radians(38)           # the ring road / campus grid is rotated ~38 degrees

nodes, edges, buildings, locations = [], [], [], []
pos = {}  # node code -> (x, y)
outdoor_edges = []  # indices into `edges` usable for snapping (outdoor walkways only)


def xy(lat, lng):
    return latlng_to_local(lat, lng, *ORIGIN)


def uv(u, v):
    """Coordinates in the campus grid frame (rotated 38 deg) -> local metres."""
    return (u * math.cos(ALPHA) - v * math.sin(ALPHA), u * math.sin(ALPHA) + v * math.cos(ALPHA))


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def add_node(code, p, kind, floor=0, building=None, name=None, accessible=True):
    assert code not in pos, code
    nodes.append({"code": code, "x": round(p[0], 2), "y": round(p[1], 2), "floor": floor, "building": building,
                  "kind": kind, "name": name, "accessible": accessible})
    pos[code] = (round(p[0], 2), round(p[1], 2))
    return code


def add_edge(a, b, kind, name=None, accessible=True, length_m=None, outdoor=False):
    e = {"code": f"{a}--{b}", "from": a, "to": b, "kind": kind, "name": name, "accessible": accessible,
         "bidirectional": True}
    if length_m is not None:
        e["length_m"] = length_m
    edges.append(e)
    if outdoor:
        outdoor_edges.append(len(edges) - 1)
    return e


def inside(p, poly):
    x, y = p
    res = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            res = not res
        j = i
    return res


# --------------------------------------------------------------- real outdoor network
campus_poly = [xy(*p) for p in RAW["campus"]["polygon"]]
osm_nodes = {}  # (lat, lng) -> code


def osm_node(lat, lng):
    key = (round(lat, 7), round(lng, 7))
    if key not in osm_nodes:
        osm_nodes[key] = add_node(f"OSM-{len(osm_nodes) + 1:03d}", xy(lat, lng), "junction")
    return osm_nodes[key]


way_ends = {}
GATE_WAY = {1381965092: ("GATE-W", "Main Gate", 0), 780443741: ("GATE-E", "East Gate", -1)}
for way in RAW["ways"]:
    pts = [tuple(p) for p in way["pts"]]
    keep = [p for p in pts if inside(xy(*p), campus_poly)]
    if way["id"] == 1381965092:  # the approach whose outer end is the main gate
        keep = pts
    if len(keep) < 2:
        continue
    # keep one contiguous run (clipping can only cut ends of these ways)
    prev = None
    for p in keep:
        code = osm_node(*p)
        if prev and prev != code:
            a, b = pos[prev], pos[code]
            add_edge(prev, code, "walkway", way["name"], length_m=None, outdoor=True)
        prev = code
    way_ends[way["id"]] = osm_nodes[(round(keep[-1][0], 7), round(keep[-1][1], 7))]
    if way["id"] in GATE_WAY:
        gcode, gname, idx = GATE_WAY[way["id"]]
        first = osm_nodes[(round(keep[0][0], 7), round(keep[0][1], 7))]
        for n in nodes:
            if n["code"] == first:
                n["kind"], n["name"] = "gate", gname

gates = [n for n in nodes if n["kind"] == "gate"]
assert len(gates) == 2, [g["code"] for g in gates]


def snap(p, allow_split=True, exclude=()):
    """Nearest point on the outdoor network. Splits the segment and returns the junction code."""
    best = None
    for idx in outdoor_edges:
        e = edges[idx]
        if idx in exclude:
            continue
        a, b = pos[e["from"]], pos[e["to"]]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L2 = dx * dx + dy * dy
        t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2)) if L2 else 0.0
        q = (a[0] + t * dx, a[1] + t * dy)
        d = dist(p, q)
        if best is None or d < best[0]:
            best = (d, idx, t, q)
    d, idx, t, q = best
    e = edges[idx]
    if t < 0.03:
        return e["from"], d
    if t > 0.97:
        return e["to"], d
    code = f"J-{len(nodes) + 1:03d}"
    add_node(code, q, "junction")
    old = edges.pop(idx)
    # indices after idx shift down by one
    outdoor_edges[:] = [i - 1 if i > idx else i for i in outdoor_edges if i != idx]
    for a, b in ((old["from"], code), (code, old["to"])):
        add_edge(a, b, "walkway", old["name"], outdoor=True)
    return code, d


# The east access road stops ~17 m short of the ring road in OSM: bridge the gap (inferred, labelled).
_end = way_ends[780443741]
_touching = {i for i in outdoor_edges if _end in (edges[i]["from"], edges[i]["to"])}
_j, _d = snap(pos[_end], exclude=_touching)
assert _d < 40, _d
add_edge(_end, _j, "walkway", "East connector (inferred, not in OSM)", outdoor=True)

# --------------------------------------------------------------- central quad
QUAD = add_node("QUAD", uv(35, 12), "junction", name="Central Plaza")
# Footpaths run through the gaps between buildings (grid-frame waypoints), ending on the ring road.
for k, (waypoints, end) in enumerate((
        ([(35, 38), (-20, 38)], (-76, 38)),       # west, between the lecture halls and the library
        ([(35, 38), (56, 40)], (56, 96)),         # north, between mathematics/CS and biology/geology
        ([(50, -15)], (128, -15)),                # east, between the teaching block and chemistry/physics
)):
    prev = QUAD
    for n, (u, v) in enumerate(waypoints):
        key = (round(u), round(v))
        code = f"PLAZA-{u}-{v}".replace("-", "m")
        if code not in pos:
            add_node(code, uv(u, v), "junction")
        if code != prev:
            add_edge(prev, code, "walkway", "Plaza path", outdoor=True)
        prev = code
    j, _ = snap(uv(*end))
    add_edge(prev, j, "walkway", "Plaza path", outdoor=True)
locations.append({"code": "plaza", "name": "Central Plaza", "type": "outdoor", "building": None, "floor": 0,
                  "room_number": None, "node": QUAD, "keywords": "place centrale pelouse lawn events",
                  "description": "Open plaza in the middle of the campus ring road, used for student events."})

# gate locations
for g in gates:
    code = "gate-main" if g["name"] == "Main Gate" else "gate-east"
    desc = ("Main pedestrian entrance, on the road to the Beni Mellal city centre."
            if code == "gate-main" else "Secondary entrance on the east access road.")
    locations.append({"code": code, "name": g["name"], "type": "gate", "building": None, "floor": 0, "room_number": None,
                      "node": g["code"], "keywords": "entrance porte entree", "description": desc})


# --------------------------------------------------------------- buildings (POTENTIAL layout)
def rot(p, c, ang):
    ca, sa = math.cos(ang), math.sin(ang)
    return (c[0] + p[0] * ca - p[1] * sa, c[1] + p[0] * sa + p[1] * ca)


def building(code, name, desc, center, w, h, floors, rooms, entrances=1, elevator=True, btype="building",
             keywords="", unsurveyed_entrance=False, angle=ALPHA):
    """Rectangular building w x h (metres, along/against the campus grid) centred on `center`.
    rooms = {floor: [(room_no, name, type, keywords), ...]} (max 6 per floor)."""
    foot = [rot(p, center, angle) for p in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]
    buildings.append({"code": code, "name": name, "description": desc,
                      "footprint": [[round(x, 2), round(y, 2)] for x, y in foot], "floors": floors})
    W = lambda x, y: rot((x, y), center, angle)  # noqa: E731

    for f in floors:
        cw = add_node(f"{code}-{f}-CW", W(-w / 2 + 5, 0), "corridor", f, code)
        cm = add_node(f"{code}-{f}-CM", W(0, 0), "corridor", f, code)
        ce = add_node(f"{code}-{f}-CE", W(w / 2 - 5, 0), "corridor", f, code)
        add_edge(cw, cm, "corridor")
        add_edge(cm, ce, "corridor")
        st = add_node(f"{code}-{f}-ST", W(-w / 2 + 5, 4), "stairs", f, code, name="Stairwell", accessible=False)
        add_edge(cw, st, "corridor")
        if elevator:
            el = add_node(f"{code}-{f}-EL", W(w / 2 - 5, 4), "elevator", f, code, name="Elevator")
            add_edge(ce, el, "corridor")
    for a, b in zip(floors, floors[1:]):
        add_edge(f"{code}-{a}-ST", f"{code}-{b}-ST", "stairs", "Stairwell", accessible=False, length_m=10)
    if elevator:
        for a in floors:
            for b in floors:
                if a < b:
                    add_edge(f"{code}-{a}-EL", f"{code}-{b}-EL", "elevator", "Elevator", length_m=4 * (b - a))

    # entrances: the sides closest to the road network
    sides = {"S": (0, -h / 2), "N": (0, h / 2), "W": (-w / 2, 0), "E": (w / 2, 0)}
    inner = {"S": "CM", "N": "CM", "W": "CW", "E": "CE"}
    ranked = []
    for s, p in sides.items():
        _, d = snap(W(*p))
        ranked.append((d, s))
    ranked.sort()
    main_entrance = None
    for k, (d, s) in enumerate(ranked[:entrances]):
        ent_name = ("Main entrance" if k == 0 else "Side entrance")
        acc = None if (unsurveyed_entrance and k == 0) else True
        ent = add_node(f"{code}-ENT-{s}", W(*sides[s]), "entrance", 0, code, name=ent_name, accessible=acc)
        main_entrance = main_entrance or ent
        add_edge(ent, f"{code}-0-{inner[s]}", "door", ent_name, accessible=acc)
        j, _ = snap(pos[ent])
        add_edge(ent, j, "walkway", "Access path", outdoor=True)

    slots = [("CW", -w / 2 + 10), ("CM", 0), ("CE", w / 2 - 10)]
    for f, rlist in rooms.items():
        assert len(rlist) <= 6, (code, f)
        for i, (room_no, rname, rtype, kw) in enumerate(rlist):
            anchor, ax = slots[i % 3]
            side = 1 if i < 3 else -1
            rn = add_node(f"{code}-{room_no}", W(ax, side * h * 0.3), "room", f, code, name=rname)
            add_edge(f"{code}-{f}-{anchor}", rn, "door", rname)
            locations.append({"code": f"{code.lower()}-{room_no.lower()}", "name": rname, "type": rtype,
                              "building": code, "floor": f, "room_number": f"{code}-{room_no}", "node": rn,
                              "keywords": kw, "description": ""})
    locations.append({"code": code.lower(), "name": name, "type": btype, "building": code, "floor": 0,
                      "room_number": None, "node": main_entrance, "keywords": keywords, "description": desc})


# 2 floors = 0,1   3 floors = 0,1,2   (0 = rez-de-chaussee)
building("ADM", "Administration Building (Decanat)",
         "Dean's office, general secretariat, registrar and student affairs. Potential layout.",
         uv(-48, 18), 40, 26, [0, 1],
         {0: [("G01", "Welcome & Orientation Desk", "service", "accueil orientation information"),
              ("G02", "Registrar (Scolarite)", "office", "scolarite inscription registration transcripts"),
              ("G03", "Student Affairs", "office", "affaires estudiantines")],
          1: [("101", "Dean's Office (Doyen)", "office", "decanat doyen dean"),
              ("102", "General Secretariat", "office", "secretariat general"),
              ("103", "Conference Room", "meeting_room", "salle conferences council conseil")]},
         entrances=1, elevator=True, keywords="decanat administration offices")
building("LIB", "University Library",
         "Reading rooms, group-study rooms and thesis archive over three floors. Potential layout.",
         uv(-40, 58), 40, 28, [0, 1, 2],
         {0: [("G01", "Loans & Information Desk", "service", "pret accueil"),
              ("G02", "Main Reading Room", "study_room", "salle lecture")],
          1: [("101", "Group Study Room", "study_room", "travail groupe"),
              ("102", "Multimedia Room", "computer_lab", "informatique internet")],
          2: [("201", "Theses & Dissertations Archive", "library", "theses memoires archives"),
              ("202", "Silent Reading Room", "study_room", "silence calme")]},
         entrances=1, elevator=True, btype="library", keywords="bibliotheque books study")
building("AMP", "Lecture Halls (Amphitheatres)",
         "Large lecture halls and the Salle des Actes for conferences and ceremonies. Potential layout.",
         uv(0, 16), 40, 30, [0, 1],
         {0: [("G01", "Amphitheatre A", "lecture_hall", "amphi a cours"),
              ("G02", "Amphitheatre B", "lecture_hall", "amphi b cours")],
          1: [("101", "Amphitheatre C", "lecture_hall", "amphi c cours"),
              ("102", "Salle des Actes", "auditorium", "conference ceremony soutenance")]},
         entrances=2, elevator=True, btype="auditorium", keywords="amphitheatres conferences")
building("DMI", "Mathematics & Computer Science Dept.",
         "Classrooms, computer labs and offices over three floors. Potential layout.",
         uv(22, 66), 56, 28, [0, 1, 2],
         {0: [("G01", "Tutorial Room M-G01", "classroom", "td salle"),
              ("G02", "Computing Centre", "computer_lab", "centre calcul informatique pc")],
          1: [("101", "Computer Lab 1", "computer_lab", "tp informatique pc"),
              ("102", "Computer Lab 2", "computer_lab", "tp informatique pc"),
              ("103", "Tutorial Room M-103", "classroom", "td")],
          2: [("201", "Head of Department Office", "office", "chef departement"),
              ("202", "Meeting Room", "meeting_room", "reunion"),
              ("203", "Research Laboratory", "laboratory", "recherche laboratoire")]},
         entrances=1, elevator=True, keywords="mathematiques informatique computer science")
building("DBG", "Biology & Geology Dept.",
         "Teaching and research laboratories over three floors (stairs only). Potential layout.",
         uv(88, 62), 50, 28, [0, 1, 2],
         {0: [("G01", "Biology Lab 1", "laboratory", "biologie tp"),
              ("G02", "Geology Lab", "laboratory", "geologie roches")],
          1: [("101", "Biology Lab 2", "laboratory", "biologie tp"),
              ("102", "Microscopy Room", "laboratory", "microscopie")],
          2: [("201", "Tutorial Room B-201", "classroom", "td"),
              ("202", "Department Office", "office", "secretariat departement")]},
         entrances=1, elevator=False, keywords="biologie geologie biology geology")
building("DCP", "Chemistry & Physics Dept.",
         "Chemistry and physics laboratories over three floors (stairs only). Potential layout.",
         uv(98, 8), 44, 28, [0, 1, 2],
         {0: [("G01", "Chemistry Lab 1", "laboratory", "chimie tp"),
              ("G02", "Physics Lab 1", "laboratory", "physique tp")],
          1: [("101", "Chemistry Lab 2", "laboratory", "chimie tp"),
              ("102", "Spectroscopy Room", "laboratory", "spectroscopie")],
          2: [("201", "Tutorial Room P-201", "classroom", "td"),
              ("202", "Department Office", "office", "secretariat departement")]},
         entrances=1, elevator=False, unsurveyed_entrance=True, keywords="chimie physique chemistry physics")
building("ENS", "Teaching Block (Classrooms)",
         "General-purpose classrooms over two floors. Potential layout.",
         uv(45, -34), 56, 20, [0, 1],
         {0: [("G01", "Classroom 101", "classroom", "salle cours"),
              ("G02", "Classroom 102", "classroom", "salle cours"),
              ("G03", "Classroom 103", "classroom", "salle cours")],
          1: [("101", "Classroom 201", "classroom", "salle cours"),
              ("102", "Classroom 202", "classroom", "salle cours"),
              ("103", "Classroom 203", "classroom", "salle cours")]},
         entrances=1, elevator=True, keywords="salles cours classrooms")

# outside the ring road (north / south of the loop)
building("CAF", "Cafeteria",
         "Cafeteria and photocopy shop. Potential layout.",
         (50, 170), 30, 18, [0],
         {0: [("G01", "Main Cafeteria", "cafeteria", "cafe restaurant food repas coffee"),
              ("G02", "Copy Shop (Reprographie)", "service", "photocopie reprographie")]},
         entrances=1, elevator=False, btype="building", keywords="cafeteria food", angle=ALPHA)
building("VIE", "Student Life Centre",
         "Infirmary, prayer room and student clubs. Potential layout.",
         (112, 160), 28, 18, [0],
         {0: [("G01", "Infirmary", "service", "infirmerie sante health nurse"),
              ("G02", "Prayer Room", "prayer_room", "salle priere mosque"),
              ("G03", "Student Clubs Room", "meeting_room", "clubs associations")]},
         entrances=1, elevator=False, btype="building", keywords="student life vie estudiantine", angle=ALPHA)

# outdoor amenities (a point on the path network + a footprint-less marker)
j, _ = snap((150, 52))
sports = add_node("SPORTS", (150, 52), "junction", name="Sports Field")
add_edge(sports, j, "walkway", "Access path", outdoor=True)
locations.append({"code": "sports-field", "name": "Sports Field", "type": "outdoor", "building": None, "floor": 0,
                  "room_number": None, "node": sports, "keywords": "terrain sport football basketball",
                  "description": "Outdoor sports field (potential location)."})
j, _ = snap((185, -22))
parking = add_node("PARKING", (185, -22), "junction", name="Parking")
add_edge(parking, j, "walkway", "Access path", outdoor=True)
locations.append({"code": "parking", "name": "Parking", "type": "outdoor", "building": None, "floor": 0,
                  "room_number": None, "node": parking, "keywords": "parking voiture car",
                  "description": "Visitor and staff parking by the east gate (potential location)."})


# --------------------------------------------------------------- validate + write
def check():
    codes = {n["code"] for n in nodes}
    assert len(codes) == len(nodes)
    ec = set()
    for e in edges:
        assert e["from"] in codes and e["to"] in codes, e
        assert e["code"] not in ec, e["code"]
        ec.add(e["code"])
    assert len({loc["code"] for loc in locations}) == len(locations)


check()
dataset = {
    "format": "campusnav-pathways/1",
    "name": "FST Beni Mellal - Mghila campus",
    "is_sample": True,
    "notes": "Campus outline and internal service roads: OpenStreetMap contributors (ODbL). Buildings, floors, "
             "rooms and access paths are a POTENTIAL layout, not surveyed - replace with real plans.",
    "origin": {"lat": ORIGIN[0], "lng": ORIGIN[1]},
    "coordinates": "local_m",
    "campus_outline": [list(p) for p in campus_poly],
    "buildings": buildings, "nodes": nodes, "edges": edges, "locations": locations,
}
OUT.write_text(json.dumps(dataset, indent=1), encoding="utf-8")
print(f"wrote {OUT.name}: {len(nodes)} nodes, {len(edges)} edges, {len(locations)} locations, {len(buildings)} buildings")

if "--plot" in sys.argv:
    plot = {"campus": campus_poly, "buildings": [b["footprint"] for b in buildings],
            "names": [b["code"] for b in buildings],
            "edges": [[pos[e["from"]], pos[e["to"]], e["kind"]] for e in edges
                      if not ((nodes_by := {n["code"]: n for n in nodes})[e["from"]]["building"] and
                              nodes_by[e["from"]]["kind"] != "entrance")]}
    html = ("<!doctype html><meta charset=utf-8><canvas id=c width=1000 height=1000 style='width:780px'></canvas><script>"
            f"const D={json.dumps(plot)};const c=document.getElementById('c').getContext('2d');"
            "const S=1.9,ox=480,oy=520;const X=p=>ox+p[0]*S,Y=p=>oy-p[1]*S;"
            "c.strokeStyle='#060';c.lineWidth=3;c.beginPath();D.campus.forEach((p,i)=>i?c.lineTo(X(p),Y(p)):c.moveTo(X(p),Y(p)));c.closePath();c.stroke();"
            "for(const e of D.edges){c.strokeStyle=e[2]=='walkway'?'#c33':'#888';c.lineWidth=e[2]=='walkway'?2:1;c.beginPath();c.moveTo(X(e[0]),Y(e[0]));c.lineTo(X(e[1]),Y(e[1]));c.stroke();}"
            "D.buildings.forEach((b,i)=>{c.fillStyle='rgba(60,120,80,.45)';c.strokeStyle='#245';c.lineWidth=1.5;c.beginPath();b.forEach((p,j)=>j?c.lineTo(X(p),Y(p)):c.moveTo(X(p),Y(p)));c.closePath();c.fill();c.stroke();"
            "const m=b.reduce((a,p)=>[a[0]+p[0]/4,a[1]+p[1]/4],[0,0]);c.fillStyle='#000';c.font='bold 13px sans-serif';c.fillText(D.names[i],X(m)-12,Y(m)+4);});"
            "</script>")
    (BACKEND.parent / "frontend" / "_plot.html").write_text(html, encoding="utf-8")
    print("plot -> frontend/_plot.html (delete after viewing)")
