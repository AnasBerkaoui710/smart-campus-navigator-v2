"""Generate the SAMPLE campus pathway dataset (backend/data/sample_campus.json).

Everything produced here is fictional demonstration data for "Demo University".
Coordinates are authored in local metres (x east, y north) around a neutral origin
(0Â°, 0Â°) so that the dataset can never be confused with a real campus.

Run:  python tools/generate_sample_campus.py
"""
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "data" / "sample_campus.json"

nodes, edges, buildings, locations = [], [], [], []
_node_pos = {}


def node(code, x, y, kind, floor=0, building=None, name=None, accessible=True):
    nodes.append({"code": code, "x": x, "y": y, "floor": floor, "building": building,
                  "kind": kind, "name": name, "accessible": accessible})
    _node_pos[code] = (x, y)
    return code


def edge(a, b, kind, name=None, accessible=True, length_m=None, bidirectional=True):
    e = {"code": f"{a}--{b}", "from": a, "to": b, "kind": kind, "name": name,
         "accessible": accessible, "bidirectional": bidirectional}
    if length_m is not None:
        e["length_m"] = length_m
    edges.append(e)


def location(code, name, type_, node_code, building=None, floor=0, room=None, description="", keywords=""):
    locations.append({"code": code, "name": name, "type": type_, "building": building, "floor": floor,
                      "room_number": room, "node": node_code, "description": description,
                      "keywords": keywords})


# --- Outdoor grid -----------------------------------------------------------
# G{i}{j} at (100 i, 100 j); i = 0..3 (westâ†’east), j = 0..2 (southâ†’north)
for i in range(4):
    for j in range(3):
        node(f"G{i}{j}", 100 * i, 100 * j, "junction")

row_names = {0: "South Avenue", 1: "Central Walk", 2: "North Avenue"}
col_names = {0: "West Lane", 1: "Library Lane", 2: "Science Walk", 3: "East Lane"}
for j in range(3):
    for i in range(3):
        edge(f"G{i}{j}", f"G{i+1}{j}", "walkway", row_names[j])
for i in range(4):
    for j in range(2):
        if (i, j) == (2, 0):
            continue  # replaced by the Hill Steps / ramp pair below
        edge(f"G{i}{j}", f"G{i}{j+1}", "walkway", col_names[i])

# Hill between South Avenue and Central Walk on Science Walk:
# a short staircase (not step-free) and a longer switchback ramp (step-free).
edge("G20", "G21", "stairs", "Hill Steps", accessible=False, length_m=105)
node("R1", 192, 30, "junction", name="Ramp landing (lower)")
node("R2", 192, 70, "junction", name="Ramp landing (upper)")
edge("G20", "R1", "ramp", "Accessible Ramp", length_m=50)
edge("R1", "R2", "ramp", "Accessible Ramp", length_m=60)
edge("R2", "G21", "ramp", "Accessible Ramp", length_m=50)

# Diagonal path across the Central Quad
node("QUAD", 150, 150, "junction", name="Central Quad")
edge("G11", "QUAD", "walkway", "Quad Diagonal")
edge("QUAD", "G22", "walkway", "Quad Diagonal")
location("quad", "Central Quad", "outdoor", "QUAD",
         description="Open-air lawn used for fairs and outdoor events.", keywords="lawn green open air")

# Gates
node("GATE-S", 200, -30, "gate", name="Main Gate")
node("GATE-N", 200, 230, "gate", name="North Gate")
node("GATE-E", 330, 100, "gate", name="East Gate")
edge("GATE-S", "G20", "walkway", "Main Gate Path")
edge("GATE-N", "G22", "walkway", "North Gate Path")
edge("GATE-E", "G31", "walkway", "East Gate Path")
location("gate-main", "Main Gate", "gate", "GATE-S", description="Main pedestrian entrance and bus stop.",
         keywords="entrance bus stop south")
location("gate-north", "North Gate", "gate", "GATE-N", keywords="entrance parking north")
location("gate-east", "East Gate", "gate", "GATE-E", keywords="entrance east")


# --- Buildings --------------------------------------------------------------
def building(code, name, desc, box, floors, entrances, rooms, elevator=True, btype="building", keywords=""):
    """box = (x0, y0, x1, y1); entrances = [(side, corners, accessible, name)];
    rooms = {floor: [(room_no, name, type, keywords), ...]}"""
    x0, y0, x1, y1 = box
    xm, ym = (x0 + x1) / 2, (y0 + y1) / 2
    buildings.append({"code": code, "name": name, "description": desc,
                      "footprint": [[x0, y0], [x1, y0], [x1, y1], [x0, y1]],
                      "floors": floors})

    for f in floors:
        cw = node(f"{code}-{f}-CW", x0 + 10, ym, "corridor", f, code)
        cm = node(f"{code}-{f}-CM", xm, ym, "corridor", f, code)
        ce = node(f"{code}-{f}-CE", x1 - 10, ym, "corridor", f, code)
        edge(cw, cm, "corridor")
        edge(cm, ce, "corridor")
        st = node(f"{code}-{f}-ST", x0 + 10, ym + 15, "stairs", f, code, name="Stairwell", accessible=False)
        edge(cw, st, "corridor")
        if elevator:
            el = node(f"{code}-{f}-EL", x1 - 10, ym + 15, "elevator", f, code, name="Elevator")
            edge(ce, el, "corridor")
    for a, b in zip(floors, floors[1:]):
        edge(f"{code}-{a}-ST", f"{code}-{b}-ST", "stairs", "Stairwell", accessible=False, length_m=10)
    if elevator:
        for a in floors:
            for b in floors:
                if a < b:
                    edge(f"{code}-{a}-EL", f"{code}-{b}-EL", "elevator", "Elevator", length_m=4 * (b - a))

    main_entrance = None
    for side, corners, accessible, ename in entrances:
        pos = {"S": (xm, y0), "N": (xm, y1), "W": (x0, ym), "E": (x1, ym)}[side]
        inner = {"S": "CM", "N": "CM", "W": "CW", "E": "CE"}[side]
        ent = node(f"{code}-ENT-{side}", *pos, "entrance", 0, code, name=ename, accessible=accessible)
        main_entrance = main_entrance or ent
        edge(ent, f"{code}-0-{inner}", "door", ename, accessible=accessible)
        for c in corners:
            edge(c, ent, "walkway")

    location(code.lower(), name, btype, main_entrance, code, 0, None, desc, keywords)

    for f, rlist in rooms.items():
        anchors = [("CW", x0 + 22), ("CE", x1 - 22), ("CM", xm)]
        for idx, (room_no, rname, rtype, kw) in enumerate(rlist):
            anchor, rx = anchors[idx]
            rn = node(f"{code}-{room_no}", rx, ym - 20, "room", f, code, name=rname)
            edge(f"{code}-{f}-{anchor}", rn, "door", rname)
            location(f"{code.lower()}-{room_no.lower()}", rname, rtype, rn, code, f,
                     f"{code}-{room_no}", keywords=kw)


building("LIB", "Main Library", "Central library with study rooms and special collections.",
         (15, 15, 85, 85), [0, 1],
         [("S", ["G00", "G10"], True, "Library main entrance")],
         {0: [("G01", "Circulation Desk", "service", "borrow books loans"),
              ("G02", "Group Study Room", "study_room", "study group")],
          1: [("101", "Silent Reading Room", "study_room", "quiet reading"),
              ("102", "Special Collections", "library", "archives rare books")]},
         elevator=False, btype="library", keywords="books study")

building("ENG", "Engineering Hall", "Engineering faculty: lecture halls, labs and offices.",
         (115, 15, 185, 85), [0, 1, 2],
         [("S", ["G10", "G20"], True, "Engineering south entrance"),
          ("N", ["G11", "G21"], True, "Engineering north entrance")],
         {0: [("G01", "Lecture Hall ENG-G01", "lecture_hall", "amphitheatre"),
              ("G02", "Robotics Lab", "laboratory", "robots")],
          1: [("101", "Classroom ENG-101", "classroom", ""),
              ("102", "Computer Lab", "laboratory", "computers pc")],
          2: [("201", "Seminar Room ENG-201", "classroom", "seminar"),
              ("202", "Dean of Engineering Office", "office", "dean administration")]},
         keywords="faculty engineering")

building("SCI", "Science Labs", "Chemistry, biology and physics laboratories.",
         (215, 15, 285, 85), [0, 1],
         [("E", ["G30", "G31"], True, "Science Labs entrance")],
         {0: [("G01", "Chemistry Lab", "laboratory", "chemistry"),
              ("G02", "Biology Lab", "laboratory", "biology")],
          1: [("101", "Physics Lab", "laboratory", "physics"),
              ("102", "Lecture Hall SCI-102", "lecture_hall", "")]},
         keywords="science labs")

building("SC", "Student Center", "Cafeteria, student union and meeting rooms.",
         (15, 115, 85, 185), [0],
         [("E", ["G11", "G12"], True, "Student Center east entrance"),
          # Accessibility of this door has not been surveyed: recorded as unknown (None).
          ("S", ["G01", "G11"], None, "Student Center south entrance")],
         {0: [("G01", "Main Cafeteria", "cafeteria", "food lunch coffee restaurant"),
              ("G02", "Student Union Meeting Room", "meeting_room", "union club")]},
         keywords="cafeteria student union")

building("AUD", "Grand Auditorium", "Main venue for conferences, ceremonies and cultural events.",
         (215, 115, 285, 185), [0, 1],
         [("W", ["G21", "G22"], True, "Auditorium entrance")],
         {0: [("G01", "Auditorium Main Hall", "auditorium", "theatre ceremony conference")],
          1: [("101", "Exhibition Gallery", "event_venue", "gallery exhibition art")]},
         btype="auditorium", keywords="auditorium events")

building("ADM", "Administration Building", "Registrar, admissions and university leadership.",
         (320, 115, 380, 185), [0, 1],
         [("W", ["G31", "G32"], True, "Administration entrance")],
         {0: [("G01", "Registrar's Office", "office", "registration transcripts"),
              ("G02", "Admissions Office", "office", "admissions apply")],
          1: [("101", "President's Office", "office", "president"),
              ("102", "Board Room", "meeting_room", "board meeting")]},
         keywords="administration offices")


def check():
    codes = {n["code"] for n in nodes}
    assert len(codes) == len(nodes), "duplicate node codes"
    for e in edges:
        assert e["from"] in codes and e["to"] in codes, e
        if "length_m" in e:
            (ax, ay), (bx, by) = _node_pos[e["from"]], _node_pos[e["to"]]
            assert e["length_m"] >= math.hypot(ax - bx, ay - by) - 1e-6, e


check()
dataset = {
    "format": "campusnav-pathways/1",
    "name": "Demo University (SAMPLE DATA)",
    "is_sample": True,
    "notes": "Fictional campus for demonstration. Placed at 0Â°,0Â° on purpose so it cannot be "
             "confused with a real place. Do not use for real navigation.",
    "origin": {"lat": 0.0, "lng": 0.0},
    "coordinates": "local_m",
    "buildings": buildings,
    "nodes": nodes,
    "edges": edges,
    "locations": locations,
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(dataset, indent=1), encoding="utf-8")
print(f"wrote {OUT} ({len(nodes)} nodes, {len(edges)} edges, {len(locations)} locations)")
