# CampusNav — Architecture Proposal

This document is the design written before implementation: architecture, folder
structure, database schema, API, routing strategy, and the line between features
that need **real campus data** and features demonstrated with **sample data**.

---

## 1. Architecture

```
┌──────────────────────────── Browser (PWA) ───────────────────────────┐
│  index.html  ── hash router (#/map, #/events, #/events/:id)          │
│  ├─ map view    Leaflet · route rendering · geolocation · re-routing │
│  ├─ events view cards · filters · detail dialog · "Navigate"         │
│  └─ admin.html  login · event CRUD · closures · data import          │
└───────────────▲───────────────────────────────────────────────────────┘
                │ JSON over HTTP (REST)
┌───────────────┴──────────── Flask app (backend/app) ─────────────────┐
│  api/public.py   locations · buildings · events · route · meta       │
│  api/auth.py     session login (werkzeug password hashes)            │
│  api/admin.py    role-protected CRUD, closures, pathway import       │
│  routing/        graph · A* engine · cost profiles · instructions    │
│  importer.py     validates + loads campus pathway datasets           │
│  models.py       SQLAlchemy ORM                                       │
└───────────────▲───────────────────────────────────────────────────────┘
                │ SQLAlchemy
        SQLite (dev, zero setup)  ·  PostgreSQL / MySQL (production, via DATABASE_URL)
```

### Technology choices

| Layer | Choice | Why |
|---|---|---|
| Frontend | Vanilla HTML/CSS/ES modules, no build step | The UI is two sections and a dialog; a framework adds tooling without adding capability. Any student can open and edit the files. |
| Map | Leaflet 1.9 | Small, mature, touch-friendly, works with OSM tiles *and* with a blank canvas for custom campus plans. |
| Base map | Custom campus plan (default) + optional OpenStreetMap layer | OSM is good for outdoor context but rarely has accurate indoor layouts; the routing graph is our own dataset. |
| Backend | Python 3.10+ / FastAPI + uvicorn | Fast, typed, auto-generated docs at `/docs`; the routing engine is plain Python and easy to test. |
| ORM / DB | SQLAlchemy 2; SQLite by default | Same models run on PostgreSQL or MySQL by changing `DATABASE_URL`. One DB session per request (`app/database.py`). |
| Auth | Starlette signed session cookie, werkzeug password hashing, `admin`/`editor` roles | No external identity provider needed for an internal staff dashboard. |
| Routing | Own A* implementation | The graph is small (hundreds–thousands of nodes) so a dependency-free engine is fast enough and fully explainable. |
| Tests | pytest | Engine correctness is checked against brute-force Dijkstra; API and data integrity tests. |

---

## 2. Folder structure

```
campusnav/
├── README.md                 setup, run, test, deploy
├── requirements.txt
├── .env.example
├── docs/
│   ├── ARCHITECTURE.md       this file
│   ├── ROUTING.md            algorithm, cost model, instructions, AI roadmap
│   └── TESTING.md            automated + manual test procedures
├── backend/
│   ├── run.py                dev server entry point
│   ├── wsgi.py               production entry point (gunicorn / waitress)
│   ├── manage.py             init-db · seed · import-pathways · create-user
│   ├── app/
│   │   ├── __init__.py       app factory, static frontend serving
│   │   ├── config.py
│   │   ├── models.py
│   │   ├── geo.py            local-metre <-> lat/lng projection, distances
│   │   ├── importer.py       dataset validation + import
│   │   ├── seed.py           sample events
│   │   ├── errors.py         structured JSON errors
│   │   ├── validation.py
│   │   ├── routing/
│   │   │   ├── graph.py      in-memory graph built from DB
│   │   │   ├── profiles.py   cost model (distance / time / accessibility)
│   │   │   ├── engine.py     A*, alternatives, route assembly
│   │   │   └── instructions.py  turn-by-turn text
│   │   └── api/
│   │       ├── public.py
│   │       ├── auth.py
│   │       └── admin.py
│   ├── data/
│   │   └── sample_campus.json   generated, clearly labelled SAMPLE
│   ├── tools/
│   │   └── generate_sample_campus.py
│   └── tests/
└── frontend/
    ├── index.html  admin.html  manifest.webmanifest  sw.js
    ├── css/app.css
    ├── icons/
    └── js/ app.js api.js router.js state.js map-view.js events-view.js
           route-panel.js search.js ui.js geo.js admin.js
```

---

## 3. Database schema

```
users                 id PK, name, email UNIQUE, password_hash, role ('admin'|'editor'), created_at
buildings             id PK, code UNIQUE, name, description, lat, lng, footprint (JSON polygon),
                      floors_min, floors_max, data_source ('sample'|'verified'), is_open
pathway_nodes         id PK, code UNIQUE, lat, lng, floor INT, building_id FK NULL (NULL = outdoors),
                      kind ('junction'|'entrance'|'corridor'|'room'|'stairs'|'elevator'|'gate'),
                      name, accessible BOOL NULL (NULL = unknown)
pathway_edges         id PK, code UNIQUE, from_node_id FK, to_node_id FK,
                      kind ('walkway'|'corridor'|'door'|'stairs'|'ramp'|'elevator'),
                      length_m, accessible BOOL NULL, bidirectional BOOL, name,
                      status ('open'|'closed'), status_note, restricted BOOL
campus_locations      id PK, code UNIQUE, name, type, building_id FK NULL, floor, room_number,
                      node_id FK NOT NULL  -- every location is routable
                      description, keywords, is_open
event_categories      id PK, slug UNIQUE, name, color
organizers            id PK, name UNIQUE, department, contact_email
events                id PK, title, description, category_id FK, organizer_id FK,
                      venue_id FK -> campus_locations NOT NULL,
                      starts_at, ends_at, image_url, registration_required, registration_url,
                      capacity, status ('draft'|'published'|'cancelled'), is_sample
accessibility_prefs   id PK, user_id FK UNIQUE, avoid_stairs, prefer_elevators, max_slope_note
dataset_info          id PK, name, is_sample, origin_lat, origin_lng, imported_at, notes
```

Integrity rules enforced in code and tests:
* `events.venue_id` is NOT NULL and must reference a location whose node exists in the graph.
* An event cannot be published if its venue is closed or unreachable from any campus gate.
* Edge `length_m` must be ≥ the straight-line distance between its endpoints (keeps A* admissible and catches typos).

---

## 4. REST API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/meta` | dataset name, sample flag, bounds, walking speed |
| GET | `/api/buildings` | buildings with footprints |
| GET | `/api/locations?q=&type=&building=` | search by name, code, room number, type, keyword |
| GET | `/api/locations/:id` | one location |
| GET | `/api/pathways` | nodes + edges for map overlay (closures shown) |
| POST | `/api/nearest` | `{lat,lng}` → nearest outdoor node + distance |
| POST | `/api/route` | see below |
| GET | `/api/events?q=&category=&when=&from=&to=` | published events |
| GET | `/api/events/:id` | one event, venue included |
| GET | `/api/categories` · `/api/organizers` | lookup lists |
| POST | `/api/auth/login` · `/api/auth/logout` · GET `/api/auth/me` | session auth |
| GET/POST/PUT/DELETE | `/api/admin/events[/:id]` | event management (editor+) |
| PATCH | `/api/admin/edges/:id` · `/api/admin/locations/:id` | open/close paths and facilities |
| POST/PUT/DELETE | `/api/admin/categories`, `/api/admin/organizers` | lookups (admin) |
| POST | `/api/admin/locations` · PUT `/api/admin/locations/:id` | facilities (admin) |
| POST | `/api/admin/import` | replace pathway dataset after validation (admin) |

`POST /api/route` body:
```json
{ "from": {"location_id": 3} | {"node_id": 17} | {"lat": 0.0, "lng": 0.0},
  "to":   {"location_id": 12},
  "profile": "shortest" | "fastest",
  "avoid_stairs": false,
  "avoid_edges": [42],
  "alternatives": true }
```
Response: `routes[]` (primary first, then the other profile's best if it differs,
then alternatives), each with `distance_m`, `duration_s`, `geometry`, `steps`,
`floors`, `accessibility` (`verified` / `incomplete`), plus `warnings[]`.
Errors are `{ "error": {"code": "...", "message": "..."} }` with 400/404/409/422.

---

## 5. Routing strategy

* **Graph**: nodes = gates, junctions, entrances, corridor points, stairs/elevator
  landings, rooms. Edges = walkways, corridors, doors, stairs, ramps, elevators.
* **Algorithm**: A* with a straight-line heuristic (haversine ÷ fastest speed for the
  time profile). Admissible because every edge is at least as long as its straight line.
* **Cost profiles**: `shortest` = metres; `fastest` = seconds, with per-kind speeds
  (stairs slower, elevator = fixed wait + per-floor time). Accessible mode removes
  edges/nodes marked `accessible = false` and reports edges whose accessibility is
  *unknown* as "incomplete" rather than silently trusting them.
* **Closures**: closed edges/locations are excluded; the client can also pass
  `avoid_edges` to route around a blockage it reports.
* **Alternatives**: penalty method — re-run A* with the previous routes' edges
  penalised ×1.4; keep a candidate only if it is ≤ 1.5× the best cost and shares
  < 70 % of its length with already-returned routes.
* **Re-routing**: the client watches GPS; if the user is > 25 m off the route line
  for two consecutive fixes it requests a new route from the current position.
* Full detail in `docs/ROUTING.md`.

---

## 6. Real data vs. sample data

| Feature | Works with sample data | Needs real campus data for production |
|---|---|---|
| UI, search, events, navigate-to-event | ✅ fully | — |
| Routing algorithm, alternatives, closures, accessibility logic | ✅ fully (proven by tests) | real pathway graph |
| Distances and walking times | ✅ computed from sample geometry | surveyed node coordinates and measured stair/ramp lengths |
| Indoor navigation | ✅ sample corridors/floors | real floor plans, room positions |
| Step-free routes | ✅ logic | verified accessibility attributes per door, ramp, lift |
| "Use my location" | ✅ permission flow; a "simulate GPS" mode for demos | campus georeferenced in real lat/lng |
| OpenStreetMap layer | ✅ toggle | campus placed at its true coordinates |

The sample campus ("Demo University") is placed at a neutral coordinate (0°, 0°, in the
ocean) **on purpose**, so it can never be mistaken for a real place. Every sample record
is tagged `data_source='sample'` / `is_sample=true` and the UI shows a persistent
"Sample data" badge. Real GPS positions will be reported as "outside the mapped campus"
until a real dataset is imported.

---

## 7. Delivery phases

1. Interface and navigation — layout, sections, cards, hash router.
2. Campus data and mapping — dataset format, importer, Leaflet, search.
3. Route optimisation — graph, A*, profiles, instructions, accessibility.
4. Event integration — venue links, Navigate-to-Event, destination persistence.
5. Backend and database — REST API, auth, admin dashboard.
6. Testing and deployment — pytest suite, manual test plan, deployment guide.
