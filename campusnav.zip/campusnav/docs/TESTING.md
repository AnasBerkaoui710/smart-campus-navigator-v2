# Testing

## Automated (`cd backend && python -m pytest -q`)

| File | What it proves |
|---|---|
| `tests/test_engine.py` | A* returns the same optimum as Dijkstra on 50 random graphs (both profiles, with/without avoid-stairs); shortest vs. fastest; closures; `avoid_edges`; one-way edges; no-route and no-step-free-route errors; unknown accessibility → "incomplete" |
| `tests/test_api.py` | every event venue and every location is routable from the main gate; search by room number/keyword/type; floor-change instructions; elevator used when avoiding stairs; GPS snapping and "outside campus"; input validation (415/422/404); auth and roles; closures re-route; closed destinations rejected; events cannot be published at unreachable venues; bad datasets rejected |

## Manual test plan

Run on: desktop Chrome/Edge/Firefox/Safari, a tablet (768 px), a phone (375 px), and with a
screen reader (NVDA or VoiceOver) for at least the event → navigate flow.

| # | Scenario | Expected |
|---|---|---|
| 1 | Events → *Navigate to event* on any card | Map opens, venue is the destination, event banner shown, location prompt appears |
| 2 | Deny location permission | Message explains, start search gets focus; choosing *Main Gate* computes the route |
| 3 | Allow location (real GPS, sample data) | "You appear to be … from the mapped campus" — no fake route |
| 4 | Tick *Demo: simulate GPS*, click near Main Gate, then *My location* | Route from the clicked point, approach step shown |
| 5 | With simulated GPS, click 40 m away from the route twice | "You left the route — recalculating…", new route |
| 6 | Search `201`, `coffee`, `lab`, `Engineering` | Relevant results; room-number match first |
| 7 | Main Gate → Grand Auditorium | Shortest (Hill Steps) and Fastest (ramp) both listed; selecting each redraws the map |
| 8 | *Avoid stairs* → Special Collections | "No step-free route could be verified…" |
| 9 | *Avoid stairs* from West Lane → Main Cafeteria | "Step-free (unverified parts)" badge + warning |
| 10 | Click *Blocked?* on a step | Route recomputed avoiding it; "Avoiding 1 segment … Reset" note |
| 11 | /admin: close *Hill Steps* | Path red/dashed on the map; routes avoid it |
| 12 | /admin: mark Computer Lab unavailable | Routing there returns "temporarily unavailable"; event can't be published there |
| 13 | /admin: create event with end before start / bad URL | Clear validation messages |
| 14 | Mobile: open event, navigate, switch to Events tab and back to Map | Destination and route are preserved |
| 15 | Reload the page on the map | Destination, start, options restored (session) |
| 16 | Keyboard only: search → arrows → Enter; Tab through steps; Esc closes dialog | All reachable, visible focus |
| 17 | Stop the server and reload | App shell loads from cache; clear error for routes |
| 18 | Unknown ids: `#/map?to=99999`, `#/events/99999` | "No campus location with id …" / "Event unavailable" |

## Route correctness checks for a real dataset

1. `python manage.py validate campus.json` — no errors, review warnings (unreachable locations).
2. Pick 10 well-known trips; walk them with a measuring wheel or GPS logger; compare distance
   (target ±10 %) and time.
3. For every building, verify at least one step-free route from a gate exists or that the lack
   of one is real.
4. Re-run the pytest suite after each import: `test_every_location_reachable_from_main_gate`
   uses the live dataset when pointed at it.
