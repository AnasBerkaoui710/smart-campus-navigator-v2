# Routing engine

Code: `backend/app/routing/` — `graph.py`, `profiles.py`, `engine.py`, `instructions.py`.

## 1. Graph model

| Element | Meaning | Key attributes |
|---|---|---|
| Node | A navigable point: gate, junction, building entrance, corridor point, stair/elevator landing, room | lat/lng, `floor`, `building_id` (NULL = outdoors), `kind`, `accessible` (true / false / NULL = not surveyed) |
| Edge | A connection you can walk | `kind` (walkway, corridor, door, stairs, ramp, elevator), `length_m`, `accessible`, `bidirectional`, `status` (open/closed), `restricted` |

Indoor floors are separate nodes at the same lat/lng with different `floor` values,
joined by `stairs` or `elevator` edges. Building entrances are the hand-over points
between the outdoor network and a building's ground-floor corridors.

## 2. Algorithm — A*

`engine.astar()` is a textbook A* with a binary heap:

* `g(n)` — cost of the best known path from the start.
* `h(n)` — straight-line (haversine) distance to the goal; divided by the fastest
  walking speed for the `fastest` profile.
* **Admissibility:** the importer rejects any edge whose `length_m` is shorter than the
  straight line between its nodes, and every per-kind speed is ≤ the speed used in the
  heuristic, so `h` never overestimates. A* therefore returns the same optimum as
  Dijkstra — this is checked by `tests/test_engine.py::test_astar_matches_dijkstra_on_random_graphs`
  (50 random graphs × 10 queries × 2 profiles).
* Complexity: O(E log V); on a campus graph of a few thousand nodes a query takes a few
  milliseconds in pure Python. The graph is held in memory and rebuilt only when an
  admin closes/reopens a path or imports data.

## 3. Cost model (`profiles.py`)

| Edge kind | Distance cost | Time cost |
|---|---|---|
| walkway, corridor | length | length ÷ 1.3 m/s |
| door | length | length ÷ (1.3 × 0.8) |
| ramp | length | length ÷ (1.3 × 0.9) |
| stairs | length (measured along the flight) | length ÷ (1.3 × 0.45) |
| elevator | 4 m per floor | 30 s wait + 4 s per floor |

* `shortest` minimises metres, `fastest` minimises seconds. The API always computes
  both; if they differ the client shows both so the user can choose.
* **Constraints** (both profiles): closed edges, restricted edges and client-reported
  `avoid_edges` are skipped. With `avoid_stairs`, stairs edges and any edge or node marked
  `accessible = false` are skipped.
* **Unknown accessibility:** edges/nodes with `accessible = NULL` are *allowed* but
  counted. The route is then labelled "Step-free (unverified parts)" with a warning, instead
  of claiming a verified accessible route. If no route exists at all without stairs,
  the API returns `no_step_free_route` and says a route with stairs exists.

All constants are in one file so a university can calibrate them (e.g. measured elevator
wait times).

## 4. Alternative routes

Penalty method: after the best route, edges already used get their cost ×1.4 and A* runs
again. A candidate is kept only if its *real* cost is ≤ 1.5× the best and ≤ 70 % of its
length overlaps routes already returned. Up to two alternatives are returned.

## 5. Blocked paths and re-routing

* **Staff closures** — `PATCH /api/admin/edges/:id {status:"closed"}` removes a path from
  every route immediately (the graph cache is invalidated).
* **User reports** — every instruction step carries its `edge_ids`; "Blocked?" re-requests
  the route with those edges in `avoid_edges`.
* **Off-route** — with live GPS, the client measures the distance from each fix to the
  outdoor legs of the route. More than 25 m for two consecutive fixes (and at least 10 s
  since the last re-route) triggers a new route from the current position. Indoor legs are
  ignored because GPS is unreliable inside buildings.
* **GPS start** — a position is snapped to the nearest *outdoor* node (GPS has no floor). If
  that is farther than `SNAP_MAX_DISTANCE_M` (150 m) the user is told they are outside the
  mapped campus. The straight-line approach is added to the totals and flagged as an estimate.

## 6. Instructions (`instructions.py`)

Consecutive edges of the same kind, in the same place (outdoors, or one building floor),
are merged while they keep the same path name or bend less than 30°. Turns are classified
from the change in compass bearing: < 30° continue, 30–60° bear, 60–150° turn, > 150° turn
around. Stairs/elevator runs become "Take the elevator up to floor 2"; doors become
"Enter … through the …" / "Exit …"; the final step names the room and floor.

## 7. Dataset format (`campusnav-pathways/1`)

```json
{
  "format": "campusnav-pathways/1",
  "name": "My University — Main Campus",
  "is_sample": false,
  "coordinates": "latlng",            // or "local_m" with an "origin" {lat,lng}
  "buildings": [{"code": "ENG", "name": "...", "footprint": [[lat,lng], ...], "floors": [0,1,2]}],
  "nodes": [{"code": "ENG-ENT-S", "lat": 0, "lng": 0, "floor": 0, "building": "ENG",
             "kind": "entrance", "name": "South entrance", "accessible": true}],
  "edges": [{"code": "e1", "from": "A", "to": "B", "kind": "walkway", "name": "Library Lane",
             "accessible": true, "length_m": 42.0, "bidirectional": true}],
  "locations": [{"code": "eng-201", "name": "Seminar Room", "type": "classroom",
                 "building": "ENG", "floor": 2, "room_number": "ENG-201", "node": "ENG-201"}]
}
```

`length_m` is optional for flat edges (computed from coordinates) and **required** for
vertical edges (stairs/elevators). Records are upserted by `code`, so re-importing keeps
event venues and closures. Validate with `python manage.py validate file.json`.

## 8. Where AI can add measurable value later

The first version deliberately uses no machine learning: a deterministic graph search is
exact, explainable and testable. Candidate AI features, each with the data it needs and
how it would be evaluated:

| Feature | Needs | Evaluation |
|---|---|---|
| Congestion-aware times (e.g. corridors at class change) | anonymised, opt-in position traces or door counters | predicted vs. measured travel time, MAE per edge and time slot |
| Learned walking speeds per edge kind | the same traces | compare against the fixed 1.3 m/s model on held-out trips |
| "Less crowded route" option | congestion predictions above | user choice rate, measured trip time |
| Conversational assistant ("where is my thermodynamics exam?") | events + locations API as tools for an LLM | task success rate on a scripted question set; must only answer from API data |
| Event recommendations | opt-in attendance history | click-through / attendance uplift in an A/B test |

Each would plug into the existing cost model (as per-edge time multipliers) or call the
existing API, so the routing core stays deterministic.
