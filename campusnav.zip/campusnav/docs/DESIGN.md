# Design and data notes

## Colour palette
Forest green, warm beige and a clear red. Starting points from web research: forest green `#245D38`
(a government "tree green"), sage `#9DC183` and cream/beige `#EDE8D0`. Red is used sparingly for the
destination pin, closures, warnings and the Exit button.

| Role | Hex |
|---|---|
| Brand / buttons / top bar | `#245D38` (hover `#1D4D32`) |
| Sage accents, walkways | `#9DC183`, `#7FAE6B` |
| Page background / cards | `#F6F1E4` / `#FCFAF4` |
| Borders | `#EBE4D0` |
| Cream (badges, building fill) | `#EDE8D0` |
| Clear red (destination, danger) | `#B3261E` (soft `#FBE4E1`) |
| Text / muted text | `#1C2A21` / `#5D6B61` |

White on `#245D38` has a contrast ratio above 7:1; red `#B3261E` on white is above 6:1.

## Campus data: what is real and what is potential
FST Béni Mellal (Mghila) — OSM way 846672283, about 32.3766 N, 6.3193 W.

| Data | Source |
|---|---|
| Campus outline | **Real** — OpenStreetMap |
| Internal ring road, west connector, gate approaches | **Real** — OpenStreetMap (`data/osm_fst_raw.json`) |
| ~17 m link between the east access road and the ring road | Inferred (labelled "East connector (inferred, not in OSM)") |
| Building positions and footprints | **Potential** — OSM has no building footprints for this campus |
| Floors (1–3), corridors, rooms, names, lifts, accessibility | **Potential** — illustrative, to be replaced by a survey |

Floors: Library, Mathematics & CS, Biology & Geology and Chemistry & Physics have 3 floors;
Administration, Lecture Halls and the Teaching Block have 2; Cafeteria and Student Life have 1.
Library, Administration, Lecture Halls, Mathematics & CS and the Teaching Block have a lift; Biology & Geology
and Chemistry & Physics are stairs-only (Chemistry & Physics' entrance is also recorded as "not surveyed").

Regenerate with `python tools/generate_fst_campus.py` (from `backend/`), then `python manage.py import data/fst_campus.json`.
Map data © OpenStreetMap contributors (ODbL).
